"""Typed database repository helpers for StreamShield FastAPI service."""

from __future__ import annotations

import json
import uuid
from datetime import datetime, timezone
from typing import Any

from .database import execute, fetch_all, get_db


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _parse_json_field(val: Any, default: Any) -> Any:
    if val is None:
        return default
    if isinstance(val, (list, dict)):
        return val
    return json.loads(val)


def get_customer(customer_id: str) -> dict[str, Any] | None:
    with get_db() as (conn, dialect):
        rows = fetch_all(conn, dialect, "SELECT * FROM customers WHERE customer_id = %s", (customer_id,))
        if not rows:
            return None
        row = rows[0]
        row["usual_active_hours"] = _parse_json_field(row["usual_active_hours"], [])
        row["baseline_amount_median"] = float(row["baseline_amount_median"])
        row["baseline_amount_mad"] = float(row["baseline_amount_mad"])
        return row


def get_beneficiary(beneficiary_id: str) -> dict[str, Any] | None:
    with get_db() as (conn, dialect):
        rows = fetch_all(conn, dialect, "SELECT * FROM beneficiaries WHERE beneficiary_id = %s", (beneficiary_id,))
        if not rows:
            return None
        row = rows[0]
        row["incoming_amount_24h"] = float(row["incoming_amount_24h"])
        row["outgoing_amount_24h"] = float(row["outgoing_amount_24h"])
        row["flow_through_ratio"] = float(row["flow_through_ratio"])
        return row


def create_payment_record(
    payment_id: str,
    user_uid: str | None,
    customer_id: str,
    beneficiary_id: str,
    amount: float,
    purpose: str | None,
    language: str,
    status: str,
    is_new_beneficiary: bool,
    channel: str = "WEB_SIMULATOR",
    created_at_override: str | None = None,
) -> str:
    created_at = created_at_override or _now_iso()
    with get_db() as (conn, dialect):
        execute(
            conn,
            dialect,
            """
            INSERT INTO payments (
                payment_id, user_uid, customer_id, beneficiary_id, amount, currency,
                purpose, language, channel, status, is_new_beneficiary, is_simulated, created_at
            ) VALUES (%s, %s, %s, %s, %s, 'INR', %s, %s, %s, %s, %s, %s, %s)
            ON CONFLICT (payment_id) DO NOTHING
            """,
            (
                payment_id,
                user_uid,
                customer_id,
                beneficiary_id,
                amount,
                purpose,
                language,
                channel,
                status,
                bool(is_new_beneficiary) if dialect == "postgres" else int(bool(is_new_beneficiary)),
                True if dialect == "postgres" else 1,
                created_at,
            ),
        )
    return created_at


def save_assessment_record(payment_id: str, stage: str, assessment: dict[str, Any]) -> str:
    assessment_id = f"ASM_{uuid.uuid4().hex[:10].upper()}"
    created_at = _now_iso()
    comp = assessment["component_scores"]
    with get_db() as (conn, dialect):
        execute(
            conn,
            dialect,
            """
            INSERT INTO assessments (
                assessment_id, payment_id, stage,
                transaction_anomaly_score, beneficiary_risk_score, coercion_risk_score,
                overall_risk_score, risk_level, recommended_action,
                reason_codes, explanations, requires_questions,
                scoring_latency_ms, model_version, policy_version, created_at
            ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            """,
            (
                assessment_id,
                payment_id,
                stage,
                int(comp["transaction_anomaly_score"]),
                int(comp["beneficiary_risk_score"]),
                comp["coercion_risk_score"],
                int(assessment["overall_risk_score"]),
                assessment["risk_level"],
                assessment["recommended_action"],
                json.dumps(assessment["reason_codes"]),
                json.dumps(assessment["explanations"]),
                bool(assessment["requires_questions"]) if dialect == "postgres" else int(bool(assessment["requires_questions"])),
                float(assessment.get("scoring_latency_ms", 0.0)),
                assessment.get("model_version", "streamshield_rfde_v1.0"),
                assessment.get("policy_version", "policy_v1.0"),
                created_at,
            ),
        )
    return assessment_id


def save_answer_record(payment_id: str, question_id: str, answer: str, input_mode: str) -> str:
    answer_id = f"ANS_{uuid.uuid4().hex[:10].upper()}"
    answered_at = _now_iso()
    with get_db() as (conn, dialect):
        execute(
            conn,
            dialect,
            """
            INSERT INTO answers (answer_id, payment_id, question_id, answer, input_mode, answered_at)
            VALUES (%s, %s, %s, %s, %s, %s)
            """,
            (answer_id, payment_id, question_id, answer, input_mode, answered_at),
        )
    return answered_at


def update_payment_status(payment_id: str, status: str, customer_choice: str | None = None) -> None:
    with get_db() as (conn, dialect):
        if customer_choice is not None:
            execute(
                conn,
                dialect,
                "UPDATE payments SET status = %s, customer_choice = %s WHERE payment_id = %s",
                (status, customer_choice, payment_id),
            )
        else:
            execute(
                conn,
                dialect,
                "UPDATE payments SET status = %s WHERE payment_id = %s",
                (status, payment_id),
            )


def save_feedback_record(
    payment_id: str,
    user_uid: str | None,
    outcome: str,
    label_source: str,
    notes: str | None,
) -> str:
    feedback_id = f"FDB_{uuid.uuid4().hex[:10].upper()}"
    created_at = _now_iso()
    with get_db() as (conn, dialect):
        execute(
            conn,
            dialect,
            """
            INSERT INTO feedback (feedback_id, payment_id, user_uid, outcome, label_source, notes, created_at)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
            """,
            (feedback_id, payment_id, user_uid, outcome, label_source, notes, created_at),
        )
    return feedback_id


def log_audit_event(payment_id: str, event_type: str, actor: str, details: dict[str, Any]) -> None:
    event_id = f"AUD_{uuid.uuid4().hex[:10].upper()}"
    created_at = _now_iso()
    with get_db() as (conn, dialect):
        execute(
            conn,
            dialect,
            """
            INSERT INTO audit_events (event_id, payment_id, event_type, actor, details, created_at)
            VALUES (%s, %s, %s, %s, %s, %s)
            """,
            (event_id, payment_id, event_type, actor, json.dumps(details), created_at),
        )


def _hydrate_assessment(row: dict[str, Any]) -> dict[str, Any]:
    return {
        "overall_risk_score": int(row["overall_risk_score"]),
        "risk_level": row["risk_level"],
        "recommended_action": row["recommended_action"],
        "component_scores": {
            "transaction_anomaly_score": int(row["transaction_anomaly_score"]),
            "beneficiary_risk_score": int(row["beneficiary_risk_score"]),
            "coercion_risk_score": (
                int(row["coercion_risk_score"]) if row["coercion_risk_score"] is not None else None
            ),
        },
        "reason_codes": _parse_json_field(row["reason_codes"], []),
        "explanations": _parse_json_field(row["explanations"], []),
        "requires_questions": bool(row["requires_questions"]),
        "is_simulated": True,
        "scoring_latency_ms": float(row["scoring_latency_ms"] or 0.0),
        "model_version": row["model_version"],
        "policy_version": row["policy_version"],
    }


def get_payment_full(payment_id: str) -> dict[str, Any] | None:
    with get_db() as (conn, dialect):
        p_rows = fetch_all(conn, dialect, "SELECT * FROM payments WHERE payment_id = %s", (payment_id,))
        if not p_rows:
            return None
        p = p_rows[0]
        a_rows = fetch_all(
            conn,
            dialect,
            "SELECT * FROM assessments WHERE payment_id = %s ORDER BY created_at ASC",
            (payment_id,),
        )
        ans_rows = fetch_all(
            conn,
            dialect,
            "SELECT question_id, answer, input_mode, answered_at FROM answers WHERE payment_id = %s ORDER BY answered_at ASC",
            (payment_id,),
        )
        fb_rows = fetch_all(
            conn,
            dialect,
            "SELECT outcome, label_source, notes, created_at FROM feedback WHERE payment_id = %s ORDER BY created_at DESC LIMIT 1",
            (payment_id,),
        )

        b_rows = fetch_all(
            conn,
            dialect,
            "SELECT name, vpa FROM beneficiaries WHERE beneficiary_id = %s",
            (p["beneficiary_id"],),
        )
        beneficiary_name = b_rows[0]["name"] if b_rows else p["beneficiary_id"]
        beneficiary_vpa = b_rows[0]["vpa"] if b_rows else ""

        initial_asm = None
        final_asm = None
        for a in a_rows:
            hydrated = _hydrate_assessment(a)
            if a["stage"] == "INITIAL":
                initial_asm = hydrated
            elif a["stage"] == "FINAL":
                final_asm = hydrated

        return {
            "payment_id": p["payment_id"],
            "customer_id": p["customer_id"],
            "beneficiary_id": p["beneficiary_id"],
            "beneficiary_name": beneficiary_name,
            "beneficiary_vpa": beneficiary_vpa,
            "amount": float(p["amount"]),
            "currency": p["currency"],
            "purpose": p["purpose"] or "",
            "language": p["language"],
            "channel": p["channel"],
            "status": p["status"],
            "created_at": str(p["created_at"]),
            "is_simulated": True,
            "initial_assessment": initial_asm,
            "final_assessment": final_asm or initial_asm,
            "answers": [
                {
                    "question_id": r["question_id"],
                    "answer": r["answer"],
                    "input_mode": r["input_mode"],
                    "answered_at": str(r["answered_at"]),
                }
                for r in ans_rows
            ],
            "customer_choice": p["customer_choice"],
            "feedback": (
                {
                    "outcome": fb_rows[0]["outcome"],
                    "label_source": fb_rows[0]["label_source"],
                    "notes": fb_rows[0]["notes"],
                }
                if fb_rows
                else None
            ),
        }


def _hydrate_payments_batch(p_rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    if not p_rows:
        return []

    pids = [p["payment_id"] for p in p_rows]
    placeholders = ", ".join(["%s"] * len(pids))
    pid_tuple = tuple(pids)

    with get_db() as (conn, dialect):
        a_rows = fetch_all(
            conn,
            dialect,
            f"SELECT * FROM assessments WHERE payment_id IN ({placeholders}) ORDER BY created_at ASC",
            pid_tuple,
        )
        ans_rows = fetch_all(
            conn,
            dialect,
            f"SELECT payment_id, question_id, answer, input_mode, answered_at FROM answers WHERE payment_id IN ({placeholders}) ORDER BY answered_at ASC",
            pid_tuple,
        )
        fb_rows = fetch_all(
            conn,
            dialect,
            f"SELECT payment_id, outcome, label_source, notes, created_at FROM feedback WHERE payment_id IN ({placeholders}) ORDER BY created_at DESC",
            pid_tuple,
        )
        b_rows = fetch_all(
            conn,
            dialect,
            "SELECT beneficiary_id, name, vpa FROM beneficiaries",
        )

    ben_map = {b["beneficiary_id"]: (b["name"], b["vpa"]) for b in b_rows}
    asm_by_pid: dict[str, tuple[dict[str, Any] | None, dict[str, Any] | None]] = {}
    for a in a_rows:
        pid = a["payment_id"]
        init_asm, fin_asm = asm_by_pid.get(pid, (None, None))
        hydrated = _hydrate_assessment(a)
        if a["stage"] == "INITIAL":
            init_asm = hydrated
        elif a["stage"] == "FINAL":
            fin_asm = hydrated
        asm_by_pid[pid] = (init_asm, fin_asm)

    ans_by_pid: dict[str, list[dict[str, Any]]] = {}
    for r in ans_rows:
        ans_by_pid.setdefault(r["payment_id"], []).append(
            {
                "question_id": r["question_id"],
                "answer": r["answer"],
                "input_mode": r["input_mode"],
                "answered_at": str(r["answered_at"]),
            }
        )

    fb_by_pid: dict[str, dict[str, Any]] = {}
    for f in fb_rows:
        if f["payment_id"] not in fb_by_pid:
            fb_by_pid[f["payment_id"]] = {
                "outcome": f["outcome"],
                "label_source": f["label_source"],
                "notes": f["notes"],
            }

    sessions: list[dict[str, Any]] = []
    for p in p_rows:
        pid = p["payment_id"]
        init_asm, fin_asm = asm_by_pid.get(pid, (None, None))
        ben_name, ben_vpa = ben_map.get(p["beneficiary_id"], (p["beneficiary_id"], ""))
        sessions.append(
            {
                "payment_id": pid,
                "customer_id": p["customer_id"],
                "beneficiary_id": p["beneficiary_id"],
                "beneficiary_name": ben_name,
                "beneficiary_vpa": ben_vpa,
                "amount": float(p["amount"]),
                "currency": p["currency"],
                "purpose": p["purpose"] or "",
                "language": p["language"],
                "channel": p["channel"],
                "status": p["status"],
                "created_at": str(p["created_at"]),
                "is_simulated": True,
                "initial_assessment": init_asm,
                "final_assessment": fin_asm or init_asm,
                "answers": ans_by_pid.get(pid, []),
                "customer_choice": p["customer_choice"],
                "feedback": fb_by_pid.get(pid),
            }
        )
    return sessions


def list_admin_alerts(
    risk_level: str | None = None,
    recommended_action: str | None = None,
    limit: int = 50,
    offset: int = 0,
) -> list[dict[str, Any]]:
    with get_db() as (conn, dialect):
        p_rows = fetch_all(
            conn,
            dialect,
            """
            SELECT * FROM payments
            ORDER BY CASE WHEN status = 'REFERRED_FOR_REVIEW' THEN 0 ELSE 1 END, created_at DESC
            LIMIT %s OFFSET %s
            """,
            (limit, offset),
        )
    sessions = _hydrate_payments_batch(p_rows)
    if not risk_level and not recommended_action:
        return sessions
    filtered: list[dict[str, Any]] = []
    for item in sessions:
        latest = item.get("final_assessment") or item.get("initial_assessment")
        if risk_level and latest and latest["risk_level"] != risk_level:
            continue
        if recommended_action and latest and latest["recommended_action"] != recommended_action:
            continue
        filtered.append(item)
    return filtered


def get_admin_metrics() -> dict[str, Any]:
    with get_db() as (conn, dialect):
        p_rows = fetch_all(conn, dialect, "SELECT status, customer_choice FROM payments")
        a_rows = fetch_all(
            conn,
            dialect,
            "SELECT risk_level, recommended_action, scoring_latency_ms FROM assessments WHERE stage = 'FINAL' OR stage = 'INITIAL'",
        )
        f_rows = fetch_all(conn, dialect, "SELECT outcome FROM feedback")

    risk_counts: dict[str, int] = {"LOW": 0, "MEDIUM": 0, "HIGH": 0}
    action_counts: dict[str, int] = {}
    latencies: list[float] = []
    for a in a_rows:
        lvl = a["risk_level"]
        risk_counts[lvl] = risk_counts.get(lvl, 0) + 1
        act = a["recommended_action"]
        action_counts[act] = action_counts.get(act, 0) + 1
        if a["scoring_latency_ms"] is not None:
            latencies.append(float(a["scoring_latency_ms"]))

    outcome_counts: dict[str, int] = {}
    for f in f_rows:
        out = f["outcome"]
        outcome_counts[out] = outcome_counts.get(out, 0) + 1

    avg_latency = round(sum(latencies) / len(latencies), 2) if latencies else 0.0
    sorted_lat = sorted(latencies)
    p99_latency = (
        round(sorted_lat[min(len(sorted_lat) - 1, int(len(sorted_lat) * 0.99))], 2)
        if sorted_lat
        else 0.0
    )

    return {
        "total_payments": len(p_rows),
        "count_by_risk_level": risk_counts,
        "count_by_recommended_action": action_counts,
        "feedback_outcome_counts": outcome_counts,
        "avg_scoring_latency_ms": avg_latency,
        "p99_scoring_latency_ms": p99_latency,
    }


def _seed_user_sample_history(customer_id: str, user_uid: str | None) -> None:
    """Idempotently populate realistic synthetic past transactions if customer has none yet."""
    with get_db() as (conn, dialect):
        existing = fetch_all(
            conn,
            dialect,
            "SELECT payment_id FROM payments WHERE customer_id = %s LIMIT 1",
            (customer_id,),
        )
        if existing:
            return

    cust = get_customer(customer_id)
    if not cust:
        return

    median = float(cust["baseline_amount_median"])
    lang = str(cust["preferred_language"])
    samples = [
        {
            "suffix": "01",
            "beneficiary_id": "BEN_0102",
            "amount": round(max(120.0, median * 0.45), 0),
            "purpose": "Morning Groceries & Dairy",
            "channel": "PHONE_APP",
            "status": "SIMULATION_CONTINUED",
            "choice": "CONTINUE_SIMULATED",
            "score": 14,
            "tbe": 12,
            "bre": 10,
            "cce": None,
            "risk_level": "LOW",
            "action": "ALLOW",
            "reasons": ["BASELINE_CONSISTENT"],
            "explanations": ["Matches 30-day household grocery baseline at trusted local merchant."],
            "offset_hours": 72,
        },
        {
            "suffix": "02",
            "beneficiary_id": "BEN_0101",
            "amount": round(max(350.0, median * 0.85), 0),
            "purpose": "Clinic Consultation & Pharmacy",
            "channel": "PHONE_APP",
            "status": "SIMULATION_CONTINUED",
            "choice": "CONTINUE_SIMULATED",
            "score": 18,
            "tbe": 16,
            "bre": 14,
            "cce": None,
            "risk_level": "LOW",
            "action": "ALLOW",
            "reasons": ["TRUSTED_BENEFICIARY"],
            "explanations": ["Established clinic recipient with consistent payer behaviour."],
            "offset_hours": 36,
        },
        {
            "suffix": "03",
            "beneficiary_id": "BEN_0602",
            "amount": round(max(18500.0, median * 8.0), 0),
            "purpose": "Urgent KYC Reactivation Fee",
            "channel": "LAPTOP_WEB",
            "status": "SIMULATION_CANCELLED",
            "choice": "CANCEL_SIMULATED",
            "score": 88,
            "tbe": 74,
            "bre": 91,
            "cce": 78,
            "risk_level": "HIGH",
            "action": "SAFETY_PAUSE",
            "reasons": ["AMOUNT_ABOVE_BASELINE", "BENEFICIARY_RAPID_OUTFLOW", "AUTHORITY_THREAT_REPORTED"],
            "explanations": [
                "Transfer size significantly exceeded household baseline and targeted a high-flow-through beneficiary.",
                "Customer cancelled after coercion protection pause.",
            ],
            "offset_hours": 14,
        },
    ]

    from datetime import timedelta

    now = datetime.now(timezone.utc)
    for item in samples:
        pid = f"HIST_{customer_id}_{item['suffix']}"
        ts = (now - timedelta(hours=item["offset_hours"])).isoformat().replace("+00:00", "Z")
        with get_db() as (conn, dialect):
            execute(
                conn,
                dialect,
                """
                INSERT INTO payments (
                    payment_id, user_uid, customer_id, beneficiary_id, amount, currency,
                    purpose, language, channel, status, customer_choice, is_new_beneficiary, is_simulated, created_at
                ) VALUES (%s, %s, %s, %s, %s, 'INR', %s, %s, %s, %s, %s, %s, %s, %s)
                ON CONFLICT (payment_id) DO NOTHING
                """,
                (
                    pid,
                    user_uid,
                    customer_id,
                    item["beneficiary_id"],
                    item["amount"],
                    item["purpose"],
                    lang,
                    item["channel"],
                    item["status"],
                    item["choice"],
                    True if dialect == "postgres" else 1,
                    True if dialect == "postgres" else 1,
                    ts,
                ),
            )
            asm_id = f"ASM_{pid}"
            execute(
                conn,
                dialect,
                """
                INSERT INTO assessments (
                    assessment_id, payment_id, stage,
                    transaction_anomaly_score, beneficiary_risk_score, coercion_risk_score,
                    overall_risk_score, risk_level, recommended_action,
                    reason_codes, explanations, requires_questions,
                    scoring_latency_ms, model_version, policy_version, created_at
                ) VALUES (%s, %s, 'FINAL', %s, %s, %s, %s, %s, %s, %s, %s, %s, 1.85, 'streamshield_rfde_v1.0', 'policy_v1.0', %s)
                ON CONFLICT (assessment_id) DO NOTHING
                """,
                (
                    asm_id,
                    pid,
                    item["tbe"],
                    item["bre"],
                    item["cce"],
                    item["score"],
                    item["risk_level"],
                    item["action"],
                    json.dumps(item["reasons"]),
                    json.dumps(item["explanations"]),
                    bool(item["cce"] is not None) if dialect == "postgres" else int(item["cce"] is not None),
                    ts,
                ),
            )


def list_user_payments(customer_id: str, limit: int = 50) -> list[dict[str, Any]]:
    with get_db() as (conn, dialect):
        p_rows = fetch_all(
            conn,
            dialect,
            "SELECT * FROM payments WHERE customer_id = %s ORDER BY created_at DESC LIMIT %s",
            (customer_id, limit),
        )
    return _hydrate_payments_batch(p_rows)


def get_user_account_summary(customer_id: str, user_uid: str | None = None) -> dict[str, Any] | None:
    profile = get_customer(customer_id)
    if profile is None:
        return None

    _seed_user_sample_history(customer_id, user_uid)
    transactions = list_user_payments(customer_id, limit=50)

    scores: list[int] = []
    pending_review_count = 0
    approved_count = 0
    terminated_count = 0
    for tx in transactions:
        asm = tx.get("final_assessment") or tx.get("initial_assessment")
        if asm and isinstance(asm.get("overall_risk_score"), (int, float)):
            scores.append(int(asm["overall_risk_score"]))
        if tx["status"] == "REFERRED_FOR_REVIEW":
            pending_review_count += 1
        elif tx["status"] == "APPROVED_BY_BANK":
            approved_count += 1
        elif tx["status"] == "TERMINATED_SCAM":
            terminated_count += 1

    avg_risk = round(sum(scores) / len(scores)) if scores else 0
    latest_score = scores[0] if scores else 0

    handle_map = {
        "CUS_0001": "rama.rao@okupi",
        "CUS_0002": "priya.sharma@okupi",
        "CUS_0003": "ramesh.kumar@okupi",
        "CUS_0004": "sunita.devi@okupi",
    }

    return {
        "profile": profile,
        "vpa": handle_map.get(customer_id, f"{customer_id.lower()}@okupi"),
        "average_risk_score": avg_risk,
        "latest_risk_score": latest_score,
        "total_transactions": len(transactions),
        "pending_review_count": pending_review_count,
        "approved_count": approved_count,
        "terminated_count": terminated_count,
        "transactions": transactions,
    }
