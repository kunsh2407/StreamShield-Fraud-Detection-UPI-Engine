"""Database connection helper for StreamShield FastAPI backend.

Uses Cloud SQL PostgreSQL via SQL_HOST / SQL_USER / SQL_PASSWORD / SQL_DB_NAME
(never DATABASE_URL) when configured, with automatic local SQLite dev fallback
only when SQL_HOST is absent in an isolated local environment.
"""

from __future__ import annotations

import json
import sqlite3
from contextlib import contextmanager
from typing import Any, Iterator

import psycopg2
from psycopg2 import pool as pg_pool
from psycopg2.extras import RealDictCursor

from ..config import DATA_DIR, SQL_DB_NAME, SQL_HOST, SQL_PASSWORD, SQL_USER
from ..models.model_loader import CANONICAL_QUESTIONS_CATALOG, registry

USE_POSTGRES = bool(SQL_HOST and SQL_USER and SQL_DB_NAME)
SQLITE_PATH = DATA_DIR / "streamshield_dev.db"

_INITIALIZED = False
_PG_POOL: pg_pool.ThreadedConnectionPool | None = None


def _pg_connect():
    return psycopg2.connect(
        host=SQL_HOST,
        user=SQL_USER,
        password=SQL_PASSWORD,
        dbname=SQL_DB_NAME,
        connect_timeout=10,
    )


def _get_pg_pool() -> pg_pool.ThreadedConnectionPool:
    global _PG_POOL
    if _PG_POOL is None or _PG_POOL.closed:
        _PG_POOL = pg_pool.ThreadedConnectionPool(
            minconn=1,
            maxconn=10,
            host=SQL_HOST,
            user=SQL_USER,
            password=SQL_PASSWORD,
            dbname=SQL_DB_NAME,
            connect_timeout=10,
        )
    return _PG_POOL


def _checkout_pg_conn():
    p = _get_pg_pool()
    conn = p.getconn()
    try:
        if conn.closed:
            raise psycopg2.InterfaceError("closed connection")
        with conn.cursor() as cur:
            cur.execute("SELECT 1")
        conn.rollback()
        return p, conn
    except (psycopg2.OperationalError, psycopg2.InterfaceError):
        try:
            p.putconn(conn, close=True)
        except Exception:
            pass
        fresh = _pg_connect()
        return None, fresh


def _sqlite_connect():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(SQLITE_PATH))
    conn.row_factory = sqlite3.Row
    return conn


@contextmanager
def get_db() -> Iterator[tuple[Any, str]]:
    """Yield (connection, dialect) where dialect is 'postgres' or 'sqlite'."""
    ensure_initialized()
    if USE_POSTGRES:
        pool_ref, conn = _checkout_pg_conn()
        try:
            yield conn, "postgres"
            conn.commit()
        except Exception:
            try:
                conn.rollback()
            except Exception:
                pass
            raise
        finally:
            if pool_ref is not None:
                try:
                    pool_ref.putconn(conn, close=bool(conn.closed))
                except Exception:
                    conn.close()
            else:
                conn.close()
    else:
        conn = _sqlite_connect()
        try:
            yield conn, "sqlite"
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()


def ensure_initialized() -> None:
    """Create dev fallback tables if using local SQLite and seed canonical records idempotently."""
    global _INITIALIZED
    if _INITIALIZED:
        return

    if USE_POSTGRES:
        # In Cloud SQL mode, Drizzle manages DDL; we only seed canonical synthetic rows if missing.
        conn = _pg_connect()
        try:
            _seed_postgres(conn)
            conn.commit()
        finally:
            conn.close()
    else:
        conn = _sqlite_connect()
        try:
            _create_sqlite_schema(conn)
            _seed_sqlite(conn)
            conn.commit()
        finally:
            conn.close()

    _INITIALIZED = True


def _create_sqlite_schema(conn: sqlite3.Connection) -> None:
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS customers (
            customer_id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            preferred_language TEXT NOT NULL,
            profile_group TEXT NOT NULL,
            baseline_txn_count_30d INTEGER NOT NULL,
            baseline_amount_median REAL NOT NULL,
            baseline_amount_mad REAL NOT NULL,
            usual_active_hours TEXT NOT NULL,
            occupation TEXT NOT NULL,
            age INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS beneficiaries (
            beneficiary_id TEXT PRIMARY KEY,
            vpa TEXT NOT NULL,
            name TEXT NOT NULL,
            account_age_days INTEGER,
            customer_counterparties_30d INTEGER NOT NULL,
            incoming_txn_count_24h INTEGER NOT NULL,
            incoming_amount_24h REAL NOT NULL,
            outgoing_amount_24h REAL NOT NULL,
            flow_through_ratio REAL NOT NULL,
            network_degree INTEGER NOT NULL,
            synthetic_report_count INTEGER NOT NULL,
            category TEXT NOT NULL,
            risk_tier TEXT
        );
        CREATE TABLE IF NOT EXISTS payments (
            payment_id TEXT PRIMARY KEY,
            user_uid TEXT,
            customer_id TEXT NOT NULL,
            beneficiary_id TEXT NOT NULL,
            amount REAL NOT NULL,
            currency TEXT NOT NULL DEFAULT 'INR',
            purpose TEXT,
            language TEXT NOT NULL,
            channel TEXT NOT NULL DEFAULT 'WEB_SIMULATOR',
            status TEXT NOT NULL,
            customer_choice TEXT,
            is_new_beneficiary INTEGER NOT NULL DEFAULT 1,
            is_simulated INTEGER NOT NULL DEFAULT 1,
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS assessments (
            assessment_id TEXT PRIMARY KEY,
            payment_id TEXT NOT NULL,
            stage TEXT NOT NULL,
            transaction_anomaly_score INTEGER NOT NULL,
            beneficiary_risk_score INTEGER NOT NULL,
            coercion_risk_score INTEGER,
            overall_risk_score INTEGER NOT NULL,
            risk_level TEXT NOT NULL,
            recommended_action TEXT NOT NULL,
            reason_codes TEXT NOT NULL,
            explanations TEXT NOT NULL,
            requires_questions INTEGER NOT NULL DEFAULT 0,
            scoring_latency_ms REAL,
            model_version TEXT NOT NULL,
            policy_version TEXT NOT NULL,
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS questions (
            question_id TEXT PRIMARY KEY,
            translations TEXT NOT NULL,
            audio_prompts TEXT NOT NULL,
            intent TEXT NOT NULL,
            triggered_reason_code TEXT NOT NULL,
            answer_options TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS answers (
            answer_id TEXT PRIMARY KEY,
            payment_id TEXT NOT NULL,
            question_id TEXT NOT NULL,
            answer TEXT NOT NULL,
            input_mode TEXT NOT NULL,
            answered_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS feedback (
            feedback_id TEXT PRIMARY KEY,
            payment_id TEXT NOT NULL,
            user_uid TEXT,
            outcome TEXT NOT NULL,
            label_source TEXT NOT NULL,
            notes TEXT,
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS audit_events (
            event_id TEXT PRIMARY KEY,
            payment_id TEXT NOT NULL,
            event_type TEXT NOT NULL,
            actor TEXT NOT NULL,
            details TEXT NOT NULL,
            created_at TEXT NOT NULL
        );
        """
    )


def _seed_sqlite(conn: sqlite3.Connection) -> None:
    for c in list(registry.customers.values())[:25]:
        conn.execute(
            """
            INSERT OR IGNORE INTO customers (
                customer_id, name, preferred_language, profile_group,
                baseline_txn_count_30d, baseline_amount_median, baseline_amount_mad,
                usual_active_hours, occupation, age
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                c["customer_id"],
                c["name"],
                c["preferred_language"],
                c["profile_group"],
                int(c["baseline_txn_count_30d"]),
                float(c["baseline_amount_median"]),
                float(c["baseline_amount_mad"]),
                json.dumps(c["usual_active_hours"]),
                c["occupation"],
                int(c["age"]),
            ),
        )

    for b in list(registry.beneficiaries.values())[:25]:
        conn.execute(
            """
            INSERT OR IGNORE INTO beneficiaries (
                beneficiary_id, vpa, name, account_age_days, customer_counterparties_30d,
                incoming_txn_count_24h, incoming_amount_24h, outgoing_amount_24h,
                flow_through_ratio, network_degree, synthetic_report_count, category, risk_tier
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                b["beneficiary_id"],
                b["vpa"],
                b["name"],
                b.get("account_age_days"),
                int(b["customer_counterparties_30d"]),
                int(b["incoming_txn_count_24h"]),
                float(b["incoming_amount_24h"]),
                float(b["outgoing_amount_24h"]),
                float(b["flow_through_ratio"]),
                int(b["network_degree"]),
                int(b["synthetic_report_count"]),
                b["category"],
                b.get("risk_tier", "LOW"),
            ),
        )

    for q in CANONICAL_QUESTIONS_CATALOG:
        conn.execute(
            """
            INSERT OR IGNORE INTO questions (
                question_id, translations, audio_prompts, intent, triggered_reason_code, answer_options
            ) VALUES (?, ?, ?, ?, ?, ?)
            """,
            (
                q["question_id"],
                json.dumps(q["translations"]),
                json.dumps(q["audio_prompts"]),
                q["intent"],
                q["triggered_reason_code"],
                json.dumps(q["answer_options"]),
            ),
        )


def _seed_postgres(conn: Any) -> None:
    with conn.cursor() as cur:
        for c in list(registry.customers.values())[:25]:
            cur.execute(
                """
                INSERT INTO customers (
                    customer_id, name, preferred_language, profile_group,
                    baseline_txn_count_30d, baseline_amount_median, baseline_amount_mad,
                    usual_active_hours, occupation, age
                ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s::jsonb, %s, %s)
                ON CONFLICT (customer_id) DO NOTHING
                """,
                (
                    c["customer_id"],
                    c["name"],
                    c["preferred_language"],
                    c["profile_group"],
                    int(c["baseline_txn_count_30d"]),
                    float(c["baseline_amount_median"]),
                    float(c["baseline_amount_mad"]),
                    json.dumps(c["usual_active_hours"]),
                    c["occupation"],
                    int(c["age"]),
                ),
            )

        for b in list(registry.beneficiaries.values())[:25]:
            cur.execute(
                """
                INSERT INTO beneficiaries (
                    beneficiary_id, vpa, name, account_age_days, customer_counterparties_30d,
                    incoming_txn_count_24h, incoming_amount_24h, outgoing_amount_24h,
                    flow_through_ratio, network_degree, synthetic_report_count, category, risk_tier
                ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                ON CONFLICT (beneficiary_id) DO NOTHING
                """,
                (
                    b["beneficiary_id"],
                    b["vpa"],
                    b["name"],
                    b.get("account_age_days"),
                    int(b["customer_counterparties_30d"]),
                    int(b["incoming_txn_count_24h"]),
                    float(b["incoming_amount_24h"]),
                    float(b["outgoing_amount_24h"]),
                    float(b["flow_through_ratio"]),
                    int(b["network_degree"]),
                    int(b["synthetic_report_count"]),
                    b["category"],
                    b.get("risk_tier", "LOW"),
                ),
            )

        for q in CANONICAL_QUESTIONS_CATALOG:
            cur.execute(
                """
                INSERT INTO questions (
                    question_id, translations, audio_prompts, intent, triggered_reason_code, answer_options
                ) VALUES (%s, %s::jsonb, %s::jsonb, %s, %s, %s::jsonb)
                ON CONFLICT (question_id) DO NOTHING
                """,
                (
                    q["question_id"],
                    json.dumps(q["translations"]),
                    json.dumps(q["audio_prompts"]),
                    q["intent"],
                    q["triggered_reason_code"],
                    json.dumps(q["answer_options"]),
                ),
            )


def fetch_all(conn: Any, dialect: str, sql: str, params: tuple = ()) -> list[dict[str, Any]]:
    if dialect == "postgres":
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute(sql, params)
            return [dict(r) for r in cur.fetchall()]
    q_sql = sql.replace("%s", "?")
    cur = conn.execute(q_sql, params)
    return [dict(r) for r in cur.fetchall()]


def execute(conn: Any, dialect: str, sql: str, params: tuple = ()) -> None:
    if dialect == "postgres":
        with conn.cursor() as cur:
            cur.execute(sql, params)
    else:
        q_sql = sql.replace("%s", "?")
        conn.execute(q_sql, params)
