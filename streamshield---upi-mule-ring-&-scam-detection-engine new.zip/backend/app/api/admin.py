"""Admin, metrics, catalog, and offline evaluation endpoints (Blueprint Section 12.6-12.7)."""

from __future__ import annotations

from typing import Optional
from fastapi import APIRouter, Query

from ..db import models as repo
from ..models.model_loader import CANONICAL_QUESTIONS_CATALOG, registry

router = APIRouter(tags=["admin"])


@router.get("/admin/alerts")
def api_admin_alerts(
    risk_level: Optional[str] = Query(default=None),
    recommended_action: Optional[str] = Query(default=None),
    limit: int = Query(default=50, ge=1, le=200),
    offset: int = Query(default=0, ge=0),
):
    alerts = repo.list_admin_alerts(
        risk_level=risk_level,
        recommended_action=recommended_action,
        limit=limit,
        offset=offset,
    )
    return {"items": alerts, "count": len(alerts)}


@router.get("/admin/metrics")
def api_admin_metrics():
    return repo.get_admin_metrics()


@router.get("/evaluation/ablation")
def api_evaluation_ablation():
    if registry.evaluation_report is not None:
        return registry.evaluation_report
    return {"generated_at": None, "dataset_summary": None, "models": []}


@router.get("/catalog")
def api_catalog():
    canonical_custs = [
        c for cid, c in registry.customers.items() if cid in ("CUS_0001", "CUS_0002", "CUS_0003", "CUS_0004")
    ]
    canonical_bens = [
        b
        for bid, b in registry.beneficiaries.items()
        if bid in ("BEN_0101", "BEN_0102", "BEN_0601", "BEN_0602", "BEN_0603")
    ]
    return {
        "customers": canonical_custs,
        "beneficiaries": canonical_bens,
        "questions": CANONICAL_QUESTIONS_CATALOG,
    }
