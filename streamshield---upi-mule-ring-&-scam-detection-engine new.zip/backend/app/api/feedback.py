"""Feedback endpoint matching Blueprint Section 12.5."""

from __future__ import annotations

from typing import Optional
from fastapi import APIRouter, Header

from ..schemas.feedback import FeedbackRequest, FeedbackResponse
from ..services.feedback_service import submit_feedback

router = APIRouter(tags=["feedback"])


@router.post("/feedback", response_model=FeedbackResponse)
def api_submit_feedback(
    req: FeedbackRequest,
    x_user_uid: Optional[str] = Header(default=None, alias="X-User-Uid"),
):
    return submit_feedback(req, user_uid=x_user_uid)
