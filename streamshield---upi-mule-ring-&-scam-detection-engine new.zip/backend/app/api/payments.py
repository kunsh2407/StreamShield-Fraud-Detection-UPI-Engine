"""Payment endpoints matching Blueprint Section 12.1-12.4."""

from __future__ import annotations

from fastapi import APIRouter, Header
from typing import Optional

from ..db import models as repo
from ..schemas.payment import (
    DecisionRequest,
    DecisionResponse,
    DemoScoreRequest,
    DemoScoreResponse,
    InitiatePaymentRequest,
    InitiatePaymentResponse,
    SubmitAnswerRequest,
    SubmitAnswerResponse,
)
from ..services.payment_service import (
    DomainError,
    demo_stateless_score,
    initiate_payment,
    record_decision,
    submit_answer,
)

router = APIRouter(tags=["payments"])


@router.post("/payments/initiate", response_model=InitiatePaymentResponse)
def api_initiate_payment(
    req: InitiatePaymentRequest,
    x_user_uid: Optional[str] = Header(default=None, alias="X-User-Uid"),
):
    return initiate_payment(req, user_uid=x_user_uid)


@router.post("/payments/{payment_id}/answers", response_model=SubmitAnswerResponse)
def api_submit_answer(payment_id: str, req: SubmitAnswerRequest):
    return submit_answer(payment_id, req)


@router.get("/payments/{payment_id}")
def api_get_payment(payment_id: str):
    session = repo.get_payment_full(payment_id)
    if session is None:
        raise DomainError(404, "UNKNOWN_PAYMENT", f"Payment '{payment_id}' was not found.")
    return session


@router.post("/payments/{payment_id}/decision", response_model=DecisionResponse)
def api_record_decision(
    payment_id: str,
    req: DecisionRequest,
    x_user_uid: Optional[str] = Header(default=None, alias="X-User-Uid"),
):
    return record_decision(payment_id, req, actor=x_user_uid or "DEMO_USER")


@router.post("/demo/score", response_model=DemoScoreResponse)
def api_demo_score(req: DemoScoreRequest):
    return demo_stateless_score(req)


@router.get("/user/account")
def api_get_user_account(
    customer_id: Optional[str] = None,
    x_user_uid: Optional[str] = Header(default=None, alias="X-User-Uid"),
    x_user_role: Optional[str] = Header(default=None, alias="X-User-Role"),
    x_user_customer_id: Optional[str] = Header(default=None, alias="X-User-Customer-Id"),
):
    resolved_customer_id = (
        customer_id
        if x_user_role == "ADMIN" and customer_id
        else (x_user_customer_id or customer_id or "CUS_0002")
    )
    summary = repo.get_user_account_summary(resolved_customer_id, user_uid=x_user_uid)
    if summary is None:
        raise DomainError(404, "UNKNOWN_CUSTOMER", f"Customer '{resolved_customer_id}' was not found.")
    return summary
