"""Canonical Pydantic schemas for assessment, component scores, and reason codes."""

from __future__ import annotations

from enum import Enum
from typing import Optional
from pydantic import BaseModel, Field


class Language(str, Enum):
    en = "en"
    te = "te"
    hi = "hi"


class RiskLevel(str, Enum):
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"


class RecommendedAction(str, Enum):
    ALLOW = "ALLOW"
    INFORM = "INFORM"
    VERIFY = "VERIFY"
    SAFETY_PAUSE = "SAFETY_PAUSE"
    BANK_REVIEW = "BANK_REVIEW"


class CanonicalReasonCode(str, Enum):
    NEW_BENEFICIARY = "NEW_BENEFICIARY"
    AMOUNT_ABOVE_BASELINE = "AMOUNT_ABOVE_BASELINE"
    UNUSUAL_PAYMENT_TIME = "UNUSUAL_PAYMENT_TIME"
    HIGH_PAYMENT_VELOCITY = "HIGH_PAYMENT_VELOCITY"
    BENEFICIARY_HIGH_INFLOW_DIVERSITY = "BENEFICIARY_HIGH_INFLOW_DIVERSITY"
    BENEFICIARY_RAPID_OUTFLOW = "BENEFICIARY_RAPID_OUTFLOW"
    BENEFICIARY_NETWORK_LINKS = "BENEFICIARY_NETWORK_LINKS"
    URGENCY_REPORTED = "URGENCY_REPORTED"
    AUTHORITY_THREAT_REPORTED = "AUTHORITY_THREAT_REPORTED"
    SECRECY_REQUEST_REPORTED = "SECRECY_REQUEST_REPORTED"
    REMOTE_GUIDANCE_REPORTED = "REMOTE_GUIDANCE_REPORTED"
    IMPERSONATION_REPORTED = "IMPERSONATION_REPORTED"
    INSUFFICIENT_CONTEXT = "INSUFFICIENT_CONTEXT"


class ComponentScores(BaseModel):
    transaction_anomaly_score: int = Field(..., ge=0, le=100)
    beneficiary_risk_score: int = Field(..., ge=0, le=100)
    coercion_risk_score: Optional[int] = Field(None, ge=0, le=100)


class ComponentRisk(BaseModel):
    score: int = Field(..., ge=0, le=100)
    reason_codes: list[CanonicalReasonCode] = Field(default_factory=list)
    intelligence_source: str = "SYNTHETIC"


class RiskAssessment(BaseModel):
    overall_risk_score: int = Field(..., ge=0, le=100)
    risk_level: RiskLevel
    recommended_action: RecommendedAction
    component_scores: ComponentScores
    reason_codes: list[CanonicalReasonCode]
    explanations: list[str]
    requires_questions: bool
    is_simulated: bool = True
    scoring_latency_ms: float = 0.0
    model_version: str = "streamshield_rfde_v1.0"
    policy_version: str = "policy_v1.0"
