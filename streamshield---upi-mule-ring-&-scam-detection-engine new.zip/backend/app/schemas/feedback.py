"""Canonical Pydantic schemas for Feedback & Evaluation Service (FES)."""

from __future__ import annotations

from enum import Enum
from typing import Optional
from pydantic import BaseModel


class FeedbackOutcome(str, Enum):
    CONFIRMED_SCAM = "CONFIRMED_SCAM"
    CONFIRMED_LEGITIMATE = "CONFIRMED_LEGITIMATE"
    UNRESOLVED = "UNRESOLVED"
    USER_CANCELLED = "USER_CANCELLED"
    REFERRED_FOR_REVIEW = "REFERRED_FOR_REVIEW"


class FeedbackLabelSource(str, Enum):
    SYNTHETIC_SCENARIO = "SYNTHETIC_SCENARIO"
    DEMO_USER = "DEMO_USER"
    CUSTOMER = "CUSTOMER"
    REVIEWER = "REVIEWER"


class FeedbackRequest(BaseModel):
    payment_id: str
    outcome: FeedbackOutcome
    label_source: FeedbackLabelSource = FeedbackLabelSource.REVIEWER
    notes: Optional[str] = None


class FeedbackResponse(BaseModel):
    feedback_id: str
    saved: bool = True
    updated_status: Optional[str] = None
