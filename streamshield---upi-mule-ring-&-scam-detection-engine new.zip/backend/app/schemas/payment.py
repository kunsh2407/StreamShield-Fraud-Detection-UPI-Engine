"""Canonical Pydantic schemas for payment initiation, adaptive answers, and decisions."""

from __future__ import annotations

from enum import Enum
from typing import Literal, Optional
from pydantic import BaseModel, Field

from .assessment import Language, RiskAssessment


class PaymentStatus(str, Enum):
    ASSESSMENT_PENDING_CONTEXT = "ASSESSMENT_PENDING_CONTEXT"
    QUESTIONNAIRE_IN_PROGRESS = "QUESTIONNAIRE_IN_PROGRESS"
    ASSESSMENT_COMPLETE = "ASSESSMENT_COMPLETE"
    SIMULATION_CONTINUED = "SIMULATION_CONTINUED"
    SIMULATION_PAUSED = "SIMULATION_PAUSED"
    SIMULATION_CANCELLED = "SIMULATION_CANCELLED"
    REFERRED_FOR_REVIEW = "REFERRED_FOR_REVIEW"
    APPROVED_BY_BANK = "APPROVED_BY_BANK"
    TERMINATED_SCAM = "TERMINATED_SCAM"


class QuestionId(str, Enum):
    Q_URGENCY = "Q_URGENCY"
    Q_THREAT = "Q_THREAT"
    Q_SECRECY = "Q_SECRECY"
    Q_GUIDANCE = "Q_GUIDANCE"
    Q_IDENTITY = "Q_IDENTITY"
    Q_PURPOSE = "Q_PURPOSE"


class QuestionAnswer(str, Enum):
    YES = "YES"
    NO = "NO"
    NOT_SURE = "NOT_SURE"
    SKIP = "SKIP"
    NEED_HELP = "NEED_HELP"


class InputMode(str, Enum):
    TAP = "TAP"
    VOICE = "VOICE"
    TEXT = "TEXT"


class CustomerChoice(str, Enum):
    CONTINUE_SIMULATED = "CONTINUE_SIMULATED"
    PAUSE_AND_VERIFY = "PAUSE_AND_VERIFY"
    CANCEL_SIMULATED = "CANCEL_SIMULATED"
    REQUEST_BANK_REVIEW = "REQUEST_BANK_REVIEW"


class QuestionPrompt(BaseModel):
    question_id: QuestionId
    text: str
    translations: dict[str, str]
    audio_prompts: dict[str, str]
    answer_options: list[QuestionAnswer] = Field(
        default_factory=lambda: [
            QuestionAnswer.YES,
            QuestionAnswer.NO,
            QuestionAnswer.NOT_SURE,
            QuestionAnswer.SKIP,
            QuestionAnswer.NEED_HELP,
        ]
    )
    audio_available: bool = True


class AnswerRecord(BaseModel):
    question_id: QuestionId
    answer: QuestionAnswer
    input_mode: InputMode
    answered_at: str


class InitiatePaymentRequest(BaseModel):
    customer_id: str = Field(..., min_length=1)
    beneficiary_id: str = Field(..., min_length=1)
    amount: float = Field(..., gt=0, le=5_000_000)
    currency: Literal["INR"] = "INR"
    purpose: Optional[str] = "Payment transfer"
    language: Language = Language.en
    channel: Literal["WEB_SIMULATOR", "PHONE_APP", "LAPTOP_WEB"] = "WEB_SIMULATOR"
    custom_vpa: Optional[str] = None
    is_new_beneficiary: Optional[bool] = None


class InitiatePaymentResponse(BaseModel):
    payment_id: str
    status: PaymentStatus
    is_simulated: bool = True
    initial_assessment: RiskAssessment
    next_question: Optional[QuestionPrompt] = None


class SubmitAnswerRequest(BaseModel):
    question_id: QuestionId
    answer: QuestionAnswer
    input_mode: InputMode = InputMode.TAP


class SubmitAnswerResponse(BaseModel):
    payment_id: str
    questionnaire_status: Literal["IN_PROGRESS", "COMPLETED"]
    questions_answered: int
    max_questions: int = 3
    next_question: Optional[QuestionPrompt] = None
    final_assessment: Optional[RiskAssessment] = None


class DecisionRequest(BaseModel):
    customer_choice: CustomerChoice
    report_fraud: bool = False


class DecisionResponse(BaseModel):
    payment_id: str
    status: PaymentStatus
    is_simulated: bool = True
    message_key: str


class DemoScoreRequest(BaseModel):
    customer_id: str
    beneficiary_id: str
    amount: float = Field(..., gt=0, le=5_000_000)
    currency: Literal["INR"] = "INR"
    purpose: Optional[str] = "Payment transfer"
    language: Language = Language.en
    custom_vpa: Optional[str] = None
    answers: list[AnswerRecord] = Field(default_factory=list)


class DemoScoreResponse(BaseModel):
    payment_id: str
    status: PaymentStatus
    is_simulated: bool = True
    assessment: RiskAssessment
    next_question: Optional[QuestionPrompt] = None
    questions_answered: int
    max_questions: int = 3
