"""Payment session orchestration service (PS, TBE, BRE, CCE, AQS, RFDE)."""

from __future__ import annotations

import time
import uuid
from datetime import datetime, timezone
from typing import Any

from ..db import models as repo
from ..engines.adaptive_questions import select_next_question
from ..engines.beneficiary_risk import score_beneficiary
from ..engines.coercion_context import score_coercion
from ..engines.risk_fusion import fuse_risk
from ..engines.transaction_behaviour import score_transaction
from ..models.model_loader import registry
from ..schemas.payment import (
    CustomerChoice,
    DecisionRequest,
    DecisionResponse,
    DemoScoreRequest,
    DemoScoreResponse,
    InitiatePaymentRequest,
    InitiatePaymentResponse,
    PaymentStatus,
    SubmitAnswerRequest,
    SubmitAnswerResponse,
)


class DomainError(Exception):
    def __init__(self, status_code: int, code: str, message: str, details: dict[str, Any] | None = None):
        super().__init__(message)
        self.status_code = status_code
        self.code = code
        self.message = message
        self.details = details or {}


def _resolve_entities(
    customer_id: str,
    beneficiary_id: str,
    custom_vpa: str | None = None,
    use_db: bool = True,
) -> tuple[dict[str, Any], dict[str, Any] | None]:
    customer = repo.get_customer(customer_id) if use_db else None
    if customer is None:
        customer = registry.customers.get(customer_id)
    if customer is None:
        raise DomainError(404, "UNKNOWN_CUSTOMER", f"Customer '{customer_id}' was not found.")

    beneficiary = repo.get_beneficiary(beneficiary_id) if use_db else None
    if beneficiary is None:
        beneficiary = registry.beneficiaries.get(beneficiary_id)

    if beneficiary is None and beneficiary_id == "BEN_CUSTOM":
        beneficiary = {
            "beneficiary_id": "BEN_CUSTOM",
            "vpa": custom_vpa or "custom_recipient@upi",
            "name": f"Custom Recipient ({custom_vpa or 'Unverified VPA'})",
            "account_age_days": 10,
            "customer_counterparties_30d": 1,
            "incoming_txn_count_24h": 1,
            "incoming_amount_24h": 0.0,
            "outgoing_amount_24h": 0.0,
            "flow_through_ratio": 0.35,
            "network_degree": 1,
            "synthetic_report_count": 0,
            "category": "Custom Recipient",
            "risk_tier": "MEDIUM",
        }
    elif beneficiary is None:
        raise DomainError(404, "UNKNOWN_BENEFICIARY", f"Beneficiary '{beneficiary_id}' was not found.")

    return customer, beneficiary


def initiate_payment(req: InitiatePaymentRequest, user_uid: str | None = None) -> InitiatePaymentResponse:
    t0 = time.perf_counter()
    customer, beneficiary = _resolve_entities(req.customer_id, req.beneficiary_id, req.custom_vpa, use_db=True)

    is_new_ben = (
        req.is_new_beneficiary
        if req.is_new_beneficiary is not None
        else (not req.beneficiary_id.startswith("BEN_01"))
    )

    payment_input = {
        "amount": req.amount,
        "currency": req.currency,
        "purpose": req.purpose,
        "is_new_beneficiary": is_new_ben,
        "txn_hour": datetime.now(timezone.utc).hour,
        "recent_txn_count_1h": 1,
        "recent_cancelled_count_24h": 0,
    }

    tbe_res = score_transaction(payment_input, customer)
    bre_res = score_beneficiary(beneficiary)
    elapsed_ms = (time.perf_counter() - t0) * 1000.0

    initial_assessment = fuse_risk(
        tbe_res,
        bre_res,
        None,
        req.language,
        payment=payment_input,
        customer=customer,
        beneficiary=beneficiary,
        is_initial_stage=True,
        latency_ms=elapsed_ms,
    )

    next_q = (
        select_next_question(tbe_res.score, bre_res.score, [], req.language, max_questions=3)
        if initial_assessment.requires_questions
        else None
    )

    status = (
        PaymentStatus.ASSESSMENT_PENDING_CONTEXT
        if next_q is not None
        else PaymentStatus.ASSESSMENT_COMPLETE
    )
    payment_id = f"PAY_{uuid.uuid4().hex[:10].upper()}"

    repo.create_payment_record(
        payment_id=payment_id,
        user_uid=user_uid,
        customer_id=req.customer_id,
        beneficiary_id=req.beneficiary_id if req.beneficiary_id in registry.beneficiaries else "BEN_0601",
        amount=req.amount,
        purpose=req.purpose,
        language=req.language.value,
        channel=req.channel,
        status=status.value,
        is_new_beneficiary=is_new_ben,
    )
    repo.save_assessment_record(payment_id, "INITIAL", initial_assessment.model_dump(mode="json"))
    if next_q is None:
        repo.save_assessment_record(payment_id, "FINAL", initial_assessment.model_dump(mode="json"))
    repo.log_audit_event(
        payment_id,
        "PAYMENT_INITIATED",
        user_uid or "SIMULATOR",
        {"status": status.value, "initial_score": initial_assessment.overall_risk_score},
    )

    return InitiatePaymentResponse(
        payment_id=payment_id,
        status=status,
        is_simulated=True,
        initial_assessment=initial_assessment,
        next_question=next_q,
    )


def submit_answer(payment_id: str, req: SubmitAnswerRequest) -> SubmitAnswerResponse:
    t0 = time.perf_counter()
    session = repo.get_payment_full(payment_id)
    if session is None:
        raise DomainError(404, "UNKNOWN_PAYMENT", f"Payment '{payment_id}' was not found.")

    repo.save_answer_record(payment_id, req.question_id.value, req.answer.value, req.input_mode.value)
    updated_answers = list(session["answers"]) + [
        {
            "question_id": req.question_id.value,
            "answer": req.answer.value,
            "input_mode": req.input_mode.value,
        }
    ]

    customer, beneficiary = _resolve_entities(session["customer_id"], session["beneficiary_id"], use_db=True)
    is_new_ben = not session["beneficiary_id"].startswith("BEN_01")
    payment_input = {
        "amount": session["amount"],
        "is_new_beneficiary": is_new_ben,
        "txn_hour": datetime.now(timezone.utc).hour,
        "recent_txn_count_1h": 1,
        "recent_cancelled_count_24h": 0,
    }

    tbe_res = score_transaction(payment_input, customer)
    bre_res = score_beneficiary(beneficiary)
    cce_res = score_coercion(updated_answers)

    from ..schemas.assessment import Language

    lang = Language(session["language"])
    next_q = select_next_question(tbe_res.score, bre_res.score, updated_answers, lang, max_questions=3)

    if next_q is not None:
        repo.update_payment_status(payment_id, PaymentStatus.QUESTIONNAIRE_IN_PROGRESS.value)
        return SubmitAnswerResponse(
            payment_id=payment_id,
            questionnaire_status="IN_PROGRESS",
            questions_answered=len(updated_answers),
            max_questions=3,
            next_question=next_q,
            final_assessment=None,
        )

    elapsed_ms = (time.perf_counter() - t0) * 1000.0
    final_assessment = fuse_risk(
        tbe_res,
        bre_res,
        cce_res,
        lang,
        payment=payment_input,
        customer=customer,
        beneficiary=beneficiary,
        answers=updated_answers,
        is_initial_stage=False,
        latency_ms=elapsed_ms,
    )
    repo.update_payment_status(payment_id, PaymentStatus.ASSESSMENT_COMPLETE.value)
    repo.save_assessment_record(payment_id, "FINAL", final_assessment.model_dump(mode="json"))
    repo.log_audit_event(
        payment_id,
        "ASSESSMENT_COMPLETED",
        "RFDE",
        {"overall_risk_score": final_assessment.overall_risk_score, "action": final_assessment.recommended_action.value},
    )

    return SubmitAnswerResponse(
        payment_id=payment_id,
        questionnaire_status="COMPLETED",
        questions_answered=len(updated_answers),
        max_questions=3,
        next_question=None,
        final_assessment=final_assessment,
    )


def record_decision(payment_id: str, req: DecisionRequest, actor: str = "DEMO_USER") -> DecisionResponse:
    session = repo.get_payment_full(payment_id)
    if session is None:
        raise DomainError(404, "UNKNOWN_PAYMENT", f"Payment '{payment_id}' was not found.")

    choice_map = {
        CustomerChoice.CONTINUE_SIMULATED: (PaymentStatus.SIMULATION_CONTINUED, "decision.continue_confirmed"),
        CustomerChoice.PAUSE_AND_VERIFY: (PaymentStatus.SIMULATION_PAUSED, "decision.pause_confirmed"),
        CustomerChoice.CANCEL_SIMULATED: (PaymentStatus.SIMULATION_CANCELLED, "decision.cancel_confirmed"),
        CustomerChoice.REQUEST_BANK_REVIEW: (PaymentStatus.REFERRED_FOR_REVIEW, "decision.review_requested"),
    }
    new_status, message_key = choice_map[req.customer_choice]
    repo.update_payment_status(payment_id, new_status.value, req.customer_choice.value)
    if req.customer_choice == CustomerChoice.CANCEL_SIMULATED and req.report_fraud:
        repo.save_feedback_record(
            payment_id=payment_id,
            user_uid=None,
            outcome="CONFIRMED_SCAM",
            label_source="CUSTOMER",
            notes="Customer cancelled payment and reported suspected scam.",
        )
        repo.log_audit_event(
            payment_id,
            "USER_SCAM_REPORTED",
            actor,
            {"customer_choice": req.customer_choice.value, "status": new_status.value},
        )
        message_key = "decision.cancel_and_reported"

    repo.log_audit_event(
        payment_id,
        "CUSTOMER_DECISION_RECORDED",
        actor,
        {"customer_choice": req.customer_choice.value, "status": new_status.value, "report_fraud": req.report_fraud},
    )

    return DecisionResponse(
        payment_id=payment_id,
        status=new_status,
        is_simulated=True,
        message_key=message_key,
    )


def demo_stateless_score(req: DemoScoreRequest) -> DemoScoreResponse:
    """Stateless FastAPI ML assessment for unauthenticated simulator preview (no DB write)."""
    t0 = time.perf_counter()
    customer, beneficiary = _resolve_entities(req.customer_id, req.beneficiary_id, req.custom_vpa, use_db=False)
    is_new_ben = not req.beneficiary_id.startswith("BEN_01")

    payment_input = {
        "amount": req.amount,
        "currency": req.currency,
        "purpose": req.purpose,
        "is_new_beneficiary": is_new_ben,
        "txn_hour": datetime.now(timezone.utc).hour,
        "recent_txn_count_1h": 1,
        "recent_cancelled_count_24h": 0,
    }

    tbe_res = score_transaction(payment_input, customer)
    bre_res = score_beneficiary(beneficiary)

    answer_dicts = [a.model_dump(mode="json") for a in req.answers]
    cce_res = score_coercion(answer_dicts) if answer_dicts else None

    if not answer_dicts:
        initial = fuse_risk(
            tbe_res,
            bre_res,
            None,
            req.language,
            payment=payment_input,
            customer=customer,
            beneficiary=beneficiary,
            is_initial_stage=True,
            latency_ms=(time.perf_counter() - t0) * 1000.0,
        )
        next_q = (
            select_next_question(tbe_res.score, bre_res.score, [], req.language, max_questions=3)
            if initial.requires_questions
            else None
        )
        status = (
            PaymentStatus.ASSESSMENT_PENDING_CONTEXT
            if next_q is not None
            else PaymentStatus.ASSESSMENT_COMPLETE
        )
        return DemoScoreResponse(
            payment_id=f"DEMO_{uuid.uuid4().hex[:8].upper()}",
            status=status,
            is_simulated=True,
            assessment=initial,
            next_question=next_q,
            questions_answered=0,
        )

    next_q = select_next_question(tbe_res.score, bre_res.score, answer_dicts, req.language, max_questions=3)
    elapsed_ms = (time.perf_counter() - t0) * 1000.0
    assessment = fuse_risk(
        tbe_res,
        bre_res,
        cce_res,
        req.language,
        payment=payment_input,
        customer=customer,
        beneficiary=beneficiary,
        answers=answer_dicts,
        is_initial_stage=next_q is not None,
        latency_ms=elapsed_ms,
    )
    return DemoScoreResponse(
        payment_id=f"DEMO_{uuid.uuid4().hex[:8].upper()}",
        status=PaymentStatus.QUESTIONNAIRE_IN_PROGRESS if next_q else PaymentStatus.ASSESSMENT_COMPLETE,
        is_simulated=True,
        assessment=assessment,
        next_question=next_q,
        questions_answered=len(answer_dicts),
    )
