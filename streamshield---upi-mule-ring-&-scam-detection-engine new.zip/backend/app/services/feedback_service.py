"""Feedback & Evaluation Service (FES) — Blueprint Section 5.8."""

from __future__ import annotations

from ..db import models as repo
from ..schemas.feedback import FeedbackOutcome, FeedbackRequest, FeedbackResponse
from .payment_service import DomainError


def submit_feedback(req: FeedbackRequest, user_uid: str | None = None) -> FeedbackResponse:
    session = repo.get_payment_full(req.payment_id)
    if session is None:
        raise DomainError(404, "UNKNOWN_PAYMENT", f"Payment '{req.payment_id}' was not found.")

    feedback_id = repo.save_feedback_record(
        payment_id=req.payment_id,
        user_uid=user_uid,
        outcome=req.outcome.value,
        label_source=req.label_source.value,
        notes=req.notes,
    )

    updated_status: str | None = None
    if session["status"] == "REFERRED_FOR_REVIEW":
        if req.outcome == FeedbackOutcome.CONFIRMED_LEGITIMATE:
            updated_status = "APPROVED_BY_BANK"
            repo.update_payment_status(req.payment_id, updated_status)
            repo.log_audit_event(
                req.payment_id,
                "BANK_REVIEW_APPROVED",
                user_uid or req.label_source.value,
                {"feedback_id": feedback_id, "updated_status": updated_status},
            )
        elif req.outcome == FeedbackOutcome.CONFIRMED_SCAM:
            updated_status = "TERMINATED_SCAM"
            repo.update_payment_status(req.payment_id, updated_status)
            repo.log_audit_event(
                req.payment_id,
                "BANK_REVIEW_TERMINATED",
                user_uid or req.label_source.value,
                {"feedback_id": feedback_id, "updated_status": updated_status},
            )

    repo.log_audit_event(
        req.payment_id,
        "FEEDBACK_RECORDED",
        user_uid or req.label_source.value,
        {"feedback_id": feedback_id, "outcome": req.outcome.value, "updated_status": updated_status},
    )
    return FeedbackResponse(feedback_id=feedback_id, saved=True, updated_status=updated_status)
