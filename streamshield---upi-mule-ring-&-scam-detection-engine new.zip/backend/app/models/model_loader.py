"""Model and synthetic catalog loader for StreamShield backend."""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any
import joblib
import pandas as pd

from ..config import ARTIFACTS_DIR, BASE_DIR, DATA_DIR

# Ensure ml/feature_engineering can be imported cleanly
ML_DIR = BASE_DIR / "ml"
if str(ML_DIR) not in sys.path:
    sys.path.insert(0, str(ML_DIR))

from feature_engineering import (  # noqa: E402
    extract_bre_features,
    extract_cce_features,
    extract_tbe_features,
)

CANONICAL_QUESTIONS_CATALOG: list[dict[str, Any]] = [
    {
        "question_id": "Q_URGENCY",
        "translations": {
            "en": "Is someone asking you to send this money immediately?",
            "te": "ఈ డబ్బును వెంటనే పంపమని ఎవరైనా మిమ్మల్ని ఒత్తిడి చేస్తున్నారా?",
            "hi": "क्या कोई आपसे यह पैसा तुरंत भेजने के लिए कह रहा है?",
        },
        "audio_prompts": {
            "en": "Is someone asking you to send this money immediately?",
            "te": "Ee dabbu ventaney pampamani evarainaa mimmalni ottidi chestunnaaraa?",
            "hi": "Kya koi aapse yeh paisa turant bhejney ke liye keh raha hai?",
        },
        "intent": "Detect urgency and panic induction in social engineering scams",
        "triggered_reason_code": "URGENCY_REPORTED",
        "answer_options": ["YES", "NO", "NOT_SURE", "SKIP", "NEED_HELP"],
    },
    {
        "question_id": "Q_THREAT",
        "translations": {
            "en": "Has anyone threatened to arrest you, fine you, or block your account if you do not pay?",
            "te": "డబ్బు చెల్లించకపోతే మిమ్మల్ని అరెస్ట్ చేస్తామని, జరిమానా వేస్తామని లేదా బ్యాంక్ ఖాతా బ్లాక్ చేస్తామని ఎవరైనా బెదిరించారా?",
            "hi": "क्या भुगतान न करने पर किसी ने आपको गिरफ्तार करने, जुर्माना लगाने या खाता ब्लॉक करने की धमकी दी है?",
        },
        "audio_prompts": {
            "en": "Has anyone threatened to arrest you, fine you, or block your account if you do not pay?",
            "te": "Dabbu chellinchakapothe mimmalni arrest chestamani, jarimaana vesthamani, leda bank account block chestamani evarainaa bedirinchaaraa?",
            "hi": "Kya bhugtaan na karney par kisi ne aapko giraftaar karney, jurmaana lagaaney ya khaata block karney ki dhamki di hai?",
        },
        "intent": "Detect authority threat or digital-arrest coercion",
        "triggered_reason_code": "AUTHORITY_THREAT_REPORTED",
        "answer_options": ["YES", "NO", "NOT_SURE", "SKIP", "NEED_HELP"],
    },
    {
        "question_id": "Q_SECRECY",
        "translations": {
            "en": "Has anyone told you not to tell your family, bank, or anyone else about this payment?",
            "te": "ఈ చెల్లింపు గురించి కుటుంబ సభ్యులకు, బ్యాంకుకు లేదా మరెవరికీ చెప్పవద్దని ఎవరైనా చెప్పారా?",
            "hi": "क्या किसी ने आपसे कहा है कि इस भुगतान के बारे में परिवार, बैंक या किसी अन्य को न बताएं?",
        },
        "audio_prompts": {
            "en": "Has anyone told you not to tell your family, bank, or anyone else about this payment?",
            "te": "Ee payment gurinchi kutumbam vaariki, bank ku leda evarikee cheppavaddhani evarainaa cheppaaraa?",
            "hi": "Kya kisi ne aapse kaha hai ki is payment ke baarey mein parivaar, bank ya kisi aur ko na batayein?",
        },
        "intent": "Detect victim isolation and secrecy demands",
        "triggered_reason_code": "SECRECY_REQUEST_REPORTED",
        "answer_options": ["YES", "NO", "NOT_SURE", "SKIP", "NEED_HELP"],
    },
    {
        "question_id": "Q_GUIDANCE",
        "translations": {
            "en": "Is someone staying on a call or guiding you step by step while you make this payment?",
            "te": "మీరు ఈ చెల్లింపు చేస్తున్నప్పుడు ఎవరైనా ఫోన్ కాల్‌లో ఉండి లేదా అంచెలవారీగా నిర్దేశిస్తున్నారా?",
            "hi": "क्या इस भुगतान को करते समय कोई कॉल पर बना हुआ है या आपको कदम-दर-कदम निर्देश दे रहा है?",
        },
        "audio_prompts": {
            "en": "Is someone staying on a call or guiding you step by step while you make this payment?",
            "te": "Meeru ee payment chesthunnappudu evarainaa call lo undi step by step chepthunnaaraa?",
            "hi": "Kya is bhugtaan ko karte samay koi call par bana hua hai ya aapko step-by-step bata raha hai?",
        },
        "intent": "Detect remote assistance / live coaching pressure",
        "triggered_reason_code": "REMOTE_GUIDANCE_REPORTED",
        "answer_options": ["YES", "NO", "NOT_SURE", "SKIP", "NEED_HELP"],
    },
    {
        "question_id": "Q_IDENTITY",
        "translations": {
            "en": "Is the person claiming to be from the police, bank, government, or another organisation?",
            "te": "ఆ వ్యక్తి పోలీస్, బ్యాంక్, ప్రభుత్వం లేదా మరేదైనా అధికారిక సంస్థ నుండి మాట్లాడుతున్నట్లు పేర్కొంటున్నారా?",
            "hi": "क्या वह व्यक्ति पुलिस, बैंक, सरकार या किसी अन्य संस्था से होने का दावा कर रहा है?",
        },
        "audio_prompts": {
            "en": "Is the person claiming to be from the police, bank, government, or another organisation?",
            "te": "Aa vyakthi police, bank, prabhutvam nundi maatludutunnattu chebutunnaaraa?",
            "hi": "Kya vah vyakti police, bank, sarkaar ya kisi anya sanstha se honey ka daawa kar raha hai?",
        },
        "intent": "Detect impersonation of law enforcement or bank officials",
        "triggered_reason_code": "IMPERSONATION_REPORTED",
        "answer_options": ["YES", "NO", "NOT_SURE", "SKIP", "NEED_HELP"],
    },
    {
        "question_id": "Q_PURPOSE",
        "translations": {
            "en": "Do you personally know why this person needs the money?",
            "te": "ఈ వ్యక్తికి డబ్బు ఎందుకు అవసరమో మీకు వ్యక్తిగతంగా తెలుసా?",
            "hi": "क्या आप व्यक्तिगत रूप से जानते हैं कि इस व्यक्ति को पैसे की आवश्यकता क्यों है?",
        },
        "audio_prompts": {
            "en": "Do you personally know why this person needs the money?",
            "te": "Ee vyakthiki dabbu enduku avasaramo meeku vyakthigathangaa thelusaa?",
            "hi": "Kya aap vyaktigat roop se jaantey hain ki is vyakti ko paisey ki zaroorat kyon hai?",
        },
        "intent": "Validate purpose clarity and detect vague pretext stories",
        "triggered_reason_code": "INSUFFICIENT_CONTEXT",
        "answer_options": ["YES", "NO", "NOT_SURE", "SKIP", "NEED_HELP"],
    },
]


class ModelRegistry:
    """Singleton loader for trained scikit-learn artifacts and CSV synthetic baselines."""

    def __init__(self) -> None:
        self.tbe_bundle: dict[str, Any] | None = None
        self.bre_bundle: dict[str, Any] | None = None
        self.fusion_c_bundle: dict[str, Any] | None = None
        self.evaluation_report: dict[str, Any] | None = None
        self.customers: dict[str, dict[str, Any]] = {}
        self.beneficiaries: dict[str, dict[str, Any]] = {}
        self.questions_by_id: dict[str, dict[str, Any]] = {
            q["question_id"]: q for q in CANONICAL_QUESTIONS_CATALOG
        }
        self.load()

    def load(self) -> None:
        tbe_path = ARTIFACTS_DIR / "tbe_model.joblib"
        bre_path = ARTIFACTS_DIR / "bre_model.joblib"
        fusion_path = ARTIFACTS_DIR / "model_c.joblib"
        eval_path = ARTIFACTS_DIR / "evaluation_metrics.json"

        if tbe_path.exists():
            self.tbe_bundle = joblib.load(tbe_path)
        if bre_path.exists():
            self.bre_bundle = joblib.load(bre_path)
        if fusion_path.exists():
            self.fusion_c_bundle = joblib.load(fusion_path)
        if eval_path.exists():
            self.evaluation_report = json.loads(eval_path.read_text(encoding="utf-8"))

        cust_csv = DATA_DIR / "customers.csv"
        if cust_csv.exists():
            df = pd.read_csv(cust_csv)
            for row in df.to_dict("records"):
                row["usual_active_hours"] = (
                    json.loads(row["usual_active_hours"])
                    if isinstance(row["usual_active_hours"], str)
                    else row["usual_active_hours"]
                )
                self.customers[row["customer_id"]] = row

        ben_csv = DATA_DIR / "beneficiaries.csv"
        if ben_csv.exists():
            df = pd.read_csv(ben_csv)
            for row in df.to_dict("records"):
                if pd.isna(row.get("account_age_days")):
                    row["account_age_days"] = None
                else:
                    row["account_age_days"] = int(row["account_age_days"])
                self.beneficiaries[row["beneficiary_id"]] = row


registry = ModelRegistry()

__all__ = [
    "CANONICAL_QUESTIONS_CATALOG",
    "ModelRegistry",
    "extract_bre_features",
    "extract_cce_features",
    "extract_tbe_features",
    "registry",
]
