"""Backend configuration for StreamShield FastAPI service."""

from __future__ import annotations

import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent.parent
DATA_DIR = BASE_DIR / "data"
ARTIFACTS_DIR = BASE_DIR / "ml" / "artifacts"

MODEL_VERSION = "streamshield_rfde_v1.0"
POLICY_VERSION = "policy_v1.0"

SQL_HOST = os.environ.get("SQL_HOST", "").strip()
SQL_USER = os.environ.get("SQL_USER", "").strip()
SQL_PASSWORD = os.environ.get("SQL_PASSWORD", "").strip()
SQL_DB_NAME = os.environ.get("SQL_DB_NAME", "").strip()

FASTAPI_PORT = int(os.environ.get("FASTAPI_PORT", "8001"))
