"""StreamShield FastAPI application entrypoint (Blueprint Section 11, 12, 15)."""

from __future__ import annotations

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from .api import admin, feedback, payments
from .config import MODEL_VERSION, POLICY_VERSION
from .db.database import ensure_initialized
from .models.model_loader import registry
from .services.payment_service import DomainError

app = FastAPI(
    title="StreamShield API",
    version="1.0.0",
    description="Proposed bank-integrated payment protection prototype using synthetic data (no real money or RBI/UPI connection).",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.exception_handler(DomainError)
async def domain_error_handler(_request: Request, exc: DomainError):
    return JSONResponse(
        status_code=exc.status_code,
        content={
            "error": {
                "code": exc.code,
                "message": exc.message,
                "details": exc.details,
            }
        },
    )


@app.exception_handler(RequestValidationError)
async def validation_error_handler(_request: Request, exc: RequestValidationError):
    return JSONResponse(
        status_code=422,
        content={
            "error": {
                "code": "VALIDATION_ERROR",
                "message": "Request validation failed.",
                "details": {"errors": exc.errors()},
            }
        },
    )


@app.exception_handler(Exception)
async def generic_error_handler(_request: Request, _exc: Exception):
    return JSONResponse(
        status_code=500,
        content={
            "error": {
                "code": "INTERNAL_SERVER_ERROR",
                "message": "An unexpected server error occurred.",
                "details": {},
            }
        },
    )


@app.get("/api/v1/health")
def health_check():
    return {
        "status": "ok",
        "is_simulated": True,
        "model_version": MODEL_VERSION,
        "policy_version": POLICY_VERSION,
        "models_loaded": {
            "tbe": registry.tbe_bundle is not None,
            "bre": registry.bre_bundle is not None,
            "fusion_c": registry.fusion_c_bundle is not None,
            "evaluation_report": registry.evaluation_report is not None,
        },
    }


app.include_router(payments.router, prefix="/api/v1")
app.include_router(feedback.router, prefix="/api/v1")
app.include_router(admin.router, prefix="/api/v1")
