"""Risk Fusion & Decision Engine (RFDE) — Blueprint Section 5.6, 6, and 16.2.

Combines TBE, BRE, and CCE component scores using the trained Model C fusion pipeline
(with deterministic rule fallback) and separates model index from policy thresholds.
"""

from __future__ import annotations

from typing import Any, Mapping, Sequence
import numpy as np

from ..config import MODEL_VERSION, POLICY_VERSION
from ..models.model_loader import (
    extract_bre_features,
    extract_cce_features,
    extract_tbe_features,
    registry,
)
from ..schemas.assessment import (
    CanonicalReasonCode,
    ComponentRisk,
    ComponentScores,
    Language,
    RecommendedAction,
    RiskAssessment,
    RiskLevel,
)


def _localized_explanations(
    risk_level: RiskLevel,
    reason_codes: list[CanonicalReasonCode],
    language: Language,
) -> list[str]:
    lang = language.value
    explanations: list[str] = []

    if risk_level == RiskLevel.LOW:
        msg = {
            "en": "No major warning signs were found. Check the recipient name before continuing.",
            "te": "ప్రధాన హెచ్చరిక సంకేతాలు ఏవీ కనిపించలేదు. కొనసాగే ముందు స్వీకర్త పేరును సరిచూసుకోండి.",
            "hi": "कोई बड़े चेतावनी संकेत नहीं मिले। आगे बढ़ने से पहले प्राप्तकर्ता का नाम जाँच लें।",
        }
        return [msg.get(lang, msg["en"])]

    if risk_level == RiskLevel.MEDIUM:
        msg = {
            "en": "This payment is different from your usual activity. Do you know and trust this person?",
            "te": "ఈ చెల్లింపు మీ సాధారణ లావాదేవీలకు భిన్నంగా ఉంది. ఈ వ్యక్తిని మీరు వ్యక్తిగతంగా నమ్ముతున్నారా?",
            "hi": "यह भुगतान आपकी सामान्य गतिविधि से अलग है। क्या आप इस व्यक्ति को व्यक्तिगत रूप से जानते और भरोसा करते हैं?",
        }
        explanations.append(msg.get(lang, msg["en"]))

    if risk_level == RiskLevel.HIGH:
        msg = {
            "en": "Someone may be pressuring you to send this money. Please pause. Do not rely on a phone call or message to verify the request.",
            "te": "ఈ డబ్బు పంపమని ఎవరైనా మిమ్మల్ని ఒత్తిడి చేస్తున్నట్లు సంకేతాలు ఉన్నాయి. దయచేసి ఆగండి. ఫోన్ కాల్ ఆధారంగా వెంటనే డబ్బు పంపకండి.",
            "hi": "संभव है कि कोई आप पर यह पैसा भेजने का दबाव डाल रहा हो। कृपया रुकें और फोन कॉल पर भरोसा करके तुरंत भुगतान न करें।",
        }
        explanations.append(msg.get(lang, msg["en"]))

    if CanonicalReasonCode.AUTHORITY_THREAT_REPORTED in reason_codes:
        msg = {
            "en": "Government officials, police, and banks never demand immediate money transfers over phone calls to avoid arrest.",
            "te": "పోలీసులు, బ్యాంకులు లేదా ప్రభుత్వ అధికారులు అరెస్టు నుండి తప్పించుకోవడానికి ఫోన్ కాల్‌లో డబ్బు పంపమని ఎప్పటికీ అడగరు.",
            "hi": "पुलिस, बैंक या सरकारी अधिकारी गिरफ्तारी से बचने के लिए फोन कॉल पर कभी तुरंत पैसे भेजने को नहीं कहते।",
        }
        explanations.append(msg.get(lang, msg["en"]))

    if CanonicalReasonCode.BENEFICIARY_RAPID_OUTFLOW in reason_codes or CanonicalReasonCode.BENEFICIARY_NETWORK_LINKS in reason_codes:
        msg = {
            "en": "The recipient account shows unusual transfer indicators in synthetic checks and needs independent verification.",
            "te": "స్వీకర్త ఖాతాలో అసాధారణ లావాదేవీ సంకేతాలు కనిపిస్తున్నాయి; స్వతంత్రంగా ధృవీకరించుకోవడం మంచిది.",
            "hi": "प्राप्तकर्ता खाते में असामान्य लेन-देन संकेत दिखे हैं; आगे बढ़ने से पहले स्वतंत्र रूप से जाँच करें।",
        }
        explanations.append(msg.get(lang, msg["en"]))

    if risk_level == RiskLevel.HIGH:
        guidance = {
            "en": "End the call if safe. Contact your bank using the official number on your card or trusted family member.",
            "te": "మీకు సురక్షితంగా ఉంటే ఫోన్ కాల్ కట్ చేయండి. మీ బ్యాంక్ కార్డుపై ఉన్న అధికారిక నంబర్‌కు లేదా కుటుంబ సభ్యులకు కాల్ చేయండి.",
            "hi": "सुरक्षित होने पर कॉल काट दें। अपने बैंक के आधिकारिक नंबर पर कॉल करें या परिवार के किसी विश्वसनीय व्यक्ति से बात करें।",
        }
        explanations.append(guidance.get(lang, guidance["en"]))

    return explanations


def fuse_risk(
    tbe: ComponentRisk,
    bre: ComponentRisk,
    cce: ComponentRisk | None,
    language: Language,
    payment: Mapping[str, Any] | None = None,
    customer: Mapping[str, Any] | None = None,
    beneficiary: Mapping[str, Any] | None = None,
    answers: Sequence[Mapping[str, Any]] | None = None,
    is_initial_stage: bool = False,
    latency_ms: float = 0.0,
) -> RiskAssessment:
    """Fuse TBE, BRE, and optional CCE into overall score, risk level, and recommended action."""
    tbe_s = tbe.score
    bre_s = bre.score
    cce_s = cce.score if cce is not None else None

    all_reasons = list(
        dict.fromkeys(
            list(tbe.reason_codes)
            + list(bre.reason_codes)
            + (list(cce.reason_codes) if cce is not None else [])
        )
    )

    # Combine trained fusion ML probability (when all entities available) with calibrated rule synthesis
    if cce_s is None:
        base_index = 0.52 * tbe_s + 0.48 * bre_s
        if tbe_s >= 55 and bre_s >= 55:
            base_index = max(base_index, 60.0)
        overall_score = int(round(max(0.0, min(100.0, base_index))))
    else:
        rule_fusion = 0.24 * tbe_s + 0.28 * bre_s + 0.56 * cce_s
        if cce_s >= 70 or (cce_s >= 45 and bre_s >= 55):
            rule_fusion = max(rule_fusion, 78.0)

        if registry.fusion_c_bundle is not None and payment and customer and beneficiary:
            x_tbe = extract_tbe_features(payment, customer)
            x_bre = extract_bre_features(beneficiary)
            x_cce = extract_cce_features(answers or [])
            X = np.asarray([x_tbe + x_bre + x_cce], dtype=np.float64)
            ml_prob = float(registry.fusion_c_bundle["model"].predict_proba(X)[0, 1])
            overall_score = int(round(max(0.0, min(100.0, 0.55 * (ml_prob * 100.0) + 0.45 * rule_fusion))))
        else:
            overall_score = int(round(max(0.0, min(100.0, rule_fusion))))

    # Risk level thresholds (Blueprint Section 6.2)
    if overall_score >= 65:
        risk_level = RiskLevel.HIGH
    elif overall_score >= 30:
        risk_level = RiskLevel.MEDIUM
    else:
        risk_level = RiskLevel.LOW

    # Action policy separated from scoring model (Blueprint Section 6.3)
    if is_initial_stage:
        requires_questions = overall_score >= 30 or tbe_s >= 35 or bre_s >= 40
        if risk_level == RiskLevel.LOW:
            action = RecommendedAction.ALLOW
        elif risk_level == RiskLevel.HIGH and not requires_questions:
            action = RecommendedAction.SAFETY_PAUSE
        else:
            action = RecommendedAction.VERIFY
    else:
        requires_questions = False
        if overall_score >= 88 and bre_s >= 65 and (cce_s or 0) >= 65:
            action = RecommendedAction.SAFETY_PAUSE
        elif risk_level == RiskLevel.HIGH:
            action = RecommendedAction.SAFETY_PAUSE
        elif risk_level == RiskLevel.MEDIUM:
            action = RecommendedAction.VERIFY if bre_s >= 45 or tbe_s >= 45 else RecommendedAction.INFORM
        else:
            action = RecommendedAction.ALLOW

    explanations = _localized_explanations(risk_level, all_reasons, language)

    return RiskAssessment(
        overall_risk_score=overall_score,
        risk_level=risk_level,
        recommended_action=action,
        component_scores=ComponentScores(
            transaction_anomaly_score=tbe_s,
            beneficiary_risk_score=bre_s,
            coercion_risk_score=cce_s,
        ),
        reason_codes=all_reasons,
        explanations=explanations,
        requires_questions=requires_questions,
        is_simulated=True,
        scoring_latency_ms=round(latency_ms, 2),
        model_version=MODEL_VERSION,
        policy_version=POLICY_VERSION,
    )
