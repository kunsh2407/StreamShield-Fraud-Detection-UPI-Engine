"""Beneficiary Risk Engine (BRE) — Blueprint Section 5.3 & 16.2.

Estimates recipient mule-like patterns using synthetic beneficiary & graph features.
"""

from __future__ import annotations

from typing import Any, Mapping
import numpy as np

from ..models.model_loader import extract_bre_features, registry
from ..schemas.assessment import CanonicalReasonCode, ComponentRisk


def score_beneficiary(
    beneficiary: Mapping[str, Any] | None,
    network_features: Mapping[str, Any] | None = None,
) -> ComponentRisk:
    """Compute 0-100 synthetic beneficiary risk score and canonical BRE reason codes."""
    if beneficiary is None:
        return ComponentRisk(
            score=40,
            reason_codes=[CanonicalReasonCode.INSUFFICIENT_CONTEXT],
            intelligence_source="SYNTHETIC",
        )

    merged_ben = dict(beneficiary)
    if network_features:
        merged_ben.update(network_features)

    feats = extract_bre_features(merged_ben)
    counterparties = float(merged_ben.get("customer_counterparties_30d", 0))
    in_cnt_24h = float(merged_ben.get("incoming_txn_count_24h", 0))
    ftr = float(merged_ben.get("flow_through_ratio", 0.0))
    net_deg = float(merged_ben.get("network_degree", 0))
    reports = float(merged_ben.get("synthetic_report_count", 0))
    age_days = merged_ben.get("account_age_days")

    rule_score = 0.0
    reasons: list[CanonicalReasonCode] = []

    if ftr >= 0.75:
        rule_score += 34.0
        reasons.append(CanonicalReasonCode.BENEFICIARY_RAPID_OUTFLOW)
    elif ftr >= 0.55:
        rule_score += 14.0

    if in_cnt_24h >= 12 and ftr >= 0.60:
        rule_score += 20.0
        reasons.append(CanonicalReasonCode.BENEFICIARY_HIGH_INFLOW_DIVERSITY)
    elif counterparties >= 200 and ftr < 0.35:
        # Busy legitimate merchant with normal settlement retention
        rule_score += 4.0

    if net_deg >= 7:
        rule_score += 22.0
        reasons.append(CanonicalReasonCode.BENEFICIARY_NETWORK_LINKS)
    elif net_deg >= 4:
        rule_score += 8.0

    if reports >= 1:
        rule_score += min(28.0, reports * 7.0)

    if age_days is not None and float(age_days) < 14 and ftr >= 0.60:
        rule_score += 15.0

    if registry.bre_bundle is not None:
        model = registry.bre_bundle["model"]
        prob = float(model.predict_proba(np.asarray([feats], dtype=np.float64))[0, 1])
        ml_score = prob * 100.0
        final_score = int(round(max(0.0, min(100.0, 0.55 * ml_score + 0.45 * rule_score))))
    else:
        final_score = int(round(max(0.0, min(100.0, rule_score))))

    return ComponentRisk(
        score=final_score,
        reason_codes=reasons,
        intelligence_source="SYNTHETIC",
    )
