"""Transaction Behaviour Engine (TBE) — Blueprint Section 5.2 & 16.2.

Scores payer-side transaction anomalies without using protected demographic attributes
(age, preferred_language, or profile_group are never used as fraud predictors).
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Mapping
import numpy as np

from ..models.model_loader import extract_tbe_features, registry
from ..schemas.assessment import CanonicalReasonCode, ComponentRisk


def score_transaction(
    payment: Mapping[str, Any],
    customer: Mapping[str, Any],
) -> ComponentRisk:
    """Compute 0-100 transaction anomaly score and canonical TBE reason codes."""
    amount = float(payment.get("amount", 0.0))
    median = max(100.0, float(customer.get("baseline_amount_median", 1500.0)))
    mad = max(50.0, float(customer.get("baseline_amount_mad", 450.0)))
    is_new_ben = bool(payment.get("is_new_beneficiary", True))

    created_raw = payment.get("created_at")
    if "txn_hour" in payment and payment["txn_hour"] is not None:
        txn_hour = int(payment["txn_hour"]) % 24
    elif created_raw:
        try:
            dt = datetime.fromisoformat(str(created_raw).replace("Z", "+00:00"))
            txn_hour = dt.hour
        except ValueError:
            txn_hour = datetime.now(timezone.utc).hour
    else:
        txn_hour = datetime.now(timezone.utc).hour

    enriched_payment = {
        **payment,
        "txn_hour": txn_hour,
        "is_new_beneficiary": is_new_ben,
    }
    feats = extract_tbe_features(enriched_payment, customer)
    mad_z = feats[0]
    unusual_hour = feats[3] == 1.0
    velocity_1h = feats[4]

    # Rule-based transparent score (0-100)
    rule_score = 0.0
    reasons: list[CanonicalReasonCode] = []

    if is_new_ben:
        rule_score += 22.0
        reasons.append(CanonicalReasonCode.NEW_BENEFICIARY)

    ratio = amount / median
    if ratio >= 10.0 or mad_z >= 8.0:
        rule_score += 40.0
        reasons.append(CanonicalReasonCode.AMOUNT_ABOVE_BASELINE)
    elif ratio >= 3.0 or mad_z >= 3.0:
        rule_score += 24.0
        reasons.append(CanonicalReasonCode.AMOUNT_ABOVE_BASELINE)
    elif ratio >= 1.8:
        rule_score += 10.0

    if unusual_hour:
        rule_score += 14.0
        reasons.append(CanonicalReasonCode.UNUSUAL_PAYMENT_TIME)

    if velocity_1h >= 3:
        rule_score += 18.0
        reasons.append(CanonicalReasonCode.HIGH_PAYMENT_VELOCITY)

    # Blend with trained scikit-learn TBE classifier if available
    if registry.tbe_bundle is not None:
        model = registry.tbe_bundle["model"]
        prob = float(model.predict_proba(np.asarray([feats], dtype=np.float64))[0, 1])
        ml_score = prob * 100.0
        final_score = int(round(max(0.0, min(100.0, 0.55 * ml_score + 0.45 * rule_score))))
    else:
        final_score = int(round(max(0.0, min(100.0, rule_score))))

    return ComponentRisk(
        score=final_score,
        reason_codes=reasons,
        intelligence_source="SYNTHETIC",
    )
