"""Coercion Context Engine (CCE) — Blueprint Section 5.4 & 16.2.

Evaluates user answers for social engineering/coercion cues.
Strictly ensures SKIP, NOT_SURE, and NEED_HELP are NEVER penalized as fraud.
"""

from __future__ import annotations

from typing import Any, Mapping, Sequence

from ..schemas.assessment import CanonicalReasonCode, ComponentRisk


def score_coercion(answers: Sequence[Mapping[str, Any]]) -> ComponentRisk | None:
    """Return None if no questions have been answered yet; else 0-100 coercion index."""
    if not answers:
        return None

    score = 0.0
    reasons: list[CanonicalReasonCode] = []

    for item in answers:
        raw_qid = item.get("question_id")
        raw_ans = item.get("answer")
        qid = raw_qid.value if hasattr(raw_qid, "value") else str(raw_qid)
        ans = raw_ans.value if hasattr(raw_ans, "value") else str(raw_ans)

        if ans in ("SKIP", "NOT_SURE", "NEED_HELP"):
            continue

        if qid == "Q_URGENCY" and ans == "YES":
            score += 28.0
            reasons.append(CanonicalReasonCode.URGENCY_REPORTED)
        elif qid == "Q_THREAT" and ans == "YES":
            score += 48.0
            reasons.append(CanonicalReasonCode.AUTHORITY_THREAT_REPORTED)
        elif qid == "Q_SECRECY" and ans == "YES":
            score += 36.0
            reasons.append(CanonicalReasonCode.SECRECY_REQUEST_REPORTED)
        elif qid == "Q_GUIDANCE" and ans == "YES":
            score += 32.0
            reasons.append(CanonicalReasonCode.REMOTE_GUIDANCE_REPORTED)
        elif qid == "Q_IDENTITY" and ans == "YES":
            score += 35.0
            reasons.append(CanonicalReasonCode.IMPERSONATION_REPORTED)
        elif qid == "Q_PURPOSE" and ans == "NO":
            score += 22.0
            reasons.append(CanonicalReasonCode.INSUFFICIENT_CONTEXT)

    bounded = int(round(max(0.0, min(100.0, score))))
    # Preserve order while deduplicating reason codes
    dedup_reasons = list(dict.fromkeys(reasons))
    return ComponentRisk(
        score=bounded,
        reason_codes=dedup_reasons,
        intelligence_source="USER_CONTEXT",
    )
