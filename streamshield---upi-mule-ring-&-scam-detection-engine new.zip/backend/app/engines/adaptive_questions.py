"""Adaptive Question Selector (AQS) — Blueprint Section 5.5, 7.3, and 16.2.

Deterministic branching tree limited to max 3 questions by default.
"""

from __future__ import annotations

from typing import Any, Mapping, Sequence

from ..models.model_loader import registry
from ..schemas.assessment import Language
from ..schemas.payment import QuestionAnswer, QuestionId, QuestionPrompt


def _to_prompt(qid: str, language: Language) -> QuestionPrompt:
    q = registry.questions_by_id[qid]
    return QuestionPrompt(
        question_id=QuestionId(qid),
        text=q["translations"].get(language.value, q["translations"]["en"]),
        translations=q["translations"],
        audio_prompts=q["audio_prompts"],
        answer_options=[QuestionAnswer(opt) for opt in q["answer_options"]],
        audio_available=True,
    )


def select_next_question(
    tbe_score: int,
    bre_score: int,
    answers: Sequence[Mapping[str, Any]],
    language: Language,
    max_questions: int = 3,
) -> QuestionPrompt | None:
    """Select the single most informative next canonical question or return None."""
    if len(answers) >= max_questions:
        return None

    answered = {
        (a.get("question_id").value if hasattr(a.get("question_id"), "value") else str(a.get("question_id"))): (
            a.get("answer").value if hasattr(a.get("answer"), "value") else str(a.get("answer"))
        )
        for a in answers
    }

    # Skip questionnaire entirely for clearly benign low-risk payments
    if tbe_score < 28 and bre_score < 28 and not answered:
        return None

    # Branch 1: Always start with Q_URGENCY when elevated initial signals exist
    if "Q_URGENCY" not in answered:
        return _to_prompt("Q_URGENCY", language)

    urgency_ans = answered.get("Q_URGENCY")

    # Branch 2: If urgency confirmed, probe authority threat & secrecy/impersonation
    if urgency_ans == "YES":
        if "Q_THREAT" not in answered:
            return _to_prompt("Q_THREAT", language)
        if answered.get("Q_THREAT") == "YES":
            if "Q_SECRECY" not in answered:
                return _to_prompt("Q_SECRECY", language)
            return None
        if "Q_IDENTITY" not in answered:
            return _to_prompt("Q_IDENTITY", language)
        return None

    # Branch 3: Urgency was NO / SKIP / NOT_SURE — check beneficiary risk or guidance/purpose
    if bre_score >= 50:
        if "Q_IDENTITY" not in answered:
            return _to_prompt("Q_IDENTITY", language)
        if "Q_GUIDANCE" not in answered:
            return _to_prompt("Q_GUIDANCE", language)
        return None

    # Branch 4: Unusual amount to benign recipient (hard-negative verification)
    if "Q_PURPOSE" not in answered:
        return _to_prompt("Q_PURPOSE", language)

    return None
