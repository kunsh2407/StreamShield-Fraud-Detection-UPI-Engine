import 'dotenv/config';
import express, { Request, Response } from 'express';
import { spawn, ChildProcess } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import {
  AuthenticatedPortalUser,
  AuthRequest,
  createPortalToken,
  DEMO_ADMIN_ACCOUNTS,
  DEMO_USER_ACCOUNTS,
  requireAdmin,
  requireAuth,
  syncAuthenticatedUser,
} from './src/middleware/auth.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT || 3000);
const FASTAPI_PORT = Number(process.env.FASTAPI_PORT || 8001);
const FASTAPI_ORIGIN = `http://127.0.0.1:${FASTAPI_PORT}`;

let fastapiProc: ChildProcess | null = null;

function resolvePythonExecutable(): string {
  const venvPython = '/opt/streamshield-venv/bin/python';
  if (fs.existsSync(venvPython)) {
    return venvPython;
  }
  return 'python3';
}

function startFastApiProcess() {
  if (fastapiProc) return;
  const pythonBin = resolvePythonExecutable();
  fastapiProc = spawn(
    pythonBin,
    [
      '-m',
      'uvicorn',
      'backend.app.main:app',
      '--host',
      '127.0.0.1',
      '--port',
      String(FASTAPI_PORT),
      '--log-level',
      'warning',
    ],
    {
      cwd: __dirname,
      env: { ...process.env },
      stdio: ['ignore', 'pipe', 'pipe'],
    }
  );

  fastapiProc.stdout?.on('data', (chunk) => {
    const msg = chunk.toString().trim();
    if (msg) console.log(`[FastAPI] ${msg}`);
  });
  fastapiProc.stderr?.on('data', (chunk) => {
    const msg = chunk.toString().trim();
    if (msg) console.error(`[FastAPI] ${msg}`);
  });
  fastapiProc.on('exit', (code) => {
    console.warn(`[FastAPI] exited with code ${code}`);
    fastapiProc = null;
  });
}

async function waitForFastApi(maxWaitMs = 8000): Promise<boolean> {
  const start = Date.now();
  while (Date.now() - start < maxWaitMs) {
    try {
      const resp = await fetch(`${FASTAPI_ORIGIN}/api/v1/health`);
      if (resp.ok) return true;
    } catch {
      // retry until FastAPI finishes booting
    }
    await new Promise((r) => setTimeout(r, 150));
  }
  return false;
}

async function proxyToFastApi(req: Request, res: Response, user?: AuthenticatedPortalUser) {
  try {
    const targetUrl = `${FASTAPI_ORIGIN}${req.originalUrl}`;
    const headers: Record<string, string> = {
      'content-type': 'application/json',
    };
    if (user?.uid) {
      headers['x-user-uid'] = user.uid;
    }
    if (user?.role) {
      headers['x-user-role'] = user.role;
    }
    if (user?.customerId) {
      headers['x-user-customer-id'] = user.customerId;
    }

    let upstreamResp: globalThis.Response;
    try {
      upstreamResp = await fetch(targetUrl, {
        method: req.method,
        headers,
        body: ['GET', 'HEAD'].includes(req.method) ? undefined : JSON.stringify(req.body ?? {}),
      });
    } catch {
      const ready = await waitForFastApi(6000);
      if (!ready) {
        return res.status(503).json({
          error: {
            code: 'BACKEND_UNAVAILABLE',
            message: 'Risk scoring service is starting up. Please retry shortly.',
            details: {},
          },
        });
      }
      upstreamResp = await fetch(targetUrl, {
        method: req.method,
        headers,
        body: ['GET', 'HEAD'].includes(req.method) ? undefined : JSON.stringify(req.body ?? {}),
      });
    }

    const text = await upstreamResp.text();
    res.status(upstreamResp.status);
    res.setHeader('content-type', upstreamResp.headers.get('content-type') || 'application/json');
    return res.send(text);
  } catch (error) {
    console.error('Error proxying to FastAPI backend:', error);
    return res.status(502).json({
      error: {
        code: 'UPSTREAM_PROXY_ERROR',
        message: 'Unable to reach scoring service.',
        details: {},
      },
    });
  }
}

async function createAppServer() {
  startFastApiProcess();

  const app = express();
  app.use(express.json({ limit: '1mb' }));

  // Separate Credential Sign-In for UPI Users
  app.post('/api/auth/user/login', async (req: Request, res: Response) => {
    const identifier = String(req.body?.identifier || '').trim().toLowerCase();
    const password = String(req.body?.password || '');

    const account = DEMO_USER_ACCOUNTS.find(
      (u) =>
        u.customerId.toLowerCase() === identifier ||
        u.handle.toLowerCase() === identifier ||
        u.email.toLowerCase() === identifier
    );

    if (!account || account.password !== password) {
      return res.status(401).json({
        error: {
          code: 'INVALID_USER_CREDENTIALS',
          message: 'Invalid UPI User ID / handle or passcode.',
          details: {},
        },
      });
    }

    const user: AuthenticatedPortalUser = {
      uid: `user_${account.customerId}`,
      email: account.email,
      name: account.displayName,
      role: 'USER',
      customerId: account.customerId,
      authProvider: 'CREDENTIALS',
    };

    try {
      await syncAuthenticatedUser(user);
    } catch {
      return res.status(500).json({
        error: {
          code: 'USER_SYNC_FAILED',
          message: 'Failed to initialize user session in database.',
          details: {},
        },
      });
    }

    const token = createPortalToken({
      uid: user.uid,
      email: user.email,
      name: user.name || account.displayName,
      role: 'USER',
      customerId: account.customerId,
    });

    return res.json({ token, user });
  });

  // Separate Credential Sign-In for Bank Administrators
  app.post('/api/auth/admin/login', async (req: Request, res: Response) => {
    const adminId = String(req.body?.adminId || '').trim().toUpperCase();
    const password = String(req.body?.password || '');

    const adminAccount = DEMO_ADMIN_ACCOUNTS.find((a) => a.adminId.toUpperCase() === adminId);

    if (!adminAccount || adminAccount.password !== password) {
      return res.status(401).json({
        error: {
          code: 'INVALID_ADMIN_CREDENTIALS',
          message: 'Invalid Bank Administrator ID or credentials.',
          details: {},
        },
      });
    }

    const adminUser: AuthenticatedPortalUser = {
      uid: `admin_${adminAccount.adminId}`,
      email: adminAccount.email,
      name: adminAccount.displayName,
      role: 'ADMIN',
      adminId: adminAccount.adminId,
      authProvider: 'CREDENTIALS',
    };

    try {
      await syncAuthenticatedUser(adminUser);
    } catch {
      return res.status(500).json({
        error: {
          code: 'ADMIN_SYNC_FAILED',
          message: 'Failed to initialize bank administrator session in database.',
          details: {},
        },
      });
    }

    const token = createPortalToken({
      uid: adminUser.uid,
      email: adminUser.email,
      name: adminUser.name || adminAccount.displayName,
      role: 'ADMIN',
      adminId: adminAccount.adminId,
    });

    return res.json({ token, user: adminUser });
  });

  // Authenticated session profile
  app.get('/api/auth/me', requireAuth, (req: AuthRequest, res: Response) => {
    return res.json({
      uid: req.user?.uid,
      email: req.user?.email || null,
      displayName: req.user?.name || null,
      role: req.user?.role || 'USER',
      customerId: req.user?.customerId || null,
      adminId: req.user?.adminId || null,
      authProvider: req.user?.authProvider || 'CREDENTIALS',
    });
  });

  // Public non-DB catalog/health endpoints
  app.get('/api/v1/health', (req, res) => proxyToFastApi(req, res));
  app.get('/api/v1/catalog', (req, res) => proxyToFastApi(req, res));
  app.post('/api/v1/demo/score', (req, res) => proxyToFastApi(req, res));

  // User Portal & Payment Lifecycle endpoints (Authenticated User or Admin)
  app.get('/api/v1/user/account', requireAuth, (req: AuthRequest, res) =>
    proxyToFastApi(req, res, req.user)
  );
  app.post('/api/v1/payments/initiate', requireAuth, (req: AuthRequest, res) =>
    proxyToFastApi(req, res, req.user)
  );
  app.post('/api/v1/payments/:paymentId/answers', requireAuth, (req: AuthRequest, res) =>
    proxyToFastApi(req, res, req.user)
  );
  app.get('/api/v1/payments/:paymentId', requireAuth, (req: AuthRequest, res) =>
    proxyToFastApi(req, res, req.user)
  );
  app.post('/api/v1/payments/:paymentId/decision', requireAuth, (req: AuthRequest, res) =>
    proxyToFastApi(req, res, req.user)
  );

  // Bank Administrator-only endpoints
  app.get('/api/v1/evaluation/ablation', requireAdmin, (req: AuthRequest, res) =>
    proxyToFastApi(req, res, req.user)
  );
  app.post('/api/v1/feedback', requireAdmin, (req: AuthRequest, res) =>
    proxyToFastApi(req, res, req.user)
  );
  app.get('/api/v1/admin/alerts', requireAdmin, (req: AuthRequest, res) =>
    proxyToFastApi(req, res, req.user)
  );
  app.get('/api/v1/admin/metrics', requireAdmin, (req: AuthRequest, res) =>
    proxyToFastApi(req, res, req.user)
  );

  // Mount Vite middleware in development or static dist in production
  if (process.env.NODE_ENV === 'production') {
    const distDir = path.resolve(__dirname, 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  } else {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  const server = app.listen(PORT, '0.0.0.0', () => {
    console.log(`StreamShield server listening on http://0.0.0.0:${PORT} (FastAPI proxy on :${FASTAPI_PORT})`);
  });

  const shutdown = () => {
    if (fastapiProc) {
      fastapiProc.kill('SIGTERM');
    }
    server.close(() => process.exit(0));
  };

  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);
}

createAppServer();
