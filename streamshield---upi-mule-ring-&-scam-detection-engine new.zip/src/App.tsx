import React, { useEffect, useMemo, useRef, useState } from 'react';
import { FastForward, Pause, Play, RotateCcw } from 'lucide-react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { AppTab, Navbar } from './components/Navbar';
import { PortalLoginView } from './components/PortalLoginView';
import { UserPortalView } from './components/UserPortalView';
import { AblationStudyView } from './components/AblationStudyView';
import { AdminAnalystDashboard } from './components/AdminAnalystDashboard';
import { MetricsHeader } from './components/MetricsHeader';
import { NetworkGraphView } from './components/NetworkGraphView';
import { LiveTransactionFeed } from './components/LiveTransactionFeed';
import { CostUtilityChart } from './components/CostUtilityChart';
import { TransactionTester } from './components/TransactionTester';
import { ScamPauseModal } from './components/ScamPauseModal';
import { TrailFreezeModal } from './components/TrailFreezeModal';
import { EcosystemPositioningView } from './components/EcosystemPositioningView';
import { ArchitectureModal } from './components/ArchitectureModal';
import {
  GraphEdge,
  GraphNode,
  ScoredTransaction,
  SimulatedPaymentSession,
} from './types';
import { StreamShieldCore } from './utils/engine';
import { UPISyntheticGenerator } from './utils/generator';

function StreamShieldWorkspace() {
  const { user, loading } = useAuth();
  const [activeTab, setActiveTab] = useState<AppTab>('user_portal');
  const [isArchModalOpen, setIsArchModalOpen] = useState<boolean>(false);

  // Sync landing view when authentication role switches
  useEffect(() => {
    if (!user) return;
    if (user.role === 'ADMIN') {
      setActiveTab((prev) => (prev === 'user_portal' ? 'analyst' : prev));
    } else {
      setActiveTab('user_portal');
    }
  }, [user?.role, user?.uid]);

  // Local fallback session cache for Analyst Queue updates
  const [localSessions, setLocalSessions] = useState<SimulatedPaymentSession[]>([]);

  // Live Streaming Operations Engine (Bank Admin Operations console)
  const engineRef = useRef<StreamShieldCore>(new StreamShieldCore());
  const generatorRef = useRef<UPISyntheticGenerator>(new UPISyntheticGenerator());
  const [isStreaming, setIsStreaming] = useState<boolean>(false);
  const [round, setRound] = useState<1 | 2>(1);
  const [tickVersion, setTickVersion] = useState<number>(0);
  const [selectedTx, setSelectedTx] = useState<ScoredTransaction | null>(null);
  const [scamModalTx, setScamModalTx] = useState<ScoredTransaction | null>(null);
  const [freezeModalNode, setFreezeModalNode] = useState<GraphNode | null>(null);
  const [thresholdStepUp, setThresholdStepUp] = useState<number>(0.45);
  const [thresholdHold, setThresholdHold] = useState<number>(0.75);

  useEffect(() => {
    if (!isStreaming) return;
    const timer = window.setInterval(() => {
      const tx = generatorRef.current.generateTransaction(round);
      engineRef.current.scoreTransaction(tx, round === 2);
      setTickVersion((v) => v + 1);
    }, 350);
    return () => window.clearInterval(timer);
  }, [isStreaming, round]);

  const handleInjectBatch = (count: number) => {
    for (let i = 0; i < count; i++) {
      const tx = generatorRef.current.generateTransaction(round);
      const scored = engineRef.current.scoreTransaction(tx, round === 2);
      if (i === count - 1) {
        setSelectedTx(scored);
      }
    }
    setTickVersion((v) => v + 1);
  };

  const handleResetOperations = () => {
    setIsStreaming(false);
    engineRef.current.reset();
    engineRef.current.thresholdStepUp = thresholdStepUp;
    engineRef.current.thresholdHold = thresholdHold;
    setSelectedTx(null);
    setTickVersion((v) => v + 1);
  };

  const handleThresholdChange = (stepUp: number, hold: number) => {
    const safeStep = Math.min(stepUp, hold - 0.05);
    setThresholdStepUp(safeStep);
    setThresholdHold(hold);
    engineRef.current.thresholdStepUp = safeStep;
    engineRef.current.thresholdHold = hold;
    setTickVersion((v) => v + 1);
  };

  const handleFreezeAccount = (vpa: string) => {
    engineRef.current.freezeAccount(vpa);
    setTickVersion((v) => v + 1);
  };

  const opsSnapshot = useMemo(() => {
    void tickVersion;
    const stats = engineRef.current.getStats();
    const graph: { nodes: GraphNode[]; edges: GraphEdge[] } = engineRef.current.getGraphData();
    const feed = engineRef.current.scoredTransactions.slice();
    return { stats, graph, feed };
  }, [tickVersion]);

  const handleUpsertLocalSession = (session: SimulatedPaymentSession) => {
    setLocalSessions((prev) => {
      const idx = prev.findIndex((p) => p.payment_id === session.payment_id);
      if (idx >= 0) {
        const next = [...prev];
        next[idx] = session;
        return next;
      }
      return [session, ...prev];
    });
  };

  const isAdmin = user?.role === 'ADMIN';

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col">
      <Navbar
        activeTab={activeTab}
        onTabChange={setActiveTab}
        onOpenArchitecture={() => setIsArchModalOpen(true)}
      />

      <main className="flex-1 max-w-[1440px] w-full mx-auto px-4 sm:px-6 py-6 sm:py-8">
        {loading ? (
          <div className="py-20 text-center text-sm text-slate-400">Verifying session...</div>
        ) : !user ? (
          <PortalLoginView />
        ) : !isAdmin ? (
          <UserPortalView />
        ) : (
          <>
            {activeTab === 'analyst' && (
              <AdminAnalystDashboard
                localSessions={localSessions}
                onUpdateLocalSession={handleUpsertLocalSession}
              />
            )}

            {activeTab === 'operations' && (
              <div className="space-y-6">
                <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-4 border-b border-slate-800 pb-5">
                  <div className="space-y-1">
                    <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-50">
                      Live Streaming Operations & Mule Graph Monitor
                    </h1>
                    <p className="text-sm text-slate-400">
                      Synthetic real-time UPI stream demonstrating Round 1 mule fan-in and Round 2 adaptive smurfing rings.
                    </p>
                  </div>

                  <div className="flex flex-wrap items-center gap-2.5">
                    <div className="flex items-center gap-1 p-1 bg-slate-900 border border-slate-800 rounded-lg">
                      <button
                        type="button"
                        onClick={() => setRound(1)}
                        className={`px-3 py-1.5 rounded-md text-xs font-semibold min-h-[36px] ${
                          round === 1 ? 'bg-sky-600 text-white' : 'text-slate-400 hover:text-white'
                        }`}
                      >
                        Round 1 (Fan-In)
                      </button>
                      <button
                        type="button"
                        onClick={() => setRound(2)}
                        className={`px-3 py-1.5 rounded-md text-xs font-semibold min-h-[36px] ${
                          round === 2 ? 'bg-amber-600 text-white' : 'text-slate-400 hover:text-white'
                        }`}
                      >
                        Round 2 (Drift)
                      </button>
                    </div>

                    <button
                      type="button"
                      onClick={() => setIsStreaming((s) => !s)}
                      className={`inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs sm:text-sm font-semibold min-h-[40px] ${
                        isStreaming
                          ? 'bg-amber-600 hover:bg-amber-500 text-white'
                          : 'bg-emerald-600 hover:bg-emerald-500 text-white'
                      }`}
                    >
                      {isStreaming ? (
                        <>
                          <Pause className="w-4 h-4" />
                          <span>Pause Stream</span>
                        </>
                      ) : (
                        <>
                          <Play className="w-4 h-4" />
                          <span>Start Stream</span>
                        </>
                      )}
                    </button>

                    <button
                      type="button"
                      onClick={() => handleInjectBatch(25)}
                      className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-slate-700 bg-slate-900 hover:bg-slate-800 text-slate-100 text-xs sm:text-sm font-medium min-h-[40px]"
                    >
                      <FastForward className="w-4 h-4 text-sky-400" />
                      <span>+25 Tx</span>
                    </button>

                    <button
                      type="button"
                      onClick={handleResetOperations}
                      className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-slate-700 bg-slate-900 hover:bg-slate-800 text-slate-300 text-xs sm:text-sm font-medium min-h-[40px]"
                    >
                      <RotateCcw className="w-4 h-4" />
                      <span>Reset</span>
                    </button>
                  </div>
                </div>

                <MetricsHeader stats={opsSnapshot.stats} />

                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                  <div className="lg:col-span-6">
                    <NetworkGraphView
                      nodes={opsSnapshot.graph.nodes}
                      edges={opsSnapshot.graph.edges}
                      onSelectNode={(n) => setFreezeModalNode(n)}
                    />
                  </div>
                  <div className="lg:col-span-6">
                    <LiveTransactionFeed
                      transactions={opsSnapshot.feed}
                      selectedTxId={selectedTx?.tx_id}
                      onSelectTx={(tx) => setSelectedTx(tx)}
                    />
                  </div>
                </div>

                <CostUtilityChart
                  stats={opsSnapshot.stats}
                  thresholdHold={thresholdHold}
                  thresholdStepUp={thresholdStepUp}
                />

                <TransactionTester
                  selectedTx={selectedTx}
                  thresholdStepUp={thresholdStepUp}
                  thresholdHold={thresholdHold}
                  onChangeThresholds={handleThresholdChange}
                  onOpenScamPauseModal={(tx) => setScamModalTx(tx)}
                />
              </div>
            )}

            {activeTab === 'ablation' && <AblationStudyView />}

            {activeTab === 'ecosystem' && <EcosystemPositioningView />}
          </>
        )}
      </main>

      <footer className="border-t border-slate-900 py-4 px-4 sm:px-6 text-xs text-slate-500">
        <div className="max-w-[1440px] mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>StreamShield Synthetic Fraud & Coercion Protection Prototype</span>
          <span>Simulated UPI demo only — no real money or banking rails connected</span>
        </div>
      </footer>

      {isAdmin && (
        <>
          <ArchitectureModal isOpen={isArchModalOpen} onClose={() => setIsArchModalOpen(false)} />
          <ScamPauseModal
            transaction={scamModalTx}
            onClose={() => setScamModalTx(null)}
            onFreezeReceiver={handleFreezeAccount}
          />
          <TrailFreezeModal
            node={freezeModalNode}
            isFrozen={freezeModalNode ? engineRef.current.isAccountFrozen(freezeModalNode.id) : false}
            onClose={() => setFreezeModalNode(null)}
            onConfirmFreeze={handleFreezeAccount}
          />
        </>
      )}
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <StreamShieldWorkspace />
    </AuthProvider>
  );
}
