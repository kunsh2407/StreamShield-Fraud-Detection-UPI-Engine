import React from 'react';
import { Snowflake, X } from 'lucide-react';
import { GraphNode } from '../types';

interface TrailFreezeModalProps {
  node: GraphNode | null;
  isFrozen: boolean;
  onClose: () => void;
  onConfirmFreeze: (vpa: string) => void;
}

export const TrailFreezeModal: React.FC<TrailFreezeModalProps> = ({
  node,
  isFrozen,
  onClose,
  onConfirmFreeze,
}) => {
  if (!node) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="trail-freeze-title"
      className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4"
    >
      <div className="w-full max-w-md rounded-xl border border-sky-500/40 bg-slate-900 p-6 space-y-5 shadow-2xl">
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-sky-500/20 border border-sky-500/40 flex items-center justify-center text-sky-300">
              <Snowflake className="w-5 h-5" />
            </div>
            <div>
              <h2 id="trail-freeze-title" className="text-lg font-bold text-slate-50">
                Mule Trail Cascade Freeze
              </h2>
              <p className="text-xs text-slate-400 font-mono truncate max-w-[240px]">
                {node.id}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close trail freeze dialog"
            className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-2 gap-3 text-xs font-mono tabular-nums">
          <div className="rounded-lg border border-slate-800 bg-slate-950 p-3">
            <div className="text-slate-400 font-sans">In / Out Links</div>
            <div className="text-base font-bold text-slate-100 mt-0.5">
              {node.inDegree} in / {node.outDegree} out
            </div>
          </div>
          <div className="rounded-lg border border-slate-800 bg-slate-950 p-3">
            <div className="text-slate-400 font-sans">Cached Risk</div>
            <div className="text-base font-bold text-rose-300 mt-0.5">
              {(node.riskScore * 100).toFixed(0)} / 100
            </div>
          </div>
          <div className="rounded-lg border border-slate-800 bg-slate-950 p-3">
            <div className="text-slate-400 font-sans">Total Received</div>
            <div className="text-sm font-bold text-slate-100 mt-0.5">
              ₹{node.totalReceived.toLocaleString('en-IN')}
            </div>
          </div>
          <div className="rounded-lg border border-slate-800 bg-slate-950 p-3">
            <div className="text-slate-400 font-sans">Total Outflow</div>
            <div className="text-sm font-bold text-slate-100 mt-0.5">
              ₹{node.totalSent.toLocaleString('en-IN')}
            </div>
          </div>
        </div>

        <p className="text-xs text-slate-300 leading-relaxed">
          Freezing this node cascades up to 2 downstream counterparty hops in the live graph so subsequent transfers to those mule accounts are held immediately.
        </p>

        <div className="flex justify-end gap-3 pt-2 border-t border-slate-800">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-lg border border-slate-700 bg-slate-950 hover:bg-slate-800 text-slate-200 text-sm font-medium min-h-[40px]"
          >
            Cancel
          </button>
          <button
            type="button"
            disabled={isFrozen}
            onClick={() => {
              onConfirmFreeze(node.id);
              onClose();
            }}
            className="px-4 py-2 rounded-lg bg-sky-600 hover:bg-sky-500 disabled:opacity-50 text-white text-sm font-semibold min-h-[40px]"
          >
            {isFrozen ? 'Already Frozen' : 'Execute Trail Freeze'}
          </button>
        </div>
      </div>
    </div>
  );
};
