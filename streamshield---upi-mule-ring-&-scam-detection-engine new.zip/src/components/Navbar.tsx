import React from 'react';
import {
  ShieldCheck,
  Activity,
  BarChart3,
  ClipboardCheck,
  Globe2,
  Layers,
  LogOut,
  UserCheck,
  Building2,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export type AdminTab = 'analyst' | 'operations' | 'ablation' | 'ecosystem';
export type AppTab = 'user_portal' | AdminTab;

interface NavbarProps {
  activeTab: AppTab;
  onTabChange: (tab: AppTab) => void;
  onOpenArchitecture: () => void;
}

const ADMIN_NAV_ITEMS: { id: AdminTab; label: string; icon: React.ReactNode }[] = [
  { id: 'analyst', label: 'Analyst Queue', icon: <ClipboardCheck className="w-4 h-4" /> },
  { id: 'operations', label: 'Operations', icon: <Activity className="w-4 h-4" /> },
  { id: 'ablation', label: 'ML Ablation', icon: <BarChart3 className="w-4 h-4" /> },
  { id: 'ecosystem', label: 'Ecosystem', icon: <Globe2 className="w-4 h-4" /> },
];

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  onTabChange,
  onOpenArchitecture,
}) => {
  const { user, loading, logout } = useAuth();

  const isAdmin = user?.role === 'ADMIN';
  const isUser = user?.role === 'USER';

  return (
    <header className="lg:sticky lg:top-0 z-40 bg-slate-950/95 backdrop-blur border-b border-slate-800">
      <div className="max-w-[1440px] mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
        <button
          type="button"
          onClick={() => onTabChange(isAdmin ? 'analyst' : 'user_portal')}
          className="flex items-center gap-2.5 text-left whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500 rounded-md px-1 py-1"
        >
          <span className="w-8 h-8 rounded-lg bg-sky-500/15 border border-sky-500/30 flex items-center justify-center text-sky-400">
            <ShieldCheck className="w-4 h-4" />
          </span>
          <span className="text-lg font-bold tracking-tight text-slate-50 font-['Plus_Jakarta_Sans']">
            StreamShield
          </span>
        </button>

        {/* Role-gated Primary Navigation */}
        {isAdmin ? (
          <nav aria-label="Bank administrator navigation" className="hidden lg:flex items-center gap-1">
            {ADMIN_NAV_ITEMS.map((item) => {
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => onTabChange(item.id)}
                  aria-current={isActive ? 'page' : undefined}
                  className={`inline-flex items-center gap-1.5 px-3 py-2 rounded-lg text-[13px] font-medium whitespace-nowrap shrink-0 transition-colors min-h-[38px] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500 ${
                    isActive
                      ? 'bg-slate-800 text-slate-50'
                      : 'text-slate-400 hover:text-slate-100 hover:bg-slate-900'
                  }`}
                >
                  {item.icon}
                  <span>{item.label}</span>
                </button>
              );
            })}
          </nav>
        ) : isUser ? (
          <nav aria-label="UPI user navigation" className="hidden lg:flex items-center gap-1">
            <button
              type="button"
              onClick={() => onTabChange('user_portal')}
              aria-current="page"
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg text-[13px] font-medium whitespace-nowrap shrink-0 min-h-[38px] bg-slate-800 text-slate-50"
            >
              <ShieldCheck className="w-4 h-4 text-sky-400" />
              <span>My Account & Pay</span>
            </button>
          </nav>
        ) : (
          <div className="hidden md:block text-xs text-slate-400">
            Pre-Payment UPI Protection & Bank Fraud Operations
          </div>
        )}

        <div className="flex items-center gap-2 shrink-0">
          {isAdmin && (
            <button
              type="button"
              onClick={onOpenArchitecture}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-slate-700 bg-slate-900 text-slate-200 hover:bg-slate-800 text-xs sm:text-sm font-medium whitespace-nowrap shrink-0 min-h-[38px] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500"
            >
              <Layers className="w-4 h-4 text-sky-400" />
              <span className="hidden sm:inline">Architecture</span>
            </button>
          )}

          {loading ? (
            <span className="px-3 py-2 text-xs text-slate-400 whitespace-nowrap">Loading...</span>
          ) : user ? (
            <div className="flex items-center gap-2.5">
              <span
                className={`hidden sm:inline-flex items-center gap-1.5 text-xs max-w-[200px] truncate ${
                  isAdmin ? 'text-amber-300' : 'text-sky-300'
                }`}
                title={user.email || user.displayName}
              >
                {isAdmin ? (
                  <Building2 className="w-3.5 h-3.5 shrink-0" />
                ) : (
                  <UserCheck className="w-3.5 h-3.5 shrink-0" />
                )}
                <span className="truncate font-medium">
                  {isAdmin ? `${user.adminId} · Bank Admin` : user.displayName}
                </span>
              </span>
              <button
                type="button"
                onClick={logout}
                className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-slate-700 bg-slate-900 hover:bg-slate-800 text-slate-200 text-xs sm:text-sm font-medium whitespace-nowrap shrink-0 min-h-[38px] transition-colors"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Sign Out</span>
              </button>
            </div>
          ) : (
            <span className="text-xs text-slate-400 whitespace-nowrap">Sign In Required</span>
          )}
        </div>
      </div>

      {/* Responsive single-row scrollable sub-bar for Admin on smaller screens */}
      {isAdmin && (
        <div className="lg:hidden border-t border-slate-800/80 bg-slate-950">
          <nav
            aria-label="Mobile bank administrator navigation"
            className="max-w-[1440px] mx-auto px-3 py-1.5 flex items-center gap-1 overflow-x-auto"
          >
            {ADMIN_NAV_ITEMS.map((item) => {
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => onTabChange(item.id)}
                  aria-current={isActive ? 'page' : undefined}
                  className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium whitespace-nowrap shrink-0 min-h-[38px] transition-colors ${
                    isActive
                      ? 'bg-slate-800 text-slate-50'
                      : 'text-slate-400 hover:text-slate-100 hover:bg-slate-900'
                  }`}
                >
                  {item.icon}
                  <span>{item.label}</span>
                </button>
              );
            })}
          </nav>
        </div>
      )}
    </header>
  );
};
