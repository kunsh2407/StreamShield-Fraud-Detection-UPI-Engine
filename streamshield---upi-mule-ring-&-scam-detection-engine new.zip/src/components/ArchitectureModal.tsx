import React from 'react';
import { Database, Layers, Cpu, ShieldCheck, X } from 'lucide-react';

interface ArchitectureModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ArchitectureModal: React.FC<ArchitectureModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="arch-modal-title"
      className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4"
    >
      <div className="w-full max-w-3xl rounded-xl border border-slate-700 bg-slate-900 p-6 space-y-6 shadow-2xl max-h-[90vh] overflow-y-auto">
        <div className="flex items-start justify-between gap-4 border-b border-slate-800 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-sky-500/20 border border-sky-500/40 flex items-center justify-center text-sky-400">
              <Layers className="w-5 h-5" />
            </div>
            <div>
              <h2 id="arch-modal-title" className="text-xl font-bold text-slate-50">
                StreamShield End-to-End Architecture
              </h2>
              <p className="text-xs text-slate-400">
                React SPA + Express Gateway + Python FastAPI ML Service + Cloud SQL PostgreSQL
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close architecture modal"
            className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
          <div className="rounded-lg border border-slate-800 bg-slate-950 p-4 space-y-2">
            <div className="flex items-center gap-2 font-semibold text-sky-300">
              <ShieldCheck className="w-4 h-4" />
              <span>1. Frontend & Auth Gateway</span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              React 19 + TypeScript + Tailwind CSS served via Express on port 3000. Firebase Google Auth protects persisted endpoints while stateless <span className="font-mono">/api/v1/demo/score</span> supports instant guest simulations.
            </p>
          </div>

          <div className="rounded-lg border border-slate-800 bg-slate-950 p-4 space-y-2">
            <div className="flex items-center gap-2 font-semibold text-emerald-300">
              <Cpu className="w-4 h-4" />
              <span>2. Python FastAPI Scoring Engines</span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              Dedicated FastAPI service on port 8001 runs TBE (payer MAD deviations), BRE (beneficiary flow-through & graph degree), AQS (multilingual 2–3 question selector), CCE (non-punitive coercion), and RFDE fusion.
            </p>
          </div>

          <div className="rounded-lg border border-slate-800 bg-slate-950 p-4 space-y-2">
            <div className="flex items-center gap-2 font-semibold text-amber-300">
              <Layers className="w-4 h-4" />
              <span>3. Offline scikit-learn & NetworkX Pipeline</span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              Reproducible synthetic generator (<span className="font-mono">ml/data_generator.py</span>) produces 2,400 scenarios split by <span className="font-mono">customer_id</span>. Trains calibrated logistic models (<span className="font-mono">tbe_model</span>, <span className="font-mono">bre_model</span>, <span className="font-mono">model_a/b/c</span>) and exports real test metrics.
            </p>
          </div>

          <div className="rounded-lg border border-slate-800 bg-slate-950 p-4 space-y-2">
            <div className="flex items-center gap-2 font-semibold text-rose-300">
              <Database className="w-4 h-4" />
              <span>4. Cloud SQL PostgreSQL Persistence</span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              Nine normalized tables (<span className="font-mono">users, customers, beneficiaries, payments, assessments, questions, answers, feedback, audit_events</span>) manage full payment lifecycles and analyst FES feedback.
            </p>
          </div>
        </div>

        <div className="flex justify-end pt-2 border-t border-slate-800">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-lg bg-sky-600 hover:bg-sky-500 text-white text-sm font-semibold min-h-[40px]"
          >
            Close Overview
          </button>
        </div>
      </div>
    </div>
  );
};
