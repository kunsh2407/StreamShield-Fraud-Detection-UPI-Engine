import React from 'react';
import { EngineStats } from '../types';

interface MetricsHeaderProps {
  stats: EngineStats;
}

export const MetricsHeader: React.FC<MetricsHeaderProps> = ({ stats }) => {
  const cards = [
    {
      label: 'Transactions Scored',
      value: stats.totalScored.toLocaleString('en-IN'),
      sub: `${stats.decisionCounts.ALLOW} Allow · ${stats.decisionCounts.STEP_UP} Step-Up · ${stats.decisionCounts.HOLD} Hold`,
      tone: 'text-slate-50',
    },
    {
      label: 'Fraud Prevented (INR)',
      value: `₹${stats.totalFraudBlockedINR.toLocaleString('en-IN')}`,
      sub: `Friction Cost: ₹${stats.totalFrictionCostINR.toLocaleString('en-IN')}`,
      tone: 'text-emerald-300',
    },
    {
      label: 'Net Cost-Utility Benefit',
      value: `₹${stats.netBenefitINR.toLocaleString('en-IN')}`,
      sub: 'Fraud Prevented − Step-Up Friction',
      tone: 'text-sky-300',
    },
    {
      label: 'Observed P99 Latency',
      value: `${stats.p99Latency.toFixed(3)} ms`,
      sub: `p50: ${stats.p50Latency.toFixed(3)} ms · p95: ${stats.p95Latency.toFixed(3)} ms`,
      tone: 'text-slate-100',
    },
    {
      label: 'Stream Precision / Recall',
      value: `${(stats.precision * 100).toFixed(1)}% / ${(stats.recall * 100).toFixed(1)}%`,
      sub: `F1 Harmonic: ${stats.prAuc.toFixed(3)}`,
      tone: 'text-amber-300',
    },
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
      {cards.map((c) => (
        <div key={c.label} className="rounded-xl border border-slate-800 bg-slate-900/70 p-4 space-y-1">
          <div className="text-xs text-slate-400">{c.label}</div>
          <div className={`text-xl font-bold font-mono tabular-nums ${c.tone}`}>{c.value}</div>
          <div className="text-xs text-slate-500 font-mono tabular-nums truncate">{c.sub}</div>
        </div>
      ))}
    </div>
  );
};
