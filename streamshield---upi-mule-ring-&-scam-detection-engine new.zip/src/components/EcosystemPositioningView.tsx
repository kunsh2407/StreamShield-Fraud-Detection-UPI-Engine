import React from 'react';
import { CheckCircle2, ShieldOff, Globe2, Lock } from 'lucide-react';
import { ECOSYSTEM_POSITIONING_CONTENT } from '../data/canonicalData';

export const EcosystemPositioningView: React.FC = () => {
  const { rbiRelationship, claimsAllowed, claimsForbidden } = ECOSYSTEM_POSITIONING_CONTENT;

  return (
    <div className="space-y-6">
      <div className="space-y-1.5 border-b border-slate-800 pb-5">
        <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-50">
          Ecosystem Alignment & Honest Prototype Scope
        </h1>
        <p className="text-sm text-slate-400 max-w-3xl leading-relaxed">
          StreamShield complements RBI and bank-side mule intelligence with a pre-payment victim-coercion protection layer while keeping strict synthetic prototype boundaries.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <section className="rounded-xl border border-slate-800 bg-slate-900/70 p-6 space-y-3">
          <div className="flex items-center gap-2 text-sky-400 text-xs font-semibold">
            <Globe2 className="w-4 h-4" />
            <span>Complementary Bank Intelligence</span>
          </div>
          <h2 className="text-xl font-bold text-slate-50">{rbiRelationship.muleHunter.name}</h2>
          <p className="text-xs text-slate-400">{rbiRelationship.muleHunter.status}</p>
          <p className="text-sm text-slate-300 leading-relaxed">{rbiRelationship.muleHunter.role}</p>
          <div className="pt-2 border-t border-slate-800 text-sm text-sky-200 leading-relaxed">
            {rbiRelationship.muleHunter.streamShieldRelation}
          </div>
        </section>

        <section className="rounded-xl border border-slate-800 bg-slate-900/70 p-6 space-y-3">
          <div className="flex items-center gap-2 text-sky-400 text-xs font-semibold">
            <Globe2 className="w-4 h-4" />
            <span>Network Intelligence Sharing</span>
          </div>
          <h2 className="text-xl font-bold text-slate-50">{rbiRelationship.dpip.name}</h2>
          <p className="text-xs text-slate-400">{rbiRelationship.dpip.status}</p>
          <p className="text-sm text-slate-300 leading-relaxed">{rbiRelationship.dpip.role}</p>
          <div className="pt-2 border-t border-slate-800 text-sm text-sky-200 leading-relaxed">
            {rbiRelationship.dpip.streamShieldRelation}
          </div>
        </section>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <section className="rounded-xl border border-emerald-500/30 bg-emerald-950/15 p-6 space-y-3">
          <h2 className="text-base font-bold text-emerald-200 flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-emerald-400" />
            <span>Defensible Claims We Make</span>
          </h2>
          <ul className="space-y-2.5 text-sm text-slate-200">
            {claimsAllowed.map((claim, i) => (
              <li key={i} className="flex items-start gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>{claim}</span>
              </li>
            ))}
          </ul>
        </section>

        <section className="rounded-xl border border-rose-500/30 bg-rose-950/15 p-6 space-y-3">
          <h2 className="text-base font-bold text-rose-200 flex items-center gap-2">
            <ShieldOff className="w-5 h-5 text-rose-400" />
            <span>Claims We Explicitly Avoid</span>
          </h2>
          <ul className="space-y-2.5 text-sm text-slate-200">
            {claimsForbidden.map((claim, i) => (
              <li key={i} className="flex items-start gap-2.5">
                <ShieldOff className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                <span>{claim}</span>
              </li>
            ))}
          </ul>
        </section>
      </div>

      <section className="rounded-xl border border-slate-800 bg-slate-900/70 p-6 flex items-start gap-3">
        <Lock className="w-5 h-5 text-sky-400 shrink-0 mt-0.5" />
        <div className="space-y-1">
          <h2 className="text-base font-semibold text-slate-100">
            Fairness, Consent & Non-Discrimination Guardrails
          </h2>
          <p className="text-sm text-slate-400 leading-relaxed">
            Age, language, and literacy profile are used strictly to choose clear multilingual UI and audio phrasing. They are excluded from fraud ML feature vectors, and neutral answers (<span className="font-mono text-slate-300">SKIP</span>, <span className="font-mono text-slate-300">NOT_SURE</span>, <span className="font-mono text-slate-300">NEED_HELP</span>) receive zero coercion penalty.
          </p>
        </div>
      </section>
    </div>
  );
};
