import React from 'react';
import { EngineStats } from '../types';

interface CostUtilityChartProps {
  stats: EngineStats;
  thresholdHold: number;
  thresholdStepUp: number;
}

export const CostUtilityChart: React.FC<CostUtilityChartProps> = ({
  stats,
  thresholdHold,
  thresholdStepUp,
}) => {
  const total = Math.max(1, stats.totalScored);
  const allowPct = (stats.decisionCounts.ALLOW / total) * 100;
  const stepPct = (stats.decisionCounts.STEP_UP / total) * 100;
  const holdPct = (stats.decisionCounts.HOLD / total) * 100;

  return (
    <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-4 sm:p-5 space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div>
          <h2 className="text-base font-semibold text-slate-100">
            Cost-Aware Policy Split & Utility Tradeoff
          </h2>
          <p className="text-xs text-slate-400 font-mono tabular-nums">
            Step-Up Threshold: {(thresholdStepUp * 100).toFixed(0)} · Hold Threshold: {(thresholdHold * 100).toFixed(0)}
          </p>
        </div>
        <div className="text-sm font-mono tabular-nums font-semibold text-sky-300">
          Net Benefit: ₹{stats.netBenefitINR.toLocaleString('en-IN')}
        </div>
      </div>

      {/* Stacked Decision Distribution Bar */}
      <div className="space-y-2">
        <div className="h-4 w-full rounded-lg bg-slate-950 border border-slate-800 overflow-hidden flex">
          <div
            className="bg-emerald-500/80 h-full transition-all duration-300"
            style={{ width: `${allowPct}%` }}
            title={`ALLOW: ${stats.decisionCounts.ALLOW}`}
          />
          <div
            className="bg-amber-500/85 h-full transition-all duration-300"
            style={{ width: `${stepPct}%` }}
            title={`STEP_UP: ${stats.decisionCounts.STEP_UP}`}
          />
          <div
            className="bg-rose-500/90 h-full transition-all duration-300"
            style={{ width: `${holdPct}%` }}
            title={`HOLD: ${stats.decisionCounts.HOLD}`}
          />
        </div>
        <div className="grid grid-cols-3 gap-2 text-xs font-mono tabular-nums">
          <div className="text-emerald-300">
            ALLOW: {stats.decisionCounts.ALLOW} ({allowPct.toFixed(1)}%)
          </div>
          <div className="text-amber-300 text-center">
            STEP-UP: {stats.decisionCounts.STEP_UP} ({stepPct.toFixed(1)}%)
          </div>
          <div className="text-rose-300 text-right">
            HOLD: {stats.decisionCounts.HOLD} ({holdPct.toFixed(1)}%)
          </div>
        </div>
      </div>
    </div>
  );
};
