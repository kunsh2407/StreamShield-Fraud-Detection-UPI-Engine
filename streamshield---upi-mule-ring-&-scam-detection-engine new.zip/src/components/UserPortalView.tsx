import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  Clock,
  Laptop,
  RefreshCw,
  Send,
  ShieldCheck,
  Smartphone,
  UserCheck,
  XCircle,
} from 'lucide-react';
import {
  CanonicalQuestion,
  Language,
  PaymentStatus,
  SimulatedPaymentSession,
  UserAccountSummary,
} from '../types';
import { CANONICAL_BENEFICIARIES, CANONICAL_CUSTOMERS } from '../data/canonicalData';
import { useAuth } from '../context/AuthContext';
import { paymentService } from '../services/paymentService';
import { detectDeviceContext } from '../utils/deviceContext';
import { PaymentRiskPopupModal } from './PaymentRiskPopupModal';

function renderStatusLabel(status: PaymentStatus): { text: string; toneClass: string } {
  switch (status) {
    case 'APPROVED_BY_BANK':
      return { text: 'Bank Approved · Payment Proceeded', toneClass: 'text-emerald-300 font-semibold' };
    case 'TERMINATED_SCAM':
      return { text: 'Terminated by Bank · Confirmed Scam', toneClass: 'text-rose-300 font-semibold' };
    case 'REFERRED_FOR_REVIEW':
      return { text: 'Awaiting Bank Review', toneClass: 'text-sky-300 font-semibold' };
    case 'SIMULATION_CONTINUED':
      return { text: 'Completed', toneClass: 'text-emerald-300' };
    case 'SIMULATION_CANCELLED':
      return { text: 'Cancelled', toneClass: 'text-rose-300' };
    case 'SIMULATION_PAUSED':
      return { text: 'Paused for Verification', toneClass: 'text-amber-300' };
    default:
      return { text: status.replace(/_/g, ' '), toneClass: 'text-slate-300' };
  }
}

export const UserPortalView: React.FC = () => {
  const { user, getIdToken } = useAuth();
  const device = useMemo(() => detectDeviceContext(), []);

  const [accountSummary, setAccountSummary] = useState<UserAccountSummary | null>(null);
  const [loadingAccount, setLoadingAccount] = useState<boolean>(true);
  const [accountError, setAccountError] = useState<string | null>(null);

  // Payment Checkout State (payer auto-filled from logged-in user)
  const [beneficiaryId, setBeneficiaryId] = useState<string>('BEN_0102');
  const [customVpa, setCustomVpa] = useState<string>('');
  const [amount, setAmount] = useState<string>('350');
  const [purpose, setPurpose] = useState<string>('Kirana Groceries & Tea');
  const [language, setLanguage] = useState<Language>('en');
  const [submitting, setSubmitting] = useState<boolean>(false);
  const [payError, setPayError] = useState<string | null>(null);
  const [safeSuccessSession, setSafeSuccessSession] = useState<SimulatedPaymentSession | null>(null);

  // Security Interception Pop-up State (automatically shown when risk is unsafe)
  const [popupSession, setPopupSession] = useState<SimulatedPaymentSession | null>(null);
  const [popupQuestion, setPopupQuestion] = useState<CanonicalQuestion | null>(null);
  const [isPopupOpen, setIsPopupOpen] = useState<boolean>(false);

  // Inspectable row details
  const [selectedTxId, setSelectedTxId] = useState<string | null>(null);
  const initializedLangForRef = useRef<string | null>(null);
  const userSwitchedLangRef = useRef<boolean>(false);

  const loadAccount = async (silent = false) => {
    if (!silent) setLoadingAccount(true);
    setAccountError(null);
    try {
      const token = await getIdToken();
      if (!token) return;
      const summary = await paymentService.fetchUserAccount(token, user?.customerId);
      setAccountSummary(summary);
      if (
        !silent &&
        !userSwitchedLangRef.current &&
        initializedLangForRef.current !== summary.profile.customer_id &&
        summary.profile.preferred_language
      ) {
        initializedLangForRef.current = summary.profile.customer_id;
        setLanguage(summary.profile.preferred_language);
      }
    } catch (err: any) {
      setAccountError(err?.message || 'Unable to load your account details.');
    } finally {
      if (!silent) setLoadingAccount(false);
    }
  };

  useEffect(() => {
    userSwitchedLangRef.current = false;
    loadAccount(false);
  }, [user?.uid, user?.customerId]);

  // Live poll every 5s while user has any pending bank review transaction
  useEffect(() => {
    if (!accountSummary || accountSummary.pending_review_count === 0) return;
    const timer = window.setInterval(() => {
      loadAccount(true);
    }, 5000);
    return () => window.clearInterval(timer);
  }, [accountSummary?.pending_review_count]);

  const activeProfile = useMemo(() => {
    if (accountSummary?.profile) return accountSummary.profile;
    return (
      CANONICAL_CUSTOMERS.find((c) => c.customer_id === (user?.customerId || 'CUS_0002')) ||
      CANONICAL_CUSTOMERS[0]
    );
  }, [accountSummary, user?.customerId]);

  const applyPaymentPreset = (mode: 'safe' | 'scam' | 'kyc') => {
    setPayError(null);
    setSafeSuccessSession(null);
    if (mode === 'safe') {
      setBeneficiaryId('BEN_0102');
      setAmount('350');
      setPurpose('Morning Chai & Groceries');
    } else if (mode === 'scam') {
      setBeneficiaryId('BEN_0601');
      setAmount('75000');
      setPurpose('Cyber Police Bail Verification');
    } else {
      setBeneficiaryId('BEN_0602');
      setAmount('48000');
      setPurpose('Urgent Bank KYC Freeze Release');
    }
  };

  const handlePaySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const numericAmount = Number(amount);
    if (!Number.isFinite(numericAmount) || numericAmount <= 0) {
      setPayError('Please enter a valid positive amount in INR.');
      return;
    }
    if (beneficiaryId === 'BEN_CUSTOM' && !customVpa.trim().includes('@')) {
      setPayError('Enter a valid custom UPI handle (e.g. merchant@okaxis).');
      return;
    }

    setSubmitting(true);
    setPayError(null);
    setSafeSuccessSession(null);

    try {
      const token = await getIdToken();
      const res = await paymentService.initiatePayment(
        {
          customer_id: activeProfile.customer_id,
          beneficiary_id: beneficiaryId,
          amount: numericAmount,
          currency: 'INR',
          purpose: purpose.trim() || 'UPI Transfer',
          language,
          channel: device.channel,
          custom_vpa: beneficiaryId === 'BEN_CUSTOM' ? customVpa.trim() : undefined,
        },
        token
      );

      const newSession: SimulatedPaymentSession = {
        payment_id: res.payment_id,
        customer_id: activeProfile.customer_id,
        beneficiary_id: beneficiaryId,
        beneficiary_name:
          CANONICAL_BENEFICIARIES.find((b) => b.beneficiary_id === beneficiaryId)?.name ||
          customVpa.trim() ||
          beneficiaryId,
        beneficiary_vpa:
          CANONICAL_BENEFICIARIES.find((b) => b.beneficiary_id === beneficiaryId)?.vpa || customVpa.trim(),
        amount: numericAmount,
        currency: 'INR',
        purpose: purpose.trim() || 'UPI Transfer',
        language,
        channel: device.channel,
        status: res.status,
        created_at: new Date().toISOString(),
        is_simulated: true,
        initial_assessment: res.initial_assessment,
        final_assessment: res.initial_assessment,
        answers: [],
      };

      const isSafe =
        res.initial_assessment.risk_level === 'LOW' &&
        res.initial_assessment.recommended_action === 'ALLOW' &&
        !res.next_question;

      if (isSafe) {
        const decisionRes = await paymentService.recordDecision(
          res.payment_id,
          'CONTINUE_SIMULATED',
          token
        );
        const completedSession: SimulatedPaymentSession = {
          ...newSession,
          customer_choice: 'CONTINUE_SIMULATED',
          status: decisionRes.status,
        };
        setSafeSuccessSession(completedSession);
        await loadAccount(true);
      } else {
        // Unsafe range: Pop up interactive security check + questions + actions automatically
        setPopupSession(newSession);
        setPopupQuestion(res.next_question);
        setIsPopupOpen(true);
        await loadAccount(true);
      }
    } catch (err: any) {
      setPayError(err?.message || 'Unable to process payment check.');
    } finally {
      setSubmitting(false);
    }
  };

  const handlePopupSessionUpdated = (updated: SimulatedPaymentSession) => {
    setPopupSession(updated);
    loadAccount(true);
  };

  const transactions = accountSummary?.transactions || [];
  const selectedTx = transactions.find((t) => t.payment_id === selectedTxId) || null;

  return (
    <div className="space-y-6">
      {/* Header & Account Profile Strip */}
      <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-4 border-b border-slate-800 pb-5">
        <div className="space-y-1.5">
          <div className="flex flex-wrap items-center gap-x-2.5 gap-y-1 text-xs text-sky-300 font-medium">
            <UserCheck className="w-4 h-4" />
            <span>Signed In Account: {activeProfile.customer_id}</span>
            <span aria-hidden="true">·</span>
            <span className="font-mono text-slate-300">{accountSummary?.vpa || `${activeProfile.customer_id.toLowerCase()}@okupi`}</span>
            <span aria-hidden="true">·</span>
            <span className="inline-flex items-center gap-1 text-slate-300">
              {device.deviceType === 'PHONE' ? (
                <Smartphone className="w-3.5 h-3.5 text-sky-400" />
              ) : (
                <Laptop className="w-3.5 h-3.5 text-sky-400" />
              )}
              <span>Auto-Detected: {device.label}</span>
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-50">
            Welcome back, {activeProfile.name}
          </h1>
          <p className="text-sm text-slate-400">
            {activeProfile.occupation} · Baseline Median ₹
            {activeProfile.baseline_amount_median.toLocaleString('en-IN')} · Usual Active Hours{' '}
            {activeProfile.usual_active_hours[0]}:00–
            {activeProfile.usual_active_hours[activeProfile.usual_active_hours.length - 1]}:00
          </p>
        </div>

        <div className="flex items-center gap-2 self-start lg:self-auto">
          <div className="flex items-center gap-1 p-1 bg-slate-900 border border-slate-800 rounded-lg">
            {(
              [
                { code: 'en', label: 'English' },
                { code: 'te', label: 'తెలుగు' },
                { code: 'hi', label: 'हिन्दी' },
              ] as const
            ).map((item) => (
              <button
                key={item.code}
                type="button"
                onClick={() => {
                  userSwitchedLangRef.current = true;
                  setLanguage(item.code);
                }}
                className={`px-3 py-1.5 rounded-md text-xs font-semibold min-h-[36px] ${
                  language === item.code ? 'bg-sky-600 text-white' : 'text-slate-300 hover:bg-slate-800'
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>
          <button
            type="button"
            onClick={() => loadAccount(false)}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-slate-700 bg-slate-900 hover:bg-slate-800 text-xs font-medium text-slate-200 min-h-[38px]"
          >
            <RefreshCw className={`w-3.5 h-3.5 text-sky-400 ${loadingAccount ? 'animate-spin' : ''}`} />
            <span>Refresh</span>
          </button>
        </div>
      </div>

      {accountError && (
        <div role="alert" className="rounded-lg border border-rose-500/40 bg-rose-950/30 px-4 py-3 text-sm text-rose-200">
          {accountError}
        </div>
      )}

      {/* Account Risk Score & Account Standing Metrics */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-4">
          <div className="text-xs text-slate-400">Account Average Risk Score</div>
          <div className="text-2xl font-bold font-mono tabular-nums text-slate-50 mt-1">
            {accountSummary?.average_risk_score ?? 0}
            <span className="text-xs font-normal text-slate-400"> / 100</span>
          </div>
          <div className="text-xs text-slate-400 mt-0.5 tabular-nums">
            Latest Txn Score: {accountSummary?.latest_risk_score ?? 0}/100
          </div>
        </div>

        <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-4">
          <div className="text-xs text-slate-400">30-Day Spending Baseline</div>
          <div className="text-2xl font-bold font-mono tabular-nums text-sky-300 mt-1">
            ₹{activeProfile.baseline_amount_median.toLocaleString('en-IN')}
          </div>
          <div className="text-xs text-slate-400 mt-0.5 tabular-nums">
            {activeProfile.baseline_txn_count_30d} txns · MAD ₹{activeProfile.baseline_amount_mad}
          </div>
        </div>

        <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-4">
          <div className="text-xs text-slate-400">Pending Bank Reviews</div>
          <div className="text-2xl font-bold font-mono tabular-nums text-amber-300 mt-1">
            {accountSummary?.pending_review_count ?? 0}
          </div>
          <div className="text-xs text-slate-400 mt-0.5">
            {accountSummary?.pending_review_count ? 'Auto-syncing bank verdict' : 'No pending escalations'}
          </div>
        </div>

        <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-4">
          <div className="text-xs text-slate-400">Total Logged Transactions</div>
          <div className="text-2xl font-bold font-mono tabular-nums text-emerald-300 mt-1">
            {accountSummary?.total_transactions ?? 0}
          </div>
          <div className="text-xs text-slate-400 mt-0.5 tabular-nums">
            Approved: {accountSummary?.approved_count ?? 0} · Stopped: {accountSummary?.terminated_count ?? 0}
          </div>
        </div>
      </div>

      {/* Main Split: Initiate Protected Payment (left) + Previous Transactions (right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left: Make Payment Form (auto-fills logged-in user + device) */}
        <section className="lg:col-span-5 rounded-xl border border-slate-800 bg-slate-900/75 p-5 sm:p-6 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <h2 className="text-lg font-bold text-slate-50 flex items-center gap-2">
              <Send className="w-4 h-4 text-sky-400" />
              <span>Send UPI Payment</span>
            </h2>
            <span className="text-xs font-mono text-slate-400">Channel: {device.channel}</span>
          </div>

          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              onClick={() => applyPaymentPreset('safe')}
              className="px-3 py-1.5 rounded-lg border border-emerald-500/30 bg-emerald-950/30 hover:bg-emerald-900/40 text-emerald-200 text-xs font-medium min-h-[36px]"
            >
              Quick Fill: Safe Pay (₹350)
            </button>
            <button
              type="button"
              onClick={() => applyPaymentPreset('scam')}
              className="px-3 py-1.5 rounded-lg border border-rose-500/30 bg-rose-950/30 hover:bg-rose-900/40 text-rose-200 text-xs font-medium min-h-[36px]"
            >
              Test Unsafe: Digital Arrest (₹75,000)
            </button>
            <button
              type="button"
              onClick={() => applyPaymentPreset('kyc')}
              className="px-3 py-1.5 rounded-lg border border-amber-500/30 bg-amber-950/30 hover:bg-amber-900/40 text-amber-200 text-xs font-medium min-h-[36px]"
            >
              Test Unsafe: Fake KYC (₹48,000)
            </button>
          </div>

          <form onSubmit={handlePaySubmit} className="space-y-4">
            <div className="rounded-lg border border-slate-800 bg-slate-950/70 px-3.5 py-2.5 text-xs text-slate-300 space-y-0.5">
              <div className="text-slate-400">Paying From (Auto-Linked Account)</div>
              <div className="font-semibold text-slate-100">
                {activeProfile.name} · <span className="font-mono text-sky-300">{activeProfile.customer_id}</span>
              </div>
              <div className="text-slate-400">Device: {device.label}</div>
            </div>

            <div className="space-y-1.5">
              <label htmlFor="user-pay-beneficiary" className="block text-sm font-medium text-slate-200">
                Beneficiary Account
              </label>
              <select
                id="user-pay-beneficiary"
                value={beneficiaryId}
                onChange={(e) => setBeneficiaryId(e.target.value)}
                className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3.5 py-2.5 text-sm text-slate-100 min-h-[44px] focus:outline-none focus:ring-2 focus:ring-sky-500"
              >
                {CANONICAL_BENEFICIARIES.map((b) => (
                  <option key={b.beneficiary_id} value={b.beneficiary_id}>
                    {b.name} ({b.vpa})
                  </option>
                ))}
                <option value="BEN_CUSTOM">Custom Recipient VPA</option>
              </select>
            </div>

            {beneficiaryId === 'BEN_CUSTOM' && (
              <div className="space-y-1.5">
                <label htmlFor="user-custom-vpa" className="block text-sm font-medium text-slate-200">
                  Custom Recipient VPA
                </label>
                <input
                  id="user-custom-vpa"
                  type="text"
                  value={customVpa}
                  onChange={(e) => setCustomVpa(e.target.value)}
                  placeholder="recipient@okaxis"
                  className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3.5 py-2.5 text-sm font-mono text-slate-100 min-h-[44px]"
                />
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              <div className="space-y-1.5">
                <label htmlFor="user-pay-amount" className="block text-sm font-medium text-slate-200">
                  Amount (INR)
                </label>
                <input
                  id="user-pay-amount"
                  type="number"
                  min="1"
                  step="1"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3.5 py-2.5 text-base font-mono tabular-nums text-slate-100 min-h-[44px]"
                />
              </div>
              <div className="space-y-1.5">
                <label htmlFor="user-pay-purpose" className="block text-sm font-medium text-slate-200">
                  Purpose
                </label>
                <input
                  id="user-pay-purpose"
                  type="text"
                  value={purpose}
                  onChange={(e) => setPurpose(e.target.value)}
                  className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3.5 py-2.5 text-sm text-slate-100 min-h-[44px]"
                />
              </div>
            </div>

            {payError && (
              <div role="alert" className="rounded-lg border border-rose-500/40 bg-rose-950/35 px-3.5 py-2.5 text-sm text-rose-200">
                {payError}
              </div>
            )}

            <button
              type="submit"
              disabled={submitting}
              className="w-full inline-flex items-center justify-center gap-2 rounded-lg bg-sky-600 hover:bg-sky-500 disabled:opacity-60 px-5 py-3 text-sm font-semibold text-white min-h-[48px] transition-colors"
            >
              <ShieldCheck className="w-4 h-4" />
              <span>{submitting ? 'Evaluating Risk...' : 'Pay & Evaluate Risk'}</span>
            </button>
          </form>

          {safeSuccessSession && (
            <div
              role="status"
              className="rounded-lg border border-emerald-500/40 bg-emerald-950/30 px-4 py-3 text-sm text-emerald-100 flex items-start gap-2.5"
            >
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <div>
                <div className="font-semibold">
                  Safe Payment Processed (Risk Score: {safeSuccessSession.initial_assessment?.overall_risk_score}/100)
                </div>
                <div className="text-xs text-emerald-200/80 mt-0.5">
                  ₹{safeSuccessSession.amount.toLocaleString('en-IN')} to {safeSuccessSession.beneficiary_name} cleared
                  without interruption.
                </div>
              </div>
            </div>
          )}
        </section>

        {/* Right: Previous Transactions & Live Status */}
        <section className="lg:col-span-7 rounded-xl border border-slate-800 bg-slate-900/75 p-5 sm:p-6 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <h2 className="text-lg font-bold text-slate-50">Previous Transactions & Risk History</h2>
              <p className="text-xs text-slate-400">
                Persisted in Cloud SQL PostgreSQL. Pending bank reviews update automatically when reviewed.
              </p>
            </div>
          </div>

          {loadingAccount && transactions.length === 0 ? (
            <div className="py-10 text-center text-sm text-slate-400">
              Loading your account risk score and transaction history...
            </div>
          ) : transactions.length === 0 ? (
            <div className="py-10 text-center text-sm text-slate-400">
              No transactions recorded yet for {activeProfile.name}.
            </div>
          ) : (
            <div className="overflow-x-auto max-h-[480px] overflow-y-auto rounded-xl border border-slate-800 bg-slate-950/50">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-800 text-xs font-medium text-slate-400 bg-slate-950/80">
                    <th className="py-3 px-3.5">Beneficiary & Purpose</th>
                    <th className="py-3 px-3.5 text-right">Amount</th>
                    <th className="py-3 px-3.5">Risk Score</th>
                    <th className="py-3 px-3.5">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/80 text-sm">
                  {transactions.map((tx) => {
                    const asm = tx.final_assessment || tx.initial_assessment;
                    const score = asm?.overall_risk_score ?? 0;
                    const riskLevel = asm?.risk_level || 'LOW';
                    const statusInfo = renderStatusLabel(tx.status);
                    const isSelected = selectedTxId === tx.payment_id;
                    return (
                      <tr
                        key={tx.payment_id}
                        onClick={() => setSelectedTxId(isSelected ? null : tx.payment_id)}
                        className={`cursor-pointer transition-colors ${
                          isSelected ? 'bg-slate-800/70' : 'hover:bg-slate-800/35'
                        }`}
                      >
                        <td className="py-3 px-3.5 align-top">
                          <div className="font-medium text-slate-100">
                            {tx.beneficiary_name || tx.beneficiary_id}
                          </div>
                          <div className="text-xs text-slate-400 mt-0.5 max-w-[240px] truncate">{tx.purpose}</div>
                          <div className="text-[11px] font-mono text-slate-500 mt-0.5">
                            {tx.payment_id} · {tx.channel}
                          </div>
                        </td>
                        <td className="py-3 px-3.5 text-right align-top font-mono tabular-nums font-semibold text-slate-100 whitespace-nowrap">
                          ₹{tx.amount.toLocaleString('en-IN')}
                        </td>
                        <td className="py-3 px-3.5 align-top font-mono tabular-nums whitespace-nowrap">
                          <span
                            className={`text-xs font-bold ${
                              riskLevel === 'HIGH'
                                ? 'text-rose-300'
                                : riskLevel === 'MEDIUM'
                                ? 'text-amber-300'
                                : 'text-emerald-300'
                            }`}
                          >
                            {score}/100 ({riskLevel})
                          </span>
                          {asm && (
                            <div className="text-[11px] text-slate-400 mt-0.5">
                              {asm.component_scores.transaction_anomaly_score} /{' '}
                              {asm.component_scores.beneficiary_risk_score} /{' '}
                              {asm.component_scores.coercion_risk_score ?? '—'}
                            </div>
                          )}
                        </td>
                        <td className="py-3 px-3.5 align-top">
                          <div className={`text-xs inline-flex items-center gap-1.5 ${statusInfo.toneClass}`}>
                            {tx.status === 'TERMINATED_SCAM' ? (
                              <XCircle className="w-3.5 h-3.5 shrink-0" />
                            ) : tx.status === 'APPROVED_BY_BANK' || tx.status === 'SIMULATION_CONTINUED' ? (
                              <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                            ) : tx.status === 'REFERRED_FOR_REVIEW' ? (
                              <Clock className="w-3.5 h-3.5 shrink-0" />
                            ) : (
                              <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                            )}
                            <span>{statusInfo.text}</span>
                          </div>
                          {tx.feedback?.notes && (
                            <div className="text-[11px] text-slate-400 mt-0.5 max-w-[200px] truncate">
                              {tx.feedback.notes}
                            </div>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}

          {selectedTx && (
            <div className="rounded-xl border border-slate-800 bg-slate-950/70 p-4 space-y-2 text-xs">
              <div className="flex items-center justify-between text-slate-200 font-semibold">
                <span>Transaction Risk Audit: {selectedTx.payment_id}</span>
                <span className="font-mono text-slate-400">{selectedTx.created_at}</span>
              </div>
              <div className="text-slate-300">
                Reason Codes:{' '}
                <span className="font-mono text-sky-300">
                  {(selectedTx.final_assessment || selectedTx.initial_assessment)?.reason_codes.join(' · ') || 'NONE'}
                </span>
              </div>
              {(selectedTx.final_assessment || selectedTx.initial_assessment)?.explanations.map((line, i) => (
                <div key={i} className="text-slate-400">
                  • {line}
                </div>
              ))}
            </div>
          )}
        </section>
      </div>

      {/* Automatic Risk Pop-Up Modal when payment risk is unsafe */}
      <PaymentRiskPopupModal
        isOpen={isPopupOpen}
        session={popupSession}
        initialQuestion={popupQuestion}
        deviceLabel={device.label}
        deviceType={device.deviceType}
        language={language}
        getToken={getIdToken}
        onSessionUpdated={handlePopupSessionUpdated}
        onClose={() => {
          setIsPopupOpen(false);
          loadAccount(true);
        }}
      />
    </div>
  );
};
