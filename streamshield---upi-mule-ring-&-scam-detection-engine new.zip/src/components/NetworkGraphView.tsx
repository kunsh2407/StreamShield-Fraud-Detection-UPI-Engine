import React from 'react';
import { ShieldAlert, Snowflake } from 'lucide-react';
import { GraphEdge, GraphNode } from '../types';

interface NetworkGraphViewProps {
  nodes: GraphNode[];
  edges: GraphEdge[];
  onSelectNode: (node: GraphNode) => void;
}

export const NetworkGraphView: React.FC<NetworkGraphViewProps> = ({
  nodes,
  edges,
  onSelectNode,
}) => {
  const visibleNodes = nodes.slice(0, 32);
  const nodeMap = new Map<string, GraphNode>(visibleNodes.map((n) => [n.id, n]));
  const visibleEdges = edges
    .filter((e) => nodeMap.has(e.source) && nodeMap.has(e.target))
    .slice(0, 48);

  return (
    <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-4 sm:p-5 space-y-3">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div>
          <h2 className="text-base font-semibold text-slate-100">
            Beneficiary & Mule Ring Graph
          </h2>
          <p className="text-xs text-slate-400">
            Click any mule or high-degree node to inspect downstream trail and trigger a cascade freeze.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-3 text-xs text-slate-400">
          <span className="inline-flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400" />
            <span>Genuine</span>
          </span>
          <span className="inline-flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-rose-500" />
            <span>Suspected Mule</span>
          </span>
          <span className="inline-flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-sky-400" />
            <span>Frozen</span>
          </span>
        </div>
      </div>

      {visibleNodes.length === 0 ? (
        <div className="h-[340px] rounded-lg border border-slate-800 bg-slate-950/80 flex flex-col items-center justify-center text-center p-6 space-y-2">
          <ShieldAlert className="w-7 h-7 text-slate-500" />
          <p className="text-sm text-slate-300 font-medium">No transactions in the graph yet</p>
          <p className="text-xs text-slate-500 max-w-sm">
            Start the stream or inject a batch (+25 Tx) to watch fan-in mule hubs and circular smurfing rings form in real time.
          </p>
        </div>
      ) : (
        <div className="relative rounded-lg border border-slate-800 bg-slate-950 overflow-hidden">
          <svg
            viewBox="0 0 680 420"
            className="w-full h-[340px] select-none"
            role="img"
            aria-label="Mule transaction graph visualization"
          >
            <defs>
              <marker
                id="arrow-fraud"
                viewBox="0 0 10 10"
                refX="8"
                refY="5"
                markerWidth="5"
                markerHeight="5"
                orient="auto-start-reverse"
              >
                <path d="M 0 1 L 10 5 L 0 9 z" fill="#f43f5e" />
              </marker>
              <marker
                id="arrow-clean"
                viewBox="0 0 10 10"
                refX="8"
                refY="5"
                markerWidth="5"
                markerHeight="5"
                orient="auto-start-reverse"
              >
                <path d="M 0 1 L 10 5 L 0 9 z" fill="#475569" />
              </marker>
            </defs>

            {visibleEdges.map((edge) => {
              const s = nodeMap.get(edge.source);
              const t = nodeMap.get(edge.target);
              if (!s || !t) return null;
              const isRisky = edge.decision === 'HOLD' || edge.isFraud;
              return (
                <line
                  key={edge.id}
                  x1={s.x}
                  y1={s.y}
                  x2={t.x}
                  y2={t.y}
                  stroke={isRisky ? '#f43f5e' : '#334155'}
                  strokeWidth={isRisky ? 1.8 : 1}
                  strokeOpacity={isRisky ? 0.8 : 0.45}
                  markerEnd={isRisky ? 'url(#arrow-fraud)' : 'url(#arrow-clean)'}
                />
              );
            })}

            {visibleNodes.map((node) => {
              const fill =
                node.type === 'frozen'
                  ? '#38bdf8'
                  : node.type === 'mule'
                  ? '#f43f5e'
                  : '#10b981';
              const radius = node.type === 'mule' || node.inDegree >= 3 ? 11 : 7;
              return (
                <g
                  key={node.id}
                  transform={`translate(${node.x}, ${node.y})`}
                  onClick={() => onSelectNode(node)}
                  className="cursor-pointer"
                >
                  <circle
                    r={radius}
                    fill={fill}
                    fillOpacity={0.9}
                    stroke="#020617"
                    strokeWidth={2}
                  />
                  <text
                    y={radius + 12}
                    textAnchor="middle"
                    className="fill-slate-300 text-[9px] font-mono"
                  >
                    {node.label.slice(0, 14)}
                  </text>
                </g>
              );
            })}
          </svg>

          <div className="px-3.5 py-2 border-t border-slate-800 bg-slate-900/90 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-400">
            <span className="font-mono tabular-nums">
              Nodes: {nodes.length} · Directed Edges: {edges.length}
            </span>
            <span className="inline-flex items-center gap-1 text-sky-300">
              <Snowflake className="w-3.5 h-3.5" />
              <span>Select node to inspect & freeze</span>
            </span>
          </div>
        </div>
      )}
    </div>
  );
};
