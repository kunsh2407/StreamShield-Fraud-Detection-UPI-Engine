import React from 'react';
import { ShieldAlert, X } from 'lucide-react';
import { ScoredTransaction } from '../types';

interface ScamPauseModalProps {
  transaction: ScoredTransaction | null;
  onClose: () => void;
  onFreezeReceiver: (vpa: string) => void;
}

export const ScamPauseModal: React.FC<ScamPauseModalProps> = ({
  transaction,
  onClose,
  onFreezeReceiver,
}) => {
  if (!transaction) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="scam-pause-title"
      className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4"
    >
      <div className="w-full max-w-lg rounded-xl border border-rose-500/40 bg-slate-900 p-6 space-y-5 shadow-2xl">
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-rose-500/20 border border-rose-500/40 flex items-center justify-center text-rose-300">
              <ShieldAlert className="w-5 h-5" />
            </div>
            <div>
              <h2 id="scam-pause-title" className="text-lg font-bold text-slate-50">
                Pre-Payment Safety Pause Triggered
              </h2>
              <p className="text-xs text-slate-400 font-mono">
                {transaction.tx_id} · Risk {(transaction.risk_score * 100).toFixed(0)}/100
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close safety pause preview"
            className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="rounded-lg border border-slate-800 bg-slate-950 p-4 space-y-2 text-sm">
          <div className="flex justify-between">
            <span className="text-slate-400">Simulated Payee</span>
            <span className="font-mono text-slate-100">{transaction.receiver}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-400">Amount</span>
            <span className="font-mono tabular-nums font-bold text-rose-300">
              ₹{transaction.amount.toLocaleString('en-IN')}
            </span>
          </div>
        </div>

        <ul className="space-y-1.5 text-sm text-slate-300">
          {transaction.reasons.map((r, i) => (
            <li key={i}>• {r}</li>
          ))}
        </ul>

        <div className="flex flex-wrap justify-end gap-3 pt-2 border-t border-slate-800">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2.5 rounded-lg border border-slate-700 bg-slate-950 hover:bg-slate-800 text-slate-200 text-sm font-medium min-h-[42px]"
          >
            Close Preview
          </button>
          <button
            type="button"
            onClick={() => {
              onFreezeReceiver(transaction.receiver);
              onClose();
            }}
            className="px-4 py-2.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white text-sm font-semibold min-h-[42px]"
          >
            Freeze Payee Mule Trail
          </button>
        </div>
      </div>
    </div>
  );
};
