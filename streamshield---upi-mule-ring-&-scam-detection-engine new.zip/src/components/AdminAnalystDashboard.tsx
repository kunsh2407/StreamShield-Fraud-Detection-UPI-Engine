import React, { useEffect, useMemo, useState } from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  ClipboardCheck,
  RefreshCw,
  Search,
  XCircle,
} from 'lucide-react';
import {
  AdminMetricsSummary,
  FeedbackOutcome,
  RiskLevel,
  SimulatedPaymentSession,
} from '../types';
import { paymentService } from '../services/paymentService';
import { useAuth } from '../context/AuthContext';

interface AdminAnalystDashboardProps {
  localSessions: SimulatedPaymentSession[];
  onUpdateLocalSession: (session: SimulatedPaymentSession) => void;
}

type QueueFilter = 'ALL' | 'PENDING_REVIEW' | RiskLevel;

export const AdminAnalystDashboard: React.FC<AdminAnalystDashboardProps> = ({
  localSessions,
  onUpdateLocalSession,
}) => {
  const { user, getIdToken } = useAuth();
  const [serverAlerts, setServerAlerts] = useState<SimulatedPaymentSession[]>([]);
  const [serverMetrics, setServerMetrics] = useState<AdminMetricsSummary | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [riskFilter, setRiskFilter] = useState<QueueFilter>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [savingId, setSavingId] = useState<string | null>(null);

  const loadServerData = async () => {
    if (!user || user.role !== 'ADMIN') return;
    setLoading(true);
    setError(null);
    try {
      const token = await getIdToken();
      if (!token) return;
      const [alertsRes, metricsRes] = await Promise.all([
        paymentService.fetchAdminAlerts(token),
        paymentService.fetchAdminMetrics(token),
      ]);
      setServerAlerts(alertsRes.items || []);
      setServerMetrics(metricsRes);
    } catch (err: any) {
      setError(err?.message || 'Unable to load analyst queue.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (user?.role === 'ADMIN') {
      loadServerData();
    }
  }, [user?.uid, user?.role]);

  const combinedSessions = useMemo(() => {
    const map = new Map<string, SimulatedPaymentSession>();
    for (const s of serverAlerts) {
      map.set(s.payment_id, s);
    }
    for (const l of localSessions) {
      if (!map.has(l.payment_id)) {
        map.set(l.payment_id, l);
      }
    }
    // Sort Pending Bank Review items first, then newest first
    return Array.from(map.values()).sort((a, b) => {
      const aPending = a.status === 'REFERRED_FOR_REVIEW' ? 1 : 0;
      const bPending = b.status === 'REFERRED_FOR_REVIEW' ? 1 : 0;
      if (aPending !== bPending) return bPending - aPending;
      return b.created_at.localeCompare(a.created_at);
    });
  }, [serverAlerts, localSessions]);

  const filteredSessions = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return combinedSessions.filter((s) => {
      const assessment = s.final_assessment || s.initial_assessment;
      if (riskFilter === 'PENDING_REVIEW') {
        if (s.status !== 'REFERRED_FOR_REVIEW') return false;
      } else if (riskFilter !== 'ALL' && assessment?.risk_level !== riskFilter) {
        return false;
      }
      if (!q) return true;
      return (
        s.payment_id.toLowerCase().includes(q) ||
        s.customer_id.toLowerCase().includes(q) ||
        s.beneficiary_id.toLowerCase().includes(q) ||
        (s.beneficiary_name || '').toLowerCase().includes(q) ||
        s.purpose.toLowerCase().includes(q)
      );
    });
  }, [combinedSessions, riskFilter, searchQuery]);

  const pendingReviewCount = useMemo(
    () => combinedSessions.filter((s) => s.status === 'REFERRED_FOR_REVIEW').length,
    [combinedSessions]
  );

  const computedStats = useMemo(() => {
    if (serverMetrics && user?.role === 'ADMIN') {
      return {
        totalPayments: serverMetrics.total_payments,
        highRiskCount: serverMetrics.count_by_risk_level?.HIGH ?? 0,
        avgLatencyMs: serverMetrics.avg_scoring_latency_ms,
        p99LatencyMs: serverMetrics.p99_scoring_latency_ms,
      };
    }

    const latencies = combinedSessions
      .map((s) => (s.final_assessment || s.initial_assessment)?.scoring_latency_ms)
      .filter((v): v is number => typeof v === 'number');
    const sorted = [...latencies].sort((a, b) => a - b);
    const avg = latencies.length ? latencies.reduce((a, b) => a + b, 0) / latencies.length : 0;
    const p99 = sorted.length ? sorted[Math.min(sorted.length - 1, Math.floor(sorted.length * 0.99))] : 0;
    const highCount = combinedSessions.filter(
      (s) => (s.final_assessment || s.initial_assessment)?.risk_level === 'HIGH'
    ).length;

    return {
      totalPayments: combinedSessions.length,
      highRiskCount: highCount,
      avgLatencyMs: Number(avg.toFixed(2)),
      p99LatencyMs: Number(p99.toFixed(2)),
    };
  }, [serverMetrics, user?.role, combinedSessions]);

  const handleTagFeedback = async (session: SimulatedPaymentSession, outcome: FeedbackOutcome) => {
    setSavingId(session.payment_id);
    setError(null);
    try {
      const token = await getIdToken();
      const noteText =
        outcome === 'CONFIRMED_LEGITIMATE'
          ? `Bank Admin (${user?.adminId || 'REVIEWER'}): Approved as legitimate — payment proceeded.`
          : `Bank Admin (${user?.adminId || 'REVIEWER'}): Confirmed scam — payment terminated.`;

      const res = await paymentService.submitFeedback(
        session.payment_id,
        outcome,
        'REVIEWER',
        noteText,
        token
      );

      const nextStatus =
        res.updated_status ||
        (session.status === 'REFERRED_FOR_REVIEW'
          ? outcome === 'CONFIRMED_LEGITIMATE'
            ? 'APPROVED_BY_BANK'
            : 'TERMINATED_SCAM'
          : session.status);

      const updated: SimulatedPaymentSession = {
        ...session,
        status: nextStatus,
        feedback: {
          outcome,
          label_source: 'REVIEWER',
          notes: noteText,
        },
      };
      setServerAlerts((prev) => prev.map((p) => (p.payment_id === session.payment_id ? updated : p)));
      onUpdateLocalSession(updated);
    } catch (err: any) {
      setError(err?.message || 'Failed to save bank review decision.');
    } finally {
      setSavingId(null);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 border-b border-slate-800 pb-5">
        <div className="space-y-1.5">
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-50">
            Bank Analyst Alert Queue & Review Console (FES)
          </h1>
          <p className="text-sm text-slate-400">
            Approve legitimate user escalations to let payments proceed, or confirm scam alerts to terminate them immediately.
          </p>
        </div>

        <button
          type="button"
          onClick={loadServerData}
          disabled={loading}
          className="inline-flex items-center gap-2 px-3.5 py-2 rounded-lg border border-slate-700 bg-slate-900 hover:bg-slate-800 text-slate-200 text-sm font-medium min-h-[40px] shrink-0 self-start sm:self-auto"
        >
          <RefreshCw className={`w-4 h-4 text-sky-400 ${loading ? 'animate-spin' : ''}`} />
          <span>Sync Cloud SQL Queue</span>
        </button>
      </div>

      {/* Live Queue Metrics */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-4">
          <div className="text-xs text-slate-400">Pending Bank Review</div>
          <div className="text-2xl font-bold font-mono tabular-nums text-sky-300 mt-1">
            {pendingReviewCount}
          </div>
        </div>
        <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-4">
          <div className="text-xs text-slate-400">Total Monitored Sessions</div>
          <div className="text-2xl font-bold font-mono tabular-nums text-slate-50 mt-1">
            {computedStats.totalPayments}
          </div>
        </div>
        <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-4">
          <div className="text-xs text-slate-400">High-Risk Alerts</div>
          <div className="text-2xl font-bold font-mono tabular-nums text-rose-300 mt-1">
            {computedStats.highRiskCount}
          </div>
        </div>
        <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-4">
          <div className="text-xs text-slate-400">Mean / P99 Latency</div>
          <div className="text-2xl font-bold font-mono tabular-nums text-emerald-300 mt-1">
            {computedStats.avgLatencyMs.toFixed(1)} / {computedStats.p99LatencyMs.toFixed(1)} ms
          </div>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-1 p-1 bg-slate-900 border border-slate-800 rounded-lg self-start">
          {(
            [
              { id: 'ALL', label: 'All' },
              { id: 'PENDING_REVIEW', label: `Pending Review (${pendingReviewCount})` },
              { id: 'HIGH', label: 'High' },
              { id: 'MEDIUM', label: 'Medium' },
              { id: 'LOW', label: 'Low' },
            ] as const
          ).map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => setRiskFilter(item.id)}
              className={`px-3 py-1.5 rounded-md text-xs font-semibold min-h-[36px] transition-colors whitespace-nowrap ${
                riskFilter === item.id
                  ? 'bg-slate-800 text-white'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>

        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search ID, customer, beneficiary..."
            aria-label="Search payment alerts"
            className="w-full rounded-lg border border-slate-700 bg-slate-950 pl-9 pr-3.5 py-2 text-sm text-slate-100 min-h-[40px] focus:outline-none focus:ring-2 focus:ring-sky-500"
          />
        </div>
      </div>

      {error && (
        <div className="rounded-lg border border-rose-500/40 bg-rose-950/30 px-4 py-3 text-sm text-rose-200 flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* Alert Queue Table */}
      {filteredSessions.length === 0 ? (
        <div className="rounded-xl border border-slate-800 bg-slate-900/50 p-10 text-center space-y-2">
          <ClipboardCheck className="w-8 h-8 text-slate-500 mx-auto" />
          <h2 className="text-base font-semibold text-slate-200">No Matching Payment Sessions</h2>
          <p className="text-sm text-slate-400 max-w-md mx-auto">
            User payments escalated via Request Bank Review or scored in Cloud SQL appear here for analyst decisioning.
          </p>
        </div>
      ) : (
        <div className="overflow-x-auto rounded-xl border border-slate-800 bg-slate-900/60">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-xs font-medium text-slate-400 bg-slate-950/60">
                <th className="py-3 px-4">Session & Status</th>
                <th className="py-3 px-4">Payer / Payee</th>
                <th className="py-3 px-4 text-right">Amount</th>
                <th className="py-3 px-4">Scores (TBE/BRE/CCE)</th>
                <th className="py-3 px-4">Risk & Action</th>
                <th className="py-3 px-4">Bank Decision (FES)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80 text-sm">
              {filteredSessions.map((s) => {
                const asm = s.final_assessment || s.initial_assessment;
                const riskLevel = asm?.risk_level || 'LOW';
                const badgeClass =
                  riskLevel === 'HIGH'
                    ? 'text-rose-300'
                    : riskLevel === 'MEDIUM'
                    ? 'text-amber-300'
                    : 'text-emerald-300';
                const statusColor =
                  s.status === 'REFERRED_FOR_REVIEW'
                    ? 'text-sky-300 font-semibold'
                    : s.status === 'APPROVED_BY_BANK'
                    ? 'text-emerald-300 font-semibold'
                    : s.status === 'TERMINATED_SCAM'
                    ? 'text-rose-300 font-semibold'
                    : 'text-slate-400';

                return (
                  <tr key={s.payment_id} className="hover:bg-slate-800/30 transition-colors">
                    <td className="py-3 px-4 align-top">
                      <div className="font-mono text-xs font-semibold text-slate-100">{s.payment_id}</div>
                      <div className={`text-xs mt-0.5 ${statusColor}`}>{s.status.replace(/_/g, ' ')}</div>
                    </td>
                    <td className="py-3 px-4 align-top">
                      <div className="font-mono text-xs text-slate-200">
                        {s.customer_id} → {s.beneficiary_name || s.beneficiary_id}
                      </div>
                      <div className="text-xs text-slate-400 mt-0.5 max-w-[240px] truncate">{s.purpose}</div>
                    </td>
                    <td className="py-3 px-4 text-right align-top font-mono tabular-nums font-semibold text-slate-100 whitespace-nowrap">
                      ₹{s.amount.toLocaleString('en-IN')}
                    </td>
                    <td className="py-3 px-4 align-top font-mono tabular-nums text-xs text-slate-300">
                      {asm ? (
                        <>
                          <div>Overall: {asm.overall_risk_score}/100</div>
                          <div className="text-slate-400">
                            {asm.component_scores.transaction_anomaly_score} /{' '}
                            {asm.component_scores.beneficiary_risk_score} /{' '}
                            {asm.component_scores.coercion_risk_score ?? '—'}
                          </div>
                        </>
                      ) : (
                        '—'
                      )}
                    </td>
                    <td className="py-3 px-4 align-top">
                      <div className={`text-xs font-semibold ${badgeClass}`}>
                        {riskLevel} · {asm?.recommended_action.replace('_', ' ') || 'ALLOW'}
                      </div>
                      <div className="text-xs text-slate-400 mt-0.5 font-mono tabular-nums">
                        {(asm?.scoring_latency_ms ?? 0).toFixed(2)} ms · {s.channel}
                      </div>
                    </td>
                    <td className="py-3 px-4 align-top">
                      {s.feedback && s.status !== 'REFERRED_FOR_REVIEW' ? (
                        <div
                          className={`inline-flex items-center gap-1.5 text-xs font-medium ${
                            s.feedback.outcome === 'CONFIRMED_SCAM' ? 'text-rose-300' : 'text-emerald-300'
                          }`}
                        >
                          {s.feedback.outcome === 'CONFIRMED_SCAM' ? (
                            <XCircle className="w-3.5 h-3.5 shrink-0" />
                          ) : (
                            <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                          )}
                          <span>
                            {s.feedback.outcome.replace(/_/g, ' ')} ({s.feedback.label_source})
                          </span>
                        </div>
                      ) : (
                        <div className="flex flex-wrap gap-1.5">
                          <button
                            type="button"
                            disabled={savingId === s.payment_id}
                            onClick={() => handleTagFeedback(s, 'CONFIRMED_LEGITIMATE')}
                            className="px-2.5 py-1.5 rounded border border-emerald-500/40 bg-emerald-950/40 hover:bg-emerald-900/50 text-emerald-200 text-xs font-semibold whitespace-nowrap"
                          >
                            {s.status === 'REFERRED_FOR_REVIEW' ? 'Legitimate · Proceed' : 'Legitimate'}
                          </button>
                          <button
                            type="button"
                            disabled={savingId === s.payment_id}
                            onClick={() => handleTagFeedback(s, 'CONFIRMED_SCAM')}
                            className="px-2.5 py-1.5 rounded border border-rose-500/40 bg-rose-950/40 hover:bg-rose-900/50 text-rose-200 text-xs font-semibold whitespace-nowrap"
                          >
                            {s.status === 'REFERRED_FOR_REVIEW' ? 'Confirm Scam · Terminate' : 'Confirm Scam'}
                          </button>
                        </div>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};
