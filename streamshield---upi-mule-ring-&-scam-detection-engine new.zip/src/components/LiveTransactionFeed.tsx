import React from 'react';
import { ScoredTransaction } from '../types';

interface LiveTransactionFeedProps {
  transactions: ScoredTransaction[];
  selectedTxId?: string;
  onSelectTx: (tx: ScoredTransaction) => void;
}

export const LiveTransactionFeed: React.FC<LiveTransactionFeedProps> = ({
  transactions,
  selectedTxId,
  onSelectTx,
}) => {
  return (
    <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-4 sm:p-5 space-y-3">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-base font-semibold text-slate-100">
            Real-Time Decision Stream
          </h2>
          <p className="text-xs text-slate-400">
            Select any scored UPI event to view feature attributions and reason codes.
          </p>
        </div>
        <span className="text-xs font-mono tabular-nums text-slate-400">
          Showing latest {Math.min(transactions.length, 30)}
        </span>
      </div>

      {transactions.length === 0 ? (
        <div className="py-10 text-center text-sm text-slate-400 border border-slate-800 rounded-lg bg-slate-950/60">
          Stream is idle. Click <strong className="text-slate-200">+25 Tx</strong> or{' '}
          <strong className="text-slate-200">Start Stream</strong> above to score transactions.
        </div>
      ) : (
        <div className="max-h-[340px] overflow-y-auto rounded-lg border border-slate-800 bg-slate-950">
          <table className="w-full text-left border-collapse text-xs">
            <thead className="sticky top-0 bg-slate-900 border-b border-slate-800 text-slate-400">
              <tr>
                <th className="py-2.5 px-3">Sender → Receiver</th>
                <th className="py-2.5 px-3 text-right">Amount</th>
                <th className="py-2.5 px-3 text-right">Risk</th>
                <th className="py-2.5 px-3">Decision</th>
                <th className="py-2.5 px-3 text-right">Latency</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/70">
              {transactions.slice(0, 30).map((tx) => {
                const isSelected = tx.tx_id === selectedTxId;
                const decisionColor =
                  tx.decision === 'HOLD'
                    ? 'text-rose-300'
                    : tx.decision === 'STEP_UP'
                    ? 'text-amber-300'
                    : 'text-emerald-300';
                return (
                  <tr
                    key={tx.tx_id}
                    onClick={() => onSelectTx(tx)}
                    className={`cursor-pointer transition-colors ${
                      isSelected ? 'bg-sky-950/50' : 'hover:bg-slate-900'
                    }`}
                  >
                    <td className="py-2 px-3 font-mono text-slate-200 max-w-[200px] truncate">
                      {tx.sender.split('@')[0]} → {tx.receiver.split('@')[0]}
                    </td>
                    <td className="py-2 px-3 text-right font-mono tabular-nums text-slate-100">
                      ₹{tx.amount.toLocaleString('en-IN')}
                    </td>
                    <td className="py-2 px-3 text-right font-mono tabular-nums text-slate-200">
                      {(tx.risk_score * 100).toFixed(0)}
                    </td>
                    <td className={`py-2 px-3 font-semibold ${decisionColor}`}>
                      {tx.frozen ? 'FROZEN HOLD' : tx.decision}
                    </td>
                    <td className="py-2 px-3 text-right font-mono tabular-nums text-slate-400">
                      {tx.latency_ms.toFixed(2)} ms
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};
