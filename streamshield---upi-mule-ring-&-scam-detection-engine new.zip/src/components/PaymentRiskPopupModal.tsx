import React, { useState } from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  HelpCircle,
  Mic,
  PauseCircle,
  ShieldAlert,
  Smartphone,
  Laptop,
  Volume2,
  VolumeX,
  X,
} from 'lucide-react';
import {
  AnswerSubmission,
  CanonicalQuestion,
  CustomerChoice,
  InputMode,
  Language,
  QuestionAnswer,
  RiskAssessment,
  SimulatedPaymentSession,
} from '../types';
import { paymentService } from '../services/paymentService';
import { WebSpeechController } from '../utils/speech';

interface PaymentRiskPopupModalProps {
  isOpen: boolean;
  session: SimulatedPaymentSession | null;
  initialQuestion: CanonicalQuestion | null;
  deviceLabel: string;
  deviceType: 'PHONE' | 'LAPTOP';
  language: Language;
  getToken: () => Promise<string | null>;
  onSessionUpdated: (updated: SimulatedPaymentSession) => void;
  onClose: () => void;
}

const MODAL_STRINGS: Record<
  Language,
  {
    headerTitle: string;
    questionStep: string;
    listenBtn: string;
    stopAudioBtn: string;
    voiceBtn: string;
    yesBtn: string;
    noBtn: string;
    notSureBtn: string;
    skipBtn: string;
    helpBtn: string;
    whyFlagged: string;
    actionsPrompt: string;
    proceedBtn: string;
    cancelReportBtn: string;
    reviewBtn: string;
    pauseBtn: string;
    reviewBanner: string;
    cancelBanner: string;
    proceedBanner: string;
    pauseBanner: string;
    doneBtn: string;
  }
> = {
  en: {
    headerTitle: 'Security Check Required Before Payment',
    questionStep: 'Safety Question',
    listenBtn: 'Listen Aloud',
    stopAudioBtn: 'Stop Audio',
    voiceBtn: 'Voice Mode',
    yesBtn: 'Yes',
    noBtn: 'No',
    notSureBtn: 'Not Sure',
    skipBtn: 'Skip',
    helpBtn: 'Need Help',
    whyFlagged: 'Why this payment was flagged',
    actionsPrompt: 'Choose how to handle this payment:',
    proceedBtn: 'Proceed with Payment',
    cancelReportBtn: 'Cancel Payment & Report Fraud',
    reviewBtn: 'Request Bank Review',
    pauseBtn: 'Pause & Verify Later',
    reviewBanner:
      'Sent to Bank Analyst Queue (REFERRED FOR REVIEW). Once the bank marks it Legitimate or Scam, your transaction status will update automatically.',
    cancelBanner: 'Payment cancelled and fraud report logged to protect your account.',
    proceedBanner: 'Payment completed after your confirmation.',
    pauseBanner: 'Payment paused safely so you can verify with family or your bank.',
    doneBtn: 'Return to My Account',
  },
  te: {
    headerTitle: 'చెల్లింపుకు ముందు భద్రతా తనిఖీ అవసరం',
    questionStep: 'భద్రతా ప్రశ్న',
    listenBtn: 'వినండి',
    stopAudioBtn: 'ఆపండి',
    voiceBtn: 'వాయిస్ మోడ్',
    yesBtn: 'అవును',
    noBtn: 'కాదు',
    notSureBtn: 'ఖచ్చితంగా తెలియదు',
    skipBtn: 'దాటవేయి',
    helpBtn: 'సహాయం కావాలి',
    whyFlagged: 'ఈ చెల్లింపును ఎందుకు గుర్తించాము',
    actionsPrompt: 'ఈ చెల్లింపుపై మీ నిర్ణయం ఎంచుకోండి:',
    proceedBtn: 'చెల్లింపు కొనసాగించు',
    cancelReportBtn: 'చెల్లింపు రద్దు చేసి మోసంగా నివేదించు',
    reviewBtn: 'బ్యాంక్ సమీక్ష కోరండి',
    pauseBtn: 'ఆపి తర్వాత తనిఖీ చేయి',
    reviewBanner:
      'మీ చెల్లింపు బ్యాంక్ విశ్లేషకుల సమీక్షకు పంపబడింది (REFERRED FOR REVIEW). బ్యాంక్ ఆమోదించినా లేదా రద్దు చేసినా ఇక్కడ స్థితి అప్‌డేట్ అవుతుంది.',
    cancelBanner: 'చెల్లింపు రద్దు చేయబడింది మరియు మోసం నివేదిక నమోదైంది.',
    proceedBanner: 'మీ నిర్ధారణ తర్వాత చెల్లింపు పూర్తయింది.',
    pauseBanner: 'చెల్లింపు సురక్షితంగా ఆపబడింది.',
    doneBtn: 'నా ఖాతాకు వెళ్ళండి',
  },
  hi: {
    headerTitle: 'भुगतान से पहले सुरक्षा जांच आवश्यक है',
    questionStep: 'सुरक्षा प्रश्न',
    listenBtn: 'सुनें',
    stopAudioBtn: 'ऑडियो रोकें',
    voiceBtn: 'वॉइस मोड',
    yesBtn: 'हाँ',
    noBtn: 'नहीं',
    notSureBtn: 'पक्का नहीं पता',
    skipBtn: 'छोड़ें',
    helpBtn: 'मदद चाहिए',
    whyFlagged: 'यह भुगतान क्यों रोका गया',
    actionsPrompt: 'इस भुगतान के लिए अपना निर्णय चुनें:',
    proceedBtn: 'भुगतान आगे बढ़ाएँ',
    cancelReportBtn: 'भुगतान रद्द करें और धोखाधड़ी रिपोर्ट करें',
    reviewBtn: 'बैंक समीक्षा का अनुरोध करें',
    pauseBtn: 'रोकें और बाद में जांचें',
    reviewBanner:
      'यह भुगतान बैंक विश्लेषक कतार में भेजा गया है (REFERRED FOR REVIEW)। बैंक द्वारा वैध या धोखाधड़ी घोषित करने पर आपकी स्थिति स्वतः अपडेट होगी।',
    cancelBanner: 'भुगतान रद्द कर दिया गया और धोखाधड़ी की रिपोर्ट दर्ज हो गई है।',
    proceedBanner: 'आपकी पुष्टि के बाद भुगतान पूरा हो गया है।',
    pauseBanner: 'भुगतान सुरक्षित रूप से रोक दिया गया है।',
    doneBtn: 'मेरे खाते पर लौटें',
  },
};

export const PaymentRiskPopupModal: React.FC<PaymentRiskPopupModalProps> = ({
  isOpen,
  session,
  initialQuestion,
  deviceLabel,
  deviceType,
  language,
  getToken,
  onSessionUpdated,
  onClose,
}) => {
  const [nextQuestion, setNextQuestion] = useState<CanonicalQuestion | null>(initialQuestion);
  const [currentAssessment, setCurrentAssessment] = useState<RiskAssessment | undefined>(
    session?.final_assessment || session?.initial_assessment
  );
  const [questionsAnswered, setQuestionsAnswered] = useState<number>(session?.answers.length || 0);
  const [inputMode, setInputMode] = useState<InputMode>('TAP');
  const [isSpeaking, setIsSpeaking] = useState<boolean>(false);
  const [submitting, setSubmitting] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [recordedChoice, setRecordedChoice] = useState<CustomerChoice | undefined>(
    session?.customer_choice
  );

  // Sync when a new session opens
  React.useEffect(() => {
    if (isOpen && session) {
      setNextQuestion(initialQuestion);
      setCurrentAssessment(session.final_assessment || session.initial_assessment);
      setQuestionsAnswered(session.answers.length);
      setRecordedChoice(session.customer_choice);
      setErrorMsg(null);
      setIsSpeaking(false);
    }
  }, [isOpen, session?.payment_id, initialQuestion]);

  if (!isOpen || !session || !currentAssessment) return null;

  const copy = MODAL_STRINGS[language];
  const isHigh = currentAssessment.risk_level === 'HIGH';

  const handleAnswer = async (answer: QuestionAnswer) => {
    if (!nextQuestion || submitting) return;
    setSubmitting(true);
    setErrorMsg(null);
    WebSpeechController.stop();
    setIsSpeaking(false);

    const newAnswer: AnswerSubmission = {
      question_id: nextQuestion.question_id,
      answer,
      input_mode: inputMode,
      answered_at: new Date().toISOString(),
    };
    const updatedAnswers = [...session.answers, newAnswer];

    try {
      const token = await getToken();
      const res = await paymentService.submitAnswer(
        session.payment_id,
        {
          question_id: nextQuestion.question_id,
          answer,
          input_mode: inputMode,
        },
        token,
        {
          customer_id: session.customer_id,
          beneficiary_id: session.beneficiary_id,
          amount: session.amount,
          purpose: session.purpose,
          language: session.language,
          answers: updatedAnswers,
        }
      );

      const finalAsm = res.final_assessment || currentAssessment;
      const updatedSession: SimulatedPaymentSession = {
        ...session,
        answers: updatedAnswers,
        status: res.final_assessment ? 'ASSESSMENT_COMPLETE' : 'QUESTIONNAIRE_IN_PROGRESS',
        final_assessment: finalAsm,
      };
      setQuestionsAnswered(res.questions_answered);
      setNextQuestion(res.next_question);
      if (res.final_assessment) {
        setCurrentAssessment(res.final_assessment);
      }
      onSessionUpdated(updatedSession);
    } catch (err: any) {
      setErrorMsg(err?.message || 'Could not record safety answer.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleDecision = async (choice: CustomerChoice, reportFraud = false) => {
    if (submitting) return;
    setSubmitting(true);
    setErrorMsg(null);
    try {
      const token = await getToken();
      const res = await paymentService.recordDecision(session.payment_id, choice, token, {
        reportFraud,
      });
      setRecordedChoice(choice);
      onSessionUpdated({
        ...session,
        final_assessment: currentAssessment,
        customer_choice: choice,
        status: res.status,
        feedback: reportFraud
          ? {
              outcome: 'CONFIRMED_SCAM',
              label_source: 'CUSTOMER',
              notes: 'Customer cancelled payment and reported fraud.',
            }
          : session.feedback,
      });
    } catch (err: any) {
      setErrorMsg(err?.message || 'Unable to record payment decision.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleSpeak = () => {
    if (!nextQuestion) return;
    if (isSpeaking) {
      WebSpeechController.stop();
      setIsSpeaking(false);
      return;
    }
    const text =
      nextQuestion.translations[language] || nextQuestion.audio_prompts[language] || nextQuestion.translations.en;
    setIsSpeaking(true);
    WebSpeechController.speak(text, language);
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="risk-popup-title"
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/85 backdrop-blur-sm p-4 overflow-y-auto"
    >
      <div className="w-full max-w-2xl rounded-2xl border border-slate-700 bg-slate-900 shadow-2xl overflow-hidden my-auto">
        {/* Top Risk Banner */}
        <div
          className={`px-5 py-4 border-b flex items-start justify-between gap-4 ${
            isHigh
              ? 'border-rose-500/40 bg-rose-950/50 text-rose-100'
              : 'border-amber-500/40 bg-amber-950/45 text-amber-100'
          }`}
        >
          <div className="flex items-start gap-3">
            {isHigh ? (
              <ShieldAlert className="w-6 h-6 text-rose-400 shrink-0 mt-0.5" />
            ) : (
              <AlertTriangle className="w-6 h-6 text-amber-400 shrink-0 mt-0.5" />
            )}
            <div>
              <h2 id="risk-popup-title" className="text-lg font-bold text-white">
                {copy.headerTitle}
              </h2>
              <div className="text-xs mt-1 flex flex-wrap items-center gap-x-2 gap-y-1 text-slate-200 tabular-nums">
                <span>
                  {currentAssessment.risk_level} RISK ({currentAssessment.overall_risk_score}/100)
                </span>
                <span aria-hidden="true">·</span>
                <span className="font-mono">₹{session.amount.toLocaleString('en-IN')}</span>
                <span aria-hidden="true">·</span>
                <span className="inline-flex items-center gap-1">
                  {deviceType === 'PHONE' ? (
                    <Smartphone className="w-3.5 h-3.5" />
                  ) : (
                    <Laptop className="w-3.5 h-3.5" />
                  )}
                  {deviceLabel}
                </span>
              </div>
            </div>
          </div>
          <button
            type="button"
            onClick={() => {
              WebSpeechController.stop();
              onClose();
            }}
            aria-label="Close security check popup"
            className="p-2 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800/70"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 sm:p-6 space-y-5 max-h-[82vh] overflow-y-auto">
          {/* Component Scores */}
          <div className="grid grid-cols-3 divide-x divide-slate-800 border border-slate-800 rounded-xl bg-slate-950/60 py-3">
            {[
              { label: 'Transaction (TBE)', val: currentAssessment.component_scores.transaction_anomaly_score },
              { label: 'Beneficiary (BRE)', val: currentAssessment.component_scores.beneficiary_risk_score },
              { label: 'Coercion (CCE)', val: currentAssessment.component_scores.coercion_risk_score },
            ].map((item) => (
              <div key={item.label} className="px-3 text-center">
                <div className="text-[11px] text-slate-400">{item.label}</div>
                <div className="text-base font-bold font-mono tabular-nums text-white mt-0.5">
                  {item.val === null ? 'Pending' : `${item.val}/100`}
                </div>
              </div>
            ))}
          </div>

          {/* Why Flagged */}
          <div className="space-y-1.5">
            <div className="text-xs font-semibold text-slate-300">{copy.whyFlagged}</div>
            <ul className="space-y-1 text-sm text-slate-300">
              {currentAssessment.explanations.map((line, i) => (
                <li key={i} className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-sky-400 shrink-0 mt-0.5" />
                  <span>{line}</span>
                </li>
              ))}
            </ul>
          </div>

          {errorMsg && (
            <div role="alert" className="rounded-lg border border-rose-500/40 bg-rose-950/40 px-3.5 py-2 text-sm text-rose-200">
              {errorMsg}
            </div>
          )}

          {/* Questions OR Final Customer Actions */}
          {nextQuestion ? (
            <div className="border-t border-slate-800 pt-4 space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span className="text-xs font-semibold text-sky-300">
                  {copy.questionStep} {questionsAnswered + 1} / 3
                </span>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={handleSpeak}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md border border-slate-700 bg-slate-950 hover:bg-slate-800 text-xs font-medium text-slate-200 min-h-[36px]"
                  >
                    {isSpeaking ? (
                      <>
                        <VolumeX className="w-3.5 h-3.5 text-amber-400" />
                        <span>{copy.stopAudioBtn}</span>
                      </>
                    ) : (
                      <>
                        <Volume2 className="w-3.5 h-3.5 text-sky-400" />
                        <span>{copy.listenBtn}</span>
                      </>
                    )}
                  </button>
                  <button
                    type="button"
                    onClick={() => setInputMode((m) => (m === 'TAP' ? 'VOICE' : 'TAP'))}
                    className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md border text-xs font-medium min-h-[36px] ${
                      inputMode === 'VOICE'
                        ? 'border-sky-500 bg-sky-500/20 text-sky-200'
                        : 'border-slate-700 bg-slate-950 text-slate-300'
                    }`}
                  >
                    <Mic className="w-3.5 h-3.5" />
                    <span>{inputMode === 'VOICE' ? 'Voice On' : copy.voiceBtn}</span>
                  </button>
                </div>
              </div>

              <p className="text-base sm:text-lg font-semibold text-white leading-snug">
                {nextQuestion.translations[language] || nextQuestion.translations.en}
              </p>

              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  disabled={submitting}
                  onClick={() => handleAnswer('YES')}
                  className="min-h-[48px] px-4 py-3 rounded-lg bg-rose-600/90 hover:bg-rose-500 text-white font-semibold text-sm transition-colors"
                >
                  {copy.yesBtn}
                </button>
                <button
                  type="button"
                  disabled={submitting}
                  onClick={() => handleAnswer('NO')}
                  className="min-h-[48px] px-4 py-3 rounded-lg bg-emerald-600/90 hover:bg-emerald-500 text-white font-semibold text-sm transition-colors"
                >
                  {copy.noBtn}
                </button>
              </div>

              <div className="flex flex-wrap gap-2">
                {(
                  [
                    { val: 'NOT_SURE', label: copy.notSureBtn },
                    { val: 'SKIP', label: copy.skipBtn },
                    { val: 'NEED_HELP', label: copy.helpBtn },
                  ] as const
                ).map((opt) => (
                  <button
                    key={opt.val}
                    type="button"
                    disabled={submitting}
                    onClick={() => handleAnswer(opt.val)}
                    className="min-h-[42px] px-3.5 py-2 rounded-lg border border-slate-700 bg-slate-950 hover:bg-slate-800 text-slate-200 text-xs font-medium inline-flex items-center gap-1.5"
                  >
                    <HelpCircle className="w-3.5 h-3.5 text-slate-400" />
                    <span>{opt.label}</span>
                  </button>
                ))}
              </div>
            </div>
          ) : (
            <div className="border-t border-slate-800 pt-4 space-y-4">
              <div className="text-xs font-semibold text-slate-300">{copy.actionsPrompt}</div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <button
                  type="button"
                  disabled={submitting}
                  onClick={() => handleDecision('CANCEL_SIMULATED', true)}
                  className={`min-h-[48px] px-4 py-3 rounded-lg font-semibold text-sm transition-colors ${
                    recordedChoice === 'CANCEL_SIMULATED'
                      ? 'bg-rose-600 text-white ring-2 ring-rose-300'
                      : 'bg-rose-600/90 hover:bg-rose-500 text-white'
                  }`}
                >
                  {copy.cancelReportBtn}
                </button>

                <button
                  type="button"
                  disabled={submitting}
                  onClick={() => handleDecision('REQUEST_BANK_REVIEW')}
                  className={`min-h-[48px] px-4 py-3 rounded-lg border font-semibold text-sm transition-colors ${
                    recordedChoice === 'REQUEST_BANK_REVIEW'
                      ? 'border-sky-300 bg-sky-600 text-white'
                      : 'border-sky-500/50 bg-sky-950/40 hover:bg-sky-900/50 text-sky-100'
                  }`}
                >
                  {copy.reviewBtn}
                </button>

                <button
                  type="button"
                  disabled={submitting}
                  onClick={() => handleDecision('PAUSE_AND_VERIFY')}
                  className={`min-h-[46px] px-4 py-2.5 rounded-lg border font-medium text-sm inline-flex items-center justify-center gap-2 transition-colors ${
                    recordedChoice === 'PAUSE_AND_VERIFY'
                      ? 'border-amber-400 bg-amber-600 text-white'
                      : 'border-amber-500/40 bg-amber-950/30 hover:bg-amber-900/40 text-amber-200'
                  }`}
                >
                  <PauseCircle className="w-4 h-4" />
                  <span>{copy.pauseBtn}</span>
                </button>

                <button
                  type="button"
                  disabled={submitting}
                  onClick={() => handleDecision('CONTINUE_SIMULATED')}
                  className={`min-h-[46px] px-4 py-2.5 rounded-lg border font-medium text-sm transition-colors ${
                    recordedChoice === 'CONTINUE_SIMULATED'
                      ? 'border-emerald-400 bg-emerald-600 text-white'
                      : 'border-slate-700 bg-slate-950 hover:bg-slate-800 text-slate-200'
                  }`}
                >
                  {copy.proceedBtn}
                </button>
              </div>

              {recordedChoice && (
                <div
                  role="status"
                  className="rounded-lg border border-sky-500/35 bg-sky-950/30 px-4 py-3 flex flex-wrap items-center justify-between gap-3 text-sm text-sky-100"
                >
                  <div className="flex items-start gap-2 max-w-md">
                    <CheckCircle2 className="w-4 h-4 text-sky-400 shrink-0 mt-0.5" />
                    <span>
                      {recordedChoice === 'REQUEST_BANK_REVIEW'
                        ? copy.reviewBanner
                        : recordedChoice === 'CANCEL_SIMULATED'
                        ? copy.cancelBanner
                        : recordedChoice === 'PAUSE_AND_VERIFY'
                        ? copy.pauseBanner
                        : copy.proceedBanner}
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={onClose}
                    className="px-4 py-2 rounded-lg bg-sky-600 hover:bg-sky-500 text-white text-xs font-semibold whitespace-nowrap"
                  >
                    {copy.doneBtn}
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
