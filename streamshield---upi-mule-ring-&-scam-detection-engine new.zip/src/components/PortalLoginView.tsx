import React, { useState } from 'react';
import {
  AlertTriangle,
  Building2,
  KeyRound,
  Lock,
  LogIn,
  ShieldCheck,
  UserCheck,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export const PortalLoginView: React.FC = () => {
  const { loginAsUser, loginAsAdmin, signInWithGoogle, authError, clearError } = useAuth();

  const [portalMode, setPortalMode] = useState<'USER' | 'ADMIN'>('USER');

  // UPI User Sign-In State
  const [userIdentifier, setUserIdentifier] = useState<string>('CUS_0001');
  const [userPassword, setUserPassword] = useState<string>('user123');

  // Bank Administrator Sign-In State
  const [adminId, setAdminId] = useState<string>('BANK_ADMIN_01');
  const [adminPassword, setAdminPassword] = useState<string>('admin@2026');

  const [submitting, setSubmitting] = useState<boolean>(false);
  const [localError, setLocalError] = useState<string | null>(null);

  const handleUserSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!userIdentifier.trim() || !userPassword.trim()) {
      setLocalError('Please enter your UPI User ID or handle and passcode.');
      return;
    }
    setSubmitting(true);
    setLocalError(null);
    try {
      await loginAsUser(userIdentifier.trim(), userPassword);
    } catch (err: any) {
      setLocalError(err?.message || 'UPI User sign-in failed.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleAdminSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!adminId.trim() || !adminPassword.trim()) {
      setLocalError('Please enter your Bank Administrator ID and credentials.');
      return;
    }
    setSubmitting(true);
    setLocalError(null);
    try {
      await loginAsAdmin(adminId.trim(), adminPassword);
    } catch (err: any) {
      setLocalError(err?.message || 'Bank Administrator sign-in failed.');
    } finally {
      setSubmitting(false);
    }
  };

  const displayError = localError || authError;

  return (
    <div className="max-w-4xl mx-auto py-1 space-y-4">
      <div className="text-center space-y-1.5 max-w-2xl mx-auto">
        <div className="inline-flex items-center gap-2 text-xs font-semibold text-sky-400">
          <ShieldCheck className="w-4 h-4" />
          <span>StreamShield Dual-Access Security Gateway</span>
        </div>
        <h1 className="text-2xl font-bold tracking-tight text-slate-50 font-['Plus_Jakarta_Sans']">
          Choose Your Access Portal
        </h1>
        <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
          Sign in as a <strong className="text-slate-200">UPI Account Holder</strong> to review your risk standing,
          past transactions, and make protected payments—or sign in as a{' '}
          <strong className="text-slate-200">Bank Administrator</strong> to access live fraud operations, ML ablation,
          and the Analyst Queue.
        </p>
      </div>

      {/* Role Portal Selector */}
      <div className="flex justify-center">
        <div
          role="tablist"
          aria-label="Sign-in portal type"
          className="inline-flex p-1 rounded-xl bg-slate-900 border border-slate-800 gap-1"
        >
          <button
            type="button"
            role="tab"
            aria-selected={portalMode === 'USER'}
            onClick={() => {
              setPortalMode('USER');
              setLocalError(null);
              clearError();
            }}
            className={`inline-flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold min-h-[40px] transition-colors ${
              portalMode === 'USER'
                ? 'bg-sky-600 text-white'
                : 'text-slate-300 hover:text-white hover:bg-slate-800/70'
            }`}
          >
            <UserCheck className="w-4 h-4" />
            <span>UPI User Sign-In</span>
          </button>
          <button
            type="button"
            role="tab"
            aria-selected={portalMode === 'ADMIN'}
            onClick={() => {
              setPortalMode('ADMIN');
              setLocalError(null);
              clearError();
            }}
            className={`inline-flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold min-h-[40px] transition-colors ${
              portalMode === 'ADMIN'
                ? 'bg-amber-600 text-white'
                : 'text-slate-300 hover:text-white hover:bg-slate-800/70'
            }`}
          >
            <Building2 className="w-4 h-4" />
            <span>Bank Administrator Sign-In</span>
          </button>
        </div>
      </div>

      {displayError && (
        <div
          role="alert"
          className="max-w-xl mx-auto rounded-lg border border-rose-500/40 bg-rose-950/35 px-4 py-2.5 text-sm text-rose-200 flex items-center gap-2.5"
        >
          <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
          <span>{displayError}</span>
        </div>
      )}

      {portalMode === 'USER' ? (
        <section
          aria-label="UPI User Sign-In Portal"
          className="max-w-xl mx-auto rounded-xl border border-slate-800 bg-slate-900/75 p-4 sm:p-5 space-y-3"
        >
          <div className="space-y-0.5">
            <h2 className="text-lg font-bold text-slate-50 flex items-center gap-2">
              <UserCheck className="w-5 h-5 text-sky-400" />
              <span>UPI Account Holder Login</span>
            </h2>
            <p className="text-xs text-slate-400">
              View your account profile, past payment risk history, and make device-aware protected transfers.
            </p>
          </div>

          <form onSubmit={handleUserSubmit} className="space-y-3">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1">
                <label htmlFor="user-identifier" className="block text-xs font-medium text-slate-200">
                  Customer ID or UPI Handle
                </label>
                <input
                  id="user-identifier"
                  type="text"
                  value={userIdentifier}
                  onChange={(e) => setUserIdentifier(e.target.value)}
                  placeholder="e.g. CUS_0001"
                  className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm font-mono text-slate-100 min-h-[42px] focus:outline-none focus:ring-2 focus:ring-sky-500"
                />
              </div>

              <div className="space-y-1">
                <label htmlFor="user-password" className="block text-xs font-medium text-slate-200">
                  Account Passcode
                </label>
                <input
                  id="user-password"
                  type="password"
                  value={userPassword}
                  onChange={(e) => setUserPassword(e.target.value)}
                  placeholder="Enter passcode"
                  className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm text-slate-100 min-h-[42px] focus:outline-none focus:ring-2 focus:ring-sky-500"
                />
              </div>
            </div>

            {/* Demo Quick-Fill Accounts */}
            <div className="space-y-1.5">
              <div className="text-xs text-slate-400">Quick-fill synthetic user accounts (passcode: user123):</div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {[
                  { id: 'CUS_0001', name: 'Rama Rao (Senior)', handle: 'rama.rao@okupi' },
                  { id: 'CUS_0002', name: 'Priya Sharma', handle: 'priya.sharma@okupi' },
                  { id: 'CUS_0003', name: 'Ramesh Kumar', handle: 'ramesh.kumar@okupi' },
                  { id: 'CUS_0004', name: 'Sunita Devi', handle: 'sunita.devi@okupi' },
                ].map((acc) => (
                  <button
                    key={acc.id}
                    type="button"
                    onClick={() => {
                      setUserIdentifier(acc.id);
                      setUserPassword('user123');
                      setLocalError(null);
                    }}
                    className={`text-left px-3 py-1.5 rounded-lg border text-xs transition-colors min-h-[38px] ${
                      userIdentifier.toUpperCase() === acc.id
                        ? 'border-sky-500 bg-sky-500/10 text-sky-200'
                        : 'border-slate-800 bg-slate-950/70 text-slate-300 hover:bg-slate-800/70'
                    }`}
                  >
                    <div className="font-semibold">{acc.name}</div>
                    <div className="font-mono text-[11px] text-slate-400">
                      {acc.id} · {acc.handle}
                    </div>
                  </button>
                ))}
              </div>
            </div>

            <button
              type="submit"
              disabled={submitting}
              className="w-full inline-flex items-center justify-center gap-2 rounded-lg bg-sky-600 hover:bg-sky-500 disabled:opacity-60 px-5 py-2.5 text-sm font-semibold text-white min-h-[44px] transition-colors"
            >
              <LogIn className="w-4 h-4" />
              <span>{submitting ? 'Signing In...' : 'Sign In as UPI User'}</span>
            </button>
          </form>

          <div className="pt-3 border-t border-slate-800 space-y-2">
            <div className="text-xs text-slate-400 text-center">Or authenticate via Firebase Google Account</div>
            <button
              type="button"
              onClick={signInWithGoogle}
              className="w-full inline-flex items-center justify-center gap-2 rounded-lg border border-slate-700 bg-slate-950 hover:bg-slate-800 px-4 py-2 text-sm font-medium text-slate-200 min-h-[42px] transition-colors"
            >
              <UserCheck className="w-4 h-4 text-sky-400" />
              <span>Continue with Google (UPI User Session)</span>
            </button>
          </div>
        </section>
      ) : (
        <section
          aria-label="Bank Administrator Sign-In Portal"
          className="max-w-xl mx-auto rounded-xl border border-amber-500/30 bg-slate-900/75 p-6 sm:p-7 space-y-6"
        >
          <div className="space-y-1">
            <h2 className="text-xl font-bold text-slate-50 flex items-center gap-2">
              <Building2 className="w-5 h-5 text-amber-400" />
              <span>Bank Administrator & Fraud Operations Login</span>
            </h2>
            <p className="text-xs text-slate-400">
              Restricted to authorized bank staff. Grants access to Operations Monitor, ML Ablation, Analyst Queue, and
              Ecosystem Controls.
            </p>
          </div>

          <form onSubmit={handleAdminSubmit} className="space-y-4">
            <div className="space-y-1.5">
              <label htmlFor="admin-id" className="block text-sm font-medium text-slate-200">
                Bank Administrator ID
              </label>
              <input
                id="admin-id"
                type="text"
                value={adminId}
                onChange={(e) => setAdminId(e.target.value)}
                placeholder="e.g. BANK_ADMIN_01"
                className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3.5 py-2.5 text-sm font-mono text-slate-100 min-h-[44px] focus:outline-none focus:ring-2 focus:ring-amber-500"
              />
            </div>

            <div className="space-y-1.5">
              <label htmlFor="admin-password" className="block text-sm font-medium text-slate-200">
                Administrator Credentials / Passcode
              </label>
              <input
                id="admin-password"
                type="password"
                value={adminPassword}
                onChange={(e) => setAdminPassword(e.target.value)}
                placeholder="Enter administrator password"
                className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3.5 py-2.5 text-sm text-slate-100 min-h-[44px] focus:outline-none focus:ring-2 focus:ring-amber-500"
              />
            </div>

            <div className="space-y-2 pt-1">
              <div className="text-xs text-slate-400">Authorized Demo Bank Staff IDs (passcode: admin@2026):</div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {[
                  { id: 'BANK_ADMIN_01', title: 'Ananya Verma', role: 'Senior Fraud Ops Officer' },
                  { id: 'BANK_ADMIN_02', title: 'Vikram Nair', role: 'Principal Risk & ML Admin' },
                ].map((adm) => (
                  <button
                    key={adm.id}
                    type="button"
                    onClick={() => {
                      setAdminId(adm.id);
                      setAdminPassword('admin@2026');
                      setLocalError(null);
                    }}
                    className={`text-left px-3 py-2 rounded-lg border text-xs transition-colors min-h-[40px] ${
                      adminId.toUpperCase() === adm.id
                        ? 'border-amber-500 bg-amber-500/10 text-amber-200'
                        : 'border-slate-800 bg-slate-950/70 text-slate-300 hover:bg-slate-800/70'
                    }`}
                  >
                    <div className="font-semibold">{adm.title}</div>
                    <div className="font-mono text-[11px] text-slate-400">
                      {adm.id} · {adm.role}
                    </div>
                  </button>
                ))}
              </div>
            </div>

            <button
              type="submit"
              disabled={submitting}
              className="w-full inline-flex items-center justify-center gap-2 rounded-lg bg-amber-600 hover:bg-amber-500 disabled:opacity-60 px-5 py-3 text-sm font-semibold text-white min-h-[48px] transition-colors"
            >
              <KeyRound className="w-4 h-4" />
              <span>{submitting ? 'Verifying Credentials...' : 'Sign In as Bank Administrator'}</span>
            </button>
          </form>

          <div className="pt-3 border-t border-slate-800 text-xs text-slate-400 flex items-start gap-2">
            <Lock className="w-4 h-4 text-slate-500 shrink-0 mt-0.5" />
            <span>
              Admin credentials enforce server-side RBAC on Operations Analytics, ML Evaluation, and Bank Analyst
              Review verdicts in Cloud SQL PostgreSQL.
            </span>
          </div>
        </section>
      )}
    </div>
  );
};
