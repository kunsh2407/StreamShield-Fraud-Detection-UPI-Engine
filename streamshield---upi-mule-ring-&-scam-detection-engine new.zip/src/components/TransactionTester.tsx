import React from 'react';
import { Sliders, AlertCircle } from 'lucide-react';
import { ScoredTransaction } from '../types';

interface TransactionTesterProps {
  selectedTx: ScoredTransaction | null;
  thresholdStepUp: number;
  thresholdHold: number;
  onChangeThresholds: (stepUp: number, hold: number) => void;
  onOpenScamPauseModal: (tx: ScoredTransaction) => void;
}

export const TransactionTester: React.FC<TransactionTesterProps> = ({
  selectedTx,
  thresholdStepUp,
  thresholdHold,
  onChangeThresholds,
  onOpenScamPauseModal,
}) => {
  return (
    <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-4 sm:p-5 space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-3">
        <div>
          <h2 className="text-base font-semibold text-slate-100">
            Explainability & Adaptive Threshold Control
          </h2>
          <p className="text-xs text-slate-400">
            Inspect feature attribution weights and tune live decision boundaries without offline retraining.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-4 text-xs">
          <label className="flex items-center gap-2 text-slate-300">
            <Sliders className="w-3.5 h-3.5 text-sky-400" />
            <span>Step-Up:</span>
            <input
              type="range"
              min="0.25"
              max="0.65"
              step="0.05"
              value={thresholdStepUp}
              onChange={(e) => onChangeThresholds(Number(e.target.value), thresholdHold)}
              className="w-20 accent-sky-500"
            />
            <span className="font-mono tabular-nums w-8">{(thresholdStepUp * 100).toFixed(0)}</span>
          </label>
          <label className="flex items-center gap-2 text-slate-300">
            <span>Hold:</span>
            <input
              type="range"
              min="0.60"
              max="0.90"
              step="0.05"
              value={thresholdHold}
              onChange={(e) => onChangeThresholds(thresholdStepUp, Number(e.target.value))}
              className="w-20 accent-rose-500"
            />
            <span className="font-mono tabular-nums w-8">{(thresholdHold * 100).toFixed(0)}</span>
          </label>
        </div>
      </div>

      {!selectedTx ? (
        <div className="py-6 text-center text-sm text-slate-400">
          Click a transaction in the Decision Stream to inspect its top reason codes and feature attribution bars.
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="font-mono text-xs text-slate-300">{selectedTx.tx_id}</div>
              <div className="text-xs font-semibold text-sky-300 font-mono tabular-nums">
                Score {(selectedTx.risk_score * 100).toFixed(1)} · {selectedTx.decision}
              </div>
            </div>
            <div className="text-sm text-slate-200 font-mono">
              {selectedTx.sender} → {selectedTx.receiver} (₹{selectedTx.amount.toLocaleString('en-IN')})
            </div>

            <div className="space-y-1.5">
              <div className="text-xs font-semibold text-slate-400">Top Plain-Language Reason Codes</div>
              <ul className="space-y-1.5 text-xs text-slate-200">
                {selectedTx.reasons.map((r, i) => (
                  <li key={i} className="flex items-start gap-2">
                    <AlertCircle className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                    <span>{r}</span>
                  </li>
                ))}
              </ul>
            </div>

            {selectedTx.decision !== 'ALLOW' && (
              <button
                type="button"
                onClick={() => onOpenScamPauseModal(selectedTx)}
                className="px-3.5 py-2 rounded-lg bg-amber-600 hover:bg-amber-500 text-white text-xs font-semibold min-h-[38px]"
              >
                Preview Customer Safety Pause Intervention
              </button>
            )}
          </div>

          <div className="space-y-2.5">
            <div className="text-xs font-semibold text-slate-400">Feature Contribution Weights</div>
            {(selectedTx.shap_contributions || []).map((item) => (
              <div key={item.feature} className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="text-slate-200">
                    {item.feature}{' '}
                    <span className="text-slate-500 font-mono">({item.description})</span>
                  </span>
                  <span className="font-mono tabular-nums text-sky-300">
                    +{Math.round(item.impact * 100)} pts
                  </span>
                </div>
                <div className="h-1.5 rounded-full bg-slate-800 overflow-hidden">
                  <div
                    className="h-full bg-sky-500"
                    style={{ width: `${Math.min(100, item.impact * 280)}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
