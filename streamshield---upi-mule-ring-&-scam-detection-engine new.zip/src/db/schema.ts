import { relations } from 'drizzle-orm';
import {
  boolean,
  integer,
  jsonb,
  numeric,
  pgTable,
  serial,
  text,
  timestamp,
} from 'drizzle-orm/pg-core';

// Authenticated application users linked to Firebase Auth UID
export const users = pgTable('users', {
  id: serial('id').primaryKey(),
  uid: text('uid').notNull().unique(),
  email: text('email').notNull(),
  displayName: text('display_name'),
  createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
});

// 1. Synthetic customer profiles and baselines (Blueprint Section 14)
export const customers = pgTable('customers', {
  customerId: text('customer_id').primaryKey(),
  name: text('name').notNull(),
  preferredLanguage: text('preferred_language').notNull(),
  profileGroup: text('profile_group').notNull(),
  baselineTxnCount30d: integer('baseline_txn_count_30d').notNull(),
  baselineAmountMedian: numeric('baseline_amount_median', { precision: 12, scale: 2 }).notNull(),
  baselineAmountMad: numeric('baseline_amount_mad', { precision: 12, scale: 2 }).notNull(),
  usualActiveHours: jsonb('usual_active_hours').$type<number[]>().notNull(),
  occupation: text('occupation').notNull(),
  age: integer('age').notNull(),
});

// 2. Synthetic beneficiary profiles and network features (Blueprint Section 14)
export const beneficiaries = pgTable('beneficiaries', {
  beneficiaryId: text('beneficiary_id').primaryKey(),
  vpa: text('vpa').notNull(),
  name: text('name').notNull(),
  accountAgeDays: integer('account_age_days'),
  customerCounterparties30d: integer('customer_counterparties_30d').notNull(),
  incomingTxnCount24h: integer('incoming_txn_count_24h').notNull(),
  incomingAmount24h: numeric('incoming_amount_24h', { precision: 14, scale: 2 }).notNull(),
  outgoingAmount24h: numeric('outgoing_amount_24h', { precision: 14, scale: 2 }).notNull(),
  flowThroughRatio: numeric('flow_through_ratio', { precision: 6, scale: 4 }).notNull(),
  networkDegree: integer('network_degree').notNull(),
  syntheticReportCount: integer('synthetic_report_count').notNull(),
  category: text('category').notNull(),
  riskTier: text('risk_tier'),
});

// 3. Simulated payment sessions (Blueprint Section 14)
export const payments = pgTable('payments', {
  paymentId: text('payment_id').primaryKey(),
  userUid: text('user_uid').references(() => users.uid),
  customerId: text('customer_id')
    .references(() => customers.customerId)
    .notNull(),
  beneficiaryId: text('beneficiary_id')
    .references(() => beneficiaries.beneficiaryId)
    .notNull(),
  amount: numeric('amount', { precision: 12, scale: 2 }).notNull(),
  currency: text('currency').notNull().default('INR'),
  purpose: text('purpose'),
  language: text('language').notNull(),
  channel: text('channel').notNull().default('WEB_SIMULATOR'),
  status: text('status').notNull(),
  customerChoice: text('customer_choice'),
  isNewBeneficiary: boolean('is_new_beneficiary').notNull().default(true),
  isSimulated: boolean('is_simulated').notNull().default(true),
  createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
});

// 4. Risk assessments (initial and final stages) (Blueprint Section 14)
export const assessments = pgTable('assessments', {
  assessmentId: text('assessment_id').primaryKey(),
  paymentId: text('payment_id')
    .references(() => payments.paymentId)
    .notNull(),
  stage: text('stage').notNull(), // INITIAL | FINAL
  transactionAnomalyScore: integer('transaction_anomaly_score').notNull(),
  beneficiaryRiskScore: integer('beneficiary_risk_score').notNull(),
  coercionRiskScore: integer('coercion_risk_score'),
  overallRiskScore: integer('overall_risk_score').notNull(),
  riskLevel: text('risk_level').notNull(),
  recommendedAction: text('recommended_action').notNull(),
  reasonCodes: jsonb('reason_codes').$type<string[]>().notNull(),
  explanations: jsonb('explanations').$type<string[]>().notNull(),
  requiresQuestions: boolean('requires_questions').notNull().default(false),
  scoringLatencyMs: numeric('scoring_latency_ms', { precision: 8, scale: 2 }),
  modelVersion: text('model_version').notNull(),
  policyVersion: text('policy_version').notNull(),
  createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
});

// 5. Canonical adaptive questions and multilingual translations (Blueprint Section 14)
export const questions = pgTable('questions', {
  questionId: text('question_id').primaryKey(),
  translations: jsonb('translations').$type<Record<string, string>>().notNull(),
  audioPrompts: jsonb('audio_prompts').$type<Record<string, string>>().notNull(),
  intent: text('intent').notNull(),
  triggeredReasonCode: text('triggered_reason_code').notNull(),
  answerOptions: jsonb('answer_options').$type<string[]>().notNull(),
});

// 6. Questionnaire answers (no raw audio stored) (Blueprint Section 14)
export const answers = pgTable('answers', {
  answerId: text('answer_id').primaryKey(),
  paymentId: text('payment_id')
    .references(() => payments.paymentId)
    .notNull(),
  questionId: text('question_id')
    .references(() => questions.questionId)
    .notNull(),
  answer: text('answer').notNull(),
  inputMode: text('input_mode').notNull(),
  answeredAt: timestamp('answered_at', { withTimezone: true }).defaultNow().notNull(),
});

// 7. Feedback & Evaluation Service outcomes (Blueprint Section 14)
export const feedback = pgTable('feedback', {
  feedbackId: text('feedback_id').primaryKey(),
  paymentId: text('payment_id')
    .references(() => payments.paymentId)
    .notNull(),
  userUid: text('user_uid').references(() => users.uid),
  outcome: text('outcome').notNull(),
  labelSource: text('label_source').notNull(),
  notes: text('notes'),
  createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
});

// 8. Audit event trail for state transitions (Blueprint Section 14)
export const auditEvents = pgTable('audit_events', {
  eventId: text('event_id').primaryKey(),
  paymentId: text('payment_id')
    .references(() => payments.paymentId)
    .notNull(),
  eventType: text('event_type').notNull(),
  actor: text('actor').notNull(),
  details: jsonb('details').$type<Record<string, unknown>>().notNull(),
  createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
});

// Drizzle Relations
export const usersRelations = relations(users, ({ many }) => ({
  payments: many(payments),
  feedback: many(feedback),
}));

export const paymentsRelations = relations(payments, ({ one, many }) => ({
  user: one(users, { fields: [payments.userUid], references: [users.uid] }),
  customer: one(customers, { fields: [payments.customerId], references: [customers.customerId] }),
  beneficiary: one(beneficiaries, {
    fields: [payments.beneficiaryId],
    references: [beneficiaries.beneficiaryId],
  }),
  assessments: many(assessments),
  answers: many(answers),
  feedback: many(feedback),
  auditEvents: many(auditEvents),
}));

export const assessmentsRelations = relations(assessments, ({ one }) => ({
  payment: one(payments, { fields: [assessments.paymentId], references: [payments.paymentId] }),
}));

export const answersRelations = relations(answers, ({ one }) => ({
  payment: one(payments, { fields: [answers.paymentId], references: [payments.paymentId] }),
  question: one(questions, { fields: [answers.questionId], references: [questions.questionId] }),
}));

export const feedbackRelations = relations(feedback, ({ one }) => ({
  payment: one(payments, { fields: [feedback.paymentId], references: [payments.paymentId] }),
  user: one(users, { fields: [feedback.userUid], references: [users.uid] }),
}));

export const auditEventsRelations = relations(auditEvents, ({ one }) => ({
  payment: one(payments, { fields: [auditEvents.paymentId], references: [payments.paymentId] }),
}));
