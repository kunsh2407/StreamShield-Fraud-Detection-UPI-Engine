import { Request, Response, NextFunction } from 'express';
import crypto from 'node:crypto';
import { adminAuth } from '../lib/firebase-admin.ts';
import { getOrCreateUser } from '../db/users.ts';

export type PortalRole = 'USER' | 'ADMIN';

export interface AuthenticatedPortalUser {
  uid: string;
  email: string;
  name?: string | null;
  role: PortalRole;
  customerId?: string;
  adminId?: string;
  authProvider: 'CREDENTIALS' | 'GOOGLE';
}

export interface AuthRequest extends Request {
  user?: AuthenticatedPortalUser;
}

export interface PortalCredentialUser {
  customerId: string;
  handle: string;
  email: string;
  displayName: string;
  password: string;
}

export interface PortalCredentialAdmin {
  adminId: string;
  email: string;
  displayName: string;
  designation: string;
  password: string;
}

export const DEMO_USER_ACCOUNTS: PortalCredentialUser[] = [
  {
    customerId: 'CUS_0001',
    handle: 'rama.rao@okupi',
    email: 'rama.rao@streamshield.demo',
    displayName: 'Rama Rao (Senior Citizen)',
    password: 'user123',
  },
  {
    customerId: 'CUS_0002',
    handle: 'priya.sharma@okupi',
    email: 'priya.sharma@streamshield.demo',
    displayName: 'Priya Sharma (Everyday User)',
    password: 'user123',
  },
  {
    customerId: 'CUS_0003',
    handle: 'ramesh.kumar@okupi',
    email: 'ramesh.kumar@streamshield.demo',
    displayName: 'Ramesh Kumar (Limited Literacy)',
    password: 'user123',
  },
  {
    customerId: 'CUS_0004',
    handle: 'sunita.devi@okupi',
    email: 'sunita.devi@streamshield.demo',
    displayName: 'Sunita Devi (Family Payer)',
    password: 'user123',
  },
];

export const DEMO_ADMIN_ACCOUNTS: PortalCredentialAdmin[] = [
  {
    adminId: 'BANK_ADMIN_01',
    email: 'ananya.verma@bankops.streamshield.demo',
    displayName: 'Ananya Verma (Bank Fraud Ops)',
    designation: 'Senior Fraud Operations Officer',
    password: 'admin@2026',
  },
  {
    adminId: 'BANK_ADMIN_02',
    email: 'vikram.nair@bankops.streamshield.demo',
    displayName: 'Vikram Nair (Risk & ML Admin)',
    designation: 'Principal Risk & ML Administrator',
    password: 'admin@2026',
  },
];

function getSessionSecret(): string {
  return (
    process.env.SESSION_SECRET ||
    process.env.SQL_PASSWORD ||
    'streamshield-local-hmac-session-secret-v1'
  );
}

interface TokenPayload {
  uid: string;
  email: string;
  name: string;
  role: PortalRole;
  customerId?: string;
  adminId?: string;
  exp: number;
}

export function createPortalToken(user: Omit<TokenPayload, 'exp'>): string {
  const payload: TokenPayload = {
    ...user,
    exp: Math.floor(Date.now() / 1000) + 60 * 60 * 24, // 24 hours
  };
  const encodedPayload = Buffer.from(JSON.stringify(payload), 'utf8').toString('base64url');
  const sig = crypto
    .createHmac('sha256', getSessionSecret())
    .update(encodedPayload)
    .digest('base64url');
  return `SS1.${encodedPayload}.${sig}`;
}

export function verifyPortalToken(token: string): AuthenticatedPortalUser | null {
  if (!token.startsWith('SS1.')) return null;
  const parts = token.split('.');
  if (parts.length !== 3) return null;
  const [, encodedPayload, sig] = parts;
  const expectedSig = crypto
    .createHmac('sha256', getSessionSecret())
    .update(encodedPayload)
    .digest('base64url');

  const sigBuf = Buffer.from(sig);
  const expectedBuf = Buffer.from(expectedSig);
  if (sigBuf.length !== expectedBuf.length || !crypto.timingSafeEqual(sigBuf, expectedBuf)) {
    return null;
  }

  try {
    const parsed = JSON.parse(Buffer.from(encodedPayload, 'base64url').toString('utf8')) as TokenPayload;
    if (!parsed.exp || parsed.exp < Math.floor(Date.now() / 1000)) {
      return null;
    }
    return {
      uid: parsed.uid,
      email: parsed.email,
      name: parsed.name,
      role: parsed.role,
      customerId: parsed.customerId,
      adminId: parsed.adminId,
      authProvider: 'CREDENTIALS',
    };
  } catch {
    return null;
  }
}

export async function syncAuthenticatedUser(user: AuthenticatedPortalUser) {
  if (!process.env.SQL_HOST) return;
  try {
    await getOrCreateUser(user.uid, user.email, user.name ?? null);
  } catch (error) {
    console.error('Error syncing authenticated user to PostgreSQL:', error);
    throw error;
  }
}

export const requireAuth = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction
) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({
      error: {
        code: 'UNAUTHORIZED',
        message: 'Unauthorized: Missing Bearer token',
        details: {},
      },
    });
  }

  const token = authHeader.split('Bearer ')[1];

  // 1. Check signed StreamShield Portal credential token (User or Bank Admin)
  const portalUser = verifyPortalToken(token);
  if (portalUser) {
    req.user = portalUser;
    try {
      await syncAuthenticatedUser(portalUser);
    } catch {
      return res.status(500).json({
        error: {
          code: 'USER_SYNC_FAILED',
          message: 'Failed to synchronize authenticated user.',
          details: {},
        },
      });
    }
    return next();
  }

  // 2. Fallback to Firebase Google ID Token (always scoped to USER role)
  try {
    const decodedToken = await adminAuth.verifyIdToken(token);
    const firebaseUser: AuthenticatedPortalUser = {
      uid: decodedToken.uid,
      email: decodedToken.email || `${decodedToken.uid}@users.streamshield.local`,
      name: decodedToken.name || decodedToken.email || 'UPI User',
      role: 'USER',
      customerId: 'CUS_0002',
      authProvider: 'GOOGLE',
    };
    req.user = firebaseUser;
    await syncAuthenticatedUser(firebaseUser);
    return next();
  } catch (error) {
    console.error('Error verifying authentication token:', error);
    return res.status(401).json({
      error: {
        code: 'UNAUTHORIZED',
        message: 'Unauthorized: Invalid or expired token',
        details: {},
      },
    });
  }
};

export const requireAdmin = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction
) => {
  await requireAuth(req, res, () => {
    if (!req.user || req.user.role !== 'ADMIN') {
      return res.status(403).json({
        error: {
          code: 'FORBIDDEN_ADMIN_ONLY',
          message: 'Access denied: Bank Administrator credentials required.',
          details: {},
        },
      });
    }
    next();
  });
};
