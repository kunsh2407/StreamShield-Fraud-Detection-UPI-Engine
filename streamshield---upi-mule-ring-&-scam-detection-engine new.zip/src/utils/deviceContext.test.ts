import test from 'node:test';
import assert from 'node:assert/strict';
import { detectDeviceContext } from './deviceContext';

test('detects mobile phone environment from user-agent or narrow viewport', () => {
  const android = detectDeviceContext(
    'Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 Chrome/128.0 Mobile Safari/537.36',
    390
  );
  assert.equal(android.deviceType, 'PHONE');
  assert.equal(android.channel, 'PHONE_APP');
  assert.equal(android.osLabel, 'Android');

  const narrowWeb = detectDeviceContext('Mozilla/5.0 (X11; Linux x86_64) Chrome/128.0', 390);
  assert.equal(narrowWeb.deviceType, 'PHONE');
  assert.equal(narrowWeb.channel, 'PHONE_APP');
});

test('detects laptop/desktop environment on desktop user-agent and wide viewport', () => {
  const desktop = detectDeviceContext(
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/128.0.0.0 Safari/537.36',
    1440
  );
  assert.equal(desktop.deviceType, 'LAPTOP');
  assert.equal(desktop.channel, 'LAPTOP_WEB');
  assert.equal(desktop.osLabel, 'Linux');
  assert.equal(desktop.browserLabel, 'Chrome');
});
