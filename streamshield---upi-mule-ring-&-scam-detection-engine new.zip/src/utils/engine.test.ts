import test from 'node:test';
import assert from 'node:assert/strict';
import { StreamShieldCore } from './engine';
import { UPITransaction } from '../types';

test('genuine baseline transaction scores LOW / ALLOW with non-negative latency', () => {
  const engine = new StreamShieldCore();
  const tx: UPITransaction = {
    tx_id: 'TX_GEN_01',
    timestamp: 1_700_000_000_000,
    sender: 'rahul.sharma@okaxis',
    receiver: 'swiggy.merchant@axisbank',
    amount: 420,
    device_id: 'DEV-GEN-0',
    is_new_account: false,
    tx_type: 'P2M',
    label: 0,
    round: 1,
  };

  const scored = engine.scoreTransaction(tx);
  assert.equal(scored.decision, 'ALLOW');
  assert.ok(scored.risk_score < engine.thresholdStepUp);
  assert.ok(scored.latency_ms >= 0);
});

test('velocity burst + shared device + pass-through mule pattern escalates to STEP_UP or HOLD', () => {
  const engine = new StreamShieldCore();
  const muleVpa = 'mule.ring.alpha99@ybl';
  const baseTs = 1_700_000_000_000;

  // Establish fan-in and pass-through activity on mule receiver and shared device
  for (let i = 0; i < 4; i++) {
    engine.scoreTransaction({
      tx_id: `TX_WARM_${i}`,
      timestamp: baseTs + i * 5000,
      sender: `victim_${i}@okaxis`,
      receiver: muleVpa,
      amount: 35000,
      device_id: 'DEV-MULE-X99',
      is_new_account: true,
      tx_type: 'MULE_FAN_IN',
      label: 1,
      round: 1,
    });
  }

  // Outgoing hop from mule to give pass-through ratio > 0
  engine.scoreTransaction({
    tx_id: 'TX_MULE_OUT',
    timestamp: baseTs + 22000,
    sender: muleVpa,
    receiver: 'cashout.node@ybl',
    amount: 120000,
    device_id: 'DEV-MULE-X99',
    is_new_account: true,
    tx_type: 'MULE_FAN_IN',
    label: 1,
    round: 1,
  });

  const finalTx = engine.scoreTransaction({
    tx_id: 'TX_VICTIM_HIT',
    timestamp: baseTs + 25000,
    sender: 'victim_0@okaxis',
    receiver: muleVpa,
    amount: 45000,
    device_id: 'DEV-MULE-X99',
    is_new_account: true,
    tx_type: 'MULE_FAN_IN',
    label: 1,
    round: 1,
  });

  assert.notEqual(finalTx.decision, 'ALLOW');
  assert.ok(finalTx.risk_score >= engine.thresholdStepUp);
});

test('getStats reports authentic precision and recall without fake floor clamping', () => {
  const engine = new StreamShieldCore();
  // Score only genuine transactions that all ALLOW -> zero positives predicted or actual
  engine.scoreTransaction({
    tx_id: 'TX_1',
    timestamp: 1_700_000_000_000,
    sender: 'a@okaxis',
    receiver: 'b@okaxis',
    amount: 250,
    device_id: 'DEV-1',
    is_new_account: false,
    tx_type: 'P2P',
    label: 0,
    round: 1,
  });

  const stats = engine.getStats();
  assert.equal(stats.totalScored, 1);
  assert.equal(stats.precision, 0);
  assert.equal(stats.recall, 0);
  assert.equal(stats.decisionCounts.ALLOW, 1);
});

test('freezeAccount cascades downstream and immediately holds future transfers', () => {
  const engine = new StreamShieldCore();
  const baseTs = 1_700_000_100_000;

  engine.scoreTransaction({
    tx_id: 'TX_HOP_1',
    timestamp: baseTs,
    sender: 'mule_a@ybl',
    receiver: 'mule_b@ybl',
    amount: 15000,
    device_id: 'DEV-RING',
    is_new_account: true,
    tx_type: 'MULE_FAN_IN',
    label: 1,
    round: 1,
  });
  engine.scoreTransaction({
    tx_id: 'TX_HOP_2',
    timestamp: baseTs + 1000,
    sender: 'mule_b@ybl',
    receiver: 'mule_c@ybl',
    amount: 14500,
    device_id: 'DEV-RING',
    is_new_account: true,
    tx_type: 'MULE_FAN_IN',
    label: 1,
    round: 1,
  });

  const frozenList = engine.freezeAccount('mule_a@ybl');
  assert.ok(frozenList.includes('mule_a@ybl'));
  assert.ok(frozenList.includes('mule_b@ybl'));
  assert.ok(frozenList.includes('mule_c@ybl'));

  const blocked = engine.scoreTransaction({
    tx_id: 'TX_POST_FREEZE',
    timestamp: baseTs + 2000,
    sender: 'innocent@okicici',
    receiver: 'mule_c@ybl',
    amount: 9000,
    device_id: 'DEV-CLEAN',
    is_new_account: false,
    tx_type: 'P2P',
    label: 1,
    round: 1,
  });

  assert.equal(blocked.decision, 'HOLD');
  assert.equal(blocked.frozen, true);
});
