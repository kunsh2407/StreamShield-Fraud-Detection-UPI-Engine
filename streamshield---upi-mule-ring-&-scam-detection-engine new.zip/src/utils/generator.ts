import { UPITransaction } from '../types';

const GENUINE_USERS = [
  'rahul.sharma@okaxis',
  'priya.nair@okicici',
  'amit.patel@ybl',
  'sneha.iyer@oksbi',
  'vikram.singh@paytm',
  'ananya.gupta@okhdfcbank',
  'rohan.verma@ybl',
  'kavita.reddy@okaxis',
  'arjun.menon@oksbi',
  'deepika.das@paytm',
];

const GENUINE_MERCHANTS = [
  'swiggy.merchant@axisbank',
  'zomato.pay@hdfcbank',
  'dmart.retail@icici',
  'irctc.upi@sbi',
  'bigbasket.india@ybl',
  'apollo.pharmacy@okicici',
  'uber.india@okaxis',
  'jio.recharge@paytm',
];

const MULE_ACCOUNTS_R1 = [
  'mule.ring.alpha99@ybl',
  'mule.drop.node04@okaxis',
  'fraud.aggregator01@paytm',
];

const MULE_DEVICES_R1 = ['DEV-MULE-X99', 'DEV-EMULATOR-007'];

const SMURF_RING_R2 = [
  'smurf.node1.r2@okicici',
  'smurf.node2.r2@okaxis',
  'smurf.node3.r2@ybl',
  'smurf.collector.r2@paytm',
];

export class UPISyntheticGenerator {
  private txCounter = 0;
  private r2Phase = 0;

  public generateTransaction(round: 1 | 2): UPITransaction {
    this.txCounter += 1;
    const timestamp = Date.now();
    const txId = `UPI${String(timestamp).slice(-7)}${String(this.txCounter).padStart(4, '0')}`;

    if (round === 2 && this.txCounter % 5 === 0) {
      this.r2Phase = (this.r2Phase + 1) % 3;
      const victim = GENUINE_USERS[this.txCounter % GENUINE_USERS.length];
      const mule = SMURF_RING_R2[this.r2Phase];
      const nextMule = SMURF_RING_R2[(this.r2Phase + 1) % SMURF_RING_R2.length];
      return {
        tx_id: txId,
        timestamp,
        sender: this.r2Phase === 0 ? victim : mule,
        receiver: this.r2Phase === 0 ? mule : nextMule,
        amount: 4200 + (this.txCounter % 7) * 650,
        device_id: 'DEV-R2-SHARED-POOL',
        is_new_account: true,
        tx_type: 'MULE_CIRCULAR_SMURF',
        label: 1,
        round: 2,
        note: 'Synthetic Round 2 smurfing pulse',
      };
    }

    if (round === 1 && this.txCounter % 6 === 0) {
      const victim = GENUINE_USERS[this.txCounter % GENUINE_USERS.length];
      const mule = MULE_ACCOUNTS_R1[this.txCounter % MULE_ACCOUNTS_R1.length];
      return {
        tx_id: txId,
        timestamp,
        sender: victim,
        receiver: mule,
        amount: 28000 + (this.txCounter % 5) * 4500,
        device_id: MULE_DEVICES_R1[this.txCounter % MULE_DEVICES_R1.length],
        is_new_account: true,
        tx_type: 'MULE_FAN_IN',
        label: 1,
        round: 1,
        note: 'Synthetic Round 1 mule fan-in',
      };
    }

    const sender = GENUINE_USERS[this.txCounter % GENUINE_USERS.length];
    const receiver =
      this.txCounter % 2 === 0
        ? GENUINE_MERCHANTS[this.txCounter % GENUINE_MERCHANTS.length]
        : GENUINE_USERS[(this.txCounter + 3) % GENUINE_USERS.length];

    return {
      tx_id: txId,
      timestamp,
      sender,
      receiver,
      amount: 180 + (this.txCounter % 15) * 240,
      device_id: `DEV-GEN-${this.txCounter % GENUINE_USERS.length}`,
      is_new_account: false,
      tx_type: this.txCounter % 2 === 0 ? 'P2M' : 'P2P',
      label: 0,
      round,
    };
  }
}
