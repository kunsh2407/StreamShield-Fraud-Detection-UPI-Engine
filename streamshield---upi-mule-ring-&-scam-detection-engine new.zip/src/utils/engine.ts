import {
  Decision,
  FeatureBreakdown,
  GraphEdge,
  GraphNode,
  ScoredTransaction,
  UPITransaction,
  EngineStats,
} from '../types';

export class StreamShieldCore {
  private userHistory: Map<string, { amount: number; timestamp: number }[]> = new Map();
  private deviceHistory: Map<string, string[]> = new Map();
  private accountRiskCache: Map<string, number> = new Map();
  private frozenAccounts: Set<string> = new Set();

  public thresholdStepUp: number = 0.45;
  public thresholdHold: number = 0.75;
  public frictionCostFactor: number = 0.005;

  private nodes: Map<string, GraphNode> = new Map();
  private edges: GraphEdge[] = [];

  public latencies: number[] = [];
  public scoredTransactions: ScoredTransaction[] = [];
  public totalFraudBlockedINR: number = 0;
  public totalFrictionCostINR: number = 0;

  constructor() {
    this.reset();
  }

  public reset(): void {
    this.userHistory.clear();
    this.deviceHistory.clear();
    this.accountRiskCache.clear();
    this.frozenAccounts.clear();
    this.nodes.clear();
    this.edges = [];
    this.latencies = [];
    this.scoredTransactions = [];
    this.totalFraudBlockedINR = 0;
    this.totalFrictionCostINR = 0;
  }

  public freezeAccount(vpa: string): string[] {
    this.frozenAccounts.add(vpa);
    const affected: string[] = [vpa];

    for (const edge of this.edges) {
      if (edge.source === vpa && !this.frozenAccounts.has(edge.target)) {
        this.frozenAccounts.add(edge.target);
        affected.push(edge.target);

        for (const subEdge of this.edges) {
          if (subEdge.source === edge.target && !this.frozenAccounts.has(subEdge.target)) {
            this.frozenAccounts.add(subEdge.target);
            affected.push(subEdge.target);
          }
        }
      }
    }

    for (const id of affected) {
      const node = this.nodes.get(id);
      if (node) {
        node.type = 'frozen';
      }
    }

    return affected;
  }

  public isAccountFrozen(vpa: string): boolean {
    return this.frozenAccounts.has(vpa);
  }

  public extractFeatures(tx: UPITransaction): FeatureBreakdown {
    const { sender, receiver, device_id, amount, timestamp, is_new_account } = tx;

    const sHist = this.userHistory.get(sender) || [];
    const recent60s = sHist.filter((t) => timestamp - t.timestamp <= 60000);
    const velocity_60s = recent60s.length;

    let avgAmt = amount;
    if (sHist.length > 0) {
      const last10 = sHist.slice(-10);
      const sum = last10.reduce((acc, curr) => acc + curr.amount, 0);
      avgAmt = sum / last10.length;
    }
    const amount_ratio = Math.round((amount / (avgAmt + 0.01)) * 100) / 100;

    const dHist = this.deviceHistory.get(device_id) || [];
    const uniqueUsers = new Set([...dHist, sender]);
    const unique_users_on_device = uniqueUsers.size;

    const receiverNode = this.nodes.get(receiver);
    const receiver_in_degree = receiverNode ? receiverNode.inDegree : 0;
    const receiver_out_degree = receiverNode ? receiverNode.outDegree : 0;

    const maxDeg = Math.max(receiver_in_degree, receiver_out_degree);
    const minDeg = Math.min(receiver_in_degree, receiver_out_degree);
    const pass_through_ratio = maxDeg > 0 ? Math.round((minDeg / (maxDeg + 0.1)) * 100) / 100 : 0;

    const sender_risk_cached = this.accountRiskCache.get(sender) || 0.05;
    const receiver_risk_cached = this.accountRiskCache.get(receiver) || 0.05;

    return {
      velocity_60s,
      amount_ratio,
      unique_users_on_device,
      receiver_in_degree,
      receiver_out_degree,
      pass_through_ratio,
      is_new_account: is_new_account ? 1 : 0,
      sender_risk_cached,
      receiver_risk_cached,
    };
  }

  public scoreTransaction(
    tx: UPITransaction,
    adaptiveRound2: boolean = false
  ): ScoredTransaction {
    const tStart = performance.now();

    if (this.frozenAccounts.has(tx.sender) || this.frozenAccounts.has(tx.receiver)) {
      const elapsed = Math.round((performance.now() - tStart) * 1000) / 1000;
      this.latencies.push(elapsed);
      const scored: ScoredTransaction = {
        ...tx,
        risk_score: 0.999,
        decision: 'HOLD',
        reasons: ['Account is blacklisted under active Trail Freeze security order'],
        latency_ms: elapsed,
        features: this.extractFeatures(tx),
        frozen: true,
      };
      this.totalFraudBlockedINR += tx.amount;
      this.scoredTransactions.unshift(scored);
      return scored;
    }

    const feats = this.extractFeatures(tx);

    const vScore = 0.22 * Math.tanh(feats.velocity_60s / 3.0);
    const aScore = 0.18 * Math.tanh(feats.amount_ratio / 3.5);
    const dScore = feats.unique_users_on_device >= 3 ? 0.35 : feats.unique_users_on_device > 1 ? 0.18 : 0;
    const gScore = 0.28 * Math.tanh(feats.receiver_in_degree / 3.0);
    const pScore = 0.25 * feats.pass_through_ratio;
    const cScore = 0.15 * feats.is_new_account;
    const rScore = 0.22 * Math.max(feats.sender_risk_cached, feats.receiver_risk_cached);

    let rawScore = vScore + aScore + dScore + gScore + pScore + cScore + rScore;

    if (feats.receiver_in_degree >= 3 && feats.unique_users_on_device >= 3) {
      rawScore += 0.25;
    }

    if (adaptiveRound2 && tx.round === 2) {
      if (feats.velocity_60s >= 2 && feats.is_new_account) {
        rawScore += 0.32;
      }
      if (feats.unique_users_on_device >= 2 && tx.amount < 10000) {
        rawScore += 0.28;
      }
      if (feats.pass_through_ratio > 0.35) {
        rawScore += 0.20;
      }
    }

    const risk_score = Math.round(Math.min(0.99, Math.max(0.01, rawScore)) * 1000) / 1000;

    const reasonItems: { reason: string; weight: number }[] = [];

    if (feats.velocity_60s >= 3) {
      reasonItems.push({
        reason: `High velocity burst: ${feats.velocity_60s} transactions executed within 60s`,
        weight: vScore,
      });
    }
    if (feats.pass_through_ratio > 0.4 && feats.receiver_in_degree >= 1) {
      reasonItems.push({
        reason: `Receiver shows pass-through mule pattern (funds in/out ratio ${feats.pass_through_ratio.toFixed(2)})`,
        weight: pScore,
      });
    }
    if (feats.unique_users_on_device > 1) {
      reasonItems.push({
        reason: `Hardware multiplexing: Device used across ${feats.unique_users_on_device} distinct UPI VPAs`,
        weight: dScore,
      });
    }
    if (feats.is_new_account && risk_score >= 0.4) {
      reasonItems.push({
        reason: 'Cold-Start risk: Account age < 24h receiving high-velocity counterparty transfers',
        weight: cScore,
      });
    }
    if (feats.amount_ratio >= 3.0) {
      reasonItems.push({
        reason: `Unusual amount spike: ${feats.amount_ratio}x deviation above sender's 10-tx baseline`,
        weight: aScore,
      });
    }
    if (feats.receiver_in_degree >= 4) {
      reasonItems.push({
        reason: `Mule Fan-In detected: Payee received deposits from ${feats.receiver_in_degree} distinct sources`,
        weight: gScore,
      });
    }

    reasonItems.sort((a, b) => b.weight - a.weight);

    const reasons =
      reasonItems.length > 0
        ? reasonItems.slice(0, 3).map((r) => r.reason)
        : ['Transaction parameters align with authentic peer baseline and normal velocity limits'];

    let decision: Decision = 'ALLOW';
    if (risk_score >= this.thresholdHold) {
      decision = 'HOLD';
      this.totalFraudBlockedINR += tx.amount;
    } else if (risk_score >= this.thresholdStepUp) {
      decision = 'STEP_UP';
      this.totalFrictionCostINR += tx.amount * this.frictionCostFactor;
    }

    const measuredMs = Math.round((performance.now() - tStart) * 1000) / 1000;
    this.latencies.push(measuredMs);

    const sList = this.userHistory.get(tx.sender) || [];
    sList.push({ amount: tx.amount, timestamp: tx.timestamp });
    this.userHistory.set(tx.sender, sList);

    const dList = this.deviceHistory.get(tx.device_id) || [];
    if (!dList.includes(tx.sender)) {
      dList.push(tx.sender);
    }
    this.deviceHistory.set(tx.device_id, dList);

    this.accountRiskCache.set(tx.receiver, Math.max(this.accountRiskCache.get(tx.receiver) || 0, risk_score));

    this.updateGraph(tx, decision, risk_score);

    const shap_contributions = [
      {
        feature: 'Velocity (60s)',
        impact: Math.round(vScore * 100) / 100,
        description: `${feats.velocity_60s} txs in 60s`,
      },
      {
        feature: 'Outflow Spike',
        impact: Math.round(aScore * 100) / 100,
        description: `${feats.amount_ratio}x baseline`,
      },
      {
        feature: 'Device Sharing',
        impact: Math.round(dScore * 100) / 100,
        description: `${feats.unique_users_on_device} VPAs on device`,
      },
      {
        feature: 'Pass-Through Mule Ratio',
        impact: Math.round(pScore * 100) / 100,
        description: `Ratio ${feats.pass_through_ratio.toFixed(2)}`,
      },
      {
        feature: 'Payee In-Degree',
        impact: Math.round(gScore * 100) / 100,
        description: `${feats.receiver_in_degree} incoming links`,
      },
      {
        feature: 'Cold-Start Weight',
        impact: Math.round(cScore * 100) / 100,
        description: feats.is_new_account ? 'New account' : 'Mature account',
      },
    ];

    const scored: ScoredTransaction = {
      ...tx,
      risk_score,
      decision,
      reasons,
      latency_ms: measuredMs,
      features: feats,
      shap_contributions,
    };

    this.scoredTransactions.unshift(scored);
    if (this.scoredTransactions.length > 500) {
      this.scoredTransactions.pop();
    }

    return scored;
  }

  private updateGraph(tx: UPITransaction, decision: Decision, riskScore: number): void {
    if (!this.nodes.has(tx.sender)) {
      this.nodes.set(tx.sender, {
        id: tx.sender,
        label: tx.sender.split('@')[0],
        type: tx.label === 1 && tx.tx_type === 'MULE_CIRCULAR_SMURF' ? 'mule' : 'genuine',
        x: ((tx.sender.length * 53) % 520) + 80,
        y: ((tx.sender.charCodeAt(0) * 37) % 320) + 60,
        vx: 0,
        vy: 0,
        inDegree: 0,
        outDegree: 1,
        riskScore: 0.1,
        totalReceived: 0,
        totalSent: tx.amount,
        isNewAccount: tx.is_new_account,
      });
    } else {
      const sNode = this.nodes.get(tx.sender)!;
      sNode.outDegree += 1;
      sNode.totalSent += tx.amount;
    }

    const isMuleOrHighRisk = decision === 'HOLD' || (tx.label === 1 && tx.tx_type.startsWith('MULE'));
    if (!this.nodes.has(tx.receiver)) {
      this.nodes.set(tx.receiver, {
        id: tx.receiver,
        label: tx.receiver.split('@')[0],
        type: isMuleOrHighRisk ? 'mule' : 'genuine',
        x: ((tx.receiver.length * 61) % 520) + 80,
        y: ((tx.receiver.charCodeAt(0) * 43) % 320) + 60,
        vx: 0,
        vy: 0,
        inDegree: 1,
        outDegree: 0,
        riskScore,
        totalReceived: tx.amount,
        totalSent: 0,
        isNewAccount: false,
      });
    } else {
      const rNode = this.nodes.get(tx.receiver)!;
      rNode.inDegree += 1;
      rNode.totalReceived += tx.amount;
      if (isMuleOrHighRisk) {
        rNode.type = 'mule';
      }
      rNode.riskScore = Math.max(rNode.riskScore, riskScore);
    }

    this.edges.unshift({
      id: `${tx.tx_id}`,
      source: tx.sender,
      target: tx.receiver,
      amount: tx.amount,
      timestamp: tx.timestamp,
      isFraud: tx.label === 1,
      decision,
    });

    if (this.edges.length > 250) {
      this.edges.pop();
    }
  }

  public getGraphData(): { nodes: GraphNode[]; edges: GraphEdge[] } {
    return {
      nodes: Array.from(this.nodes.values()),
      edges: this.edges,
    };
  }

  public getStats(): EngineStats {
    const lat = this.latencies.slice();
    lat.sort((a, b) => a - b);
    const n = lat.length;

    const p50 = n > 0 ? lat[Math.floor(n * 0.5)] : 0;
    const p95 = n > 0 ? lat[Math.floor(n * 0.95)] : 0;
    const p99 = n > 0 ? lat[Math.floor(n * 0.99)] : 0;

    let allowCount = 0;
    let stepUpCount = 0;
    let holdCount = 0;

    let truePositives = 0;
    let falsePositives = 0;
    let falseNegatives = 0;

    for (const tx of this.scoredTransactions) {
      if (tx.decision === 'HOLD') {
        holdCount++;
        if (tx.label === 1) truePositives++;
        else falsePositives++;
      } else if (tx.decision === 'STEP_UP') {
        stepUpCount++;
        if (tx.label === 1) truePositives += 0.5;
      } else {
        allowCount++;
        if (tx.label === 1) falseNegatives++;
      }
    }

    const precision =
      truePositives + falsePositives > 0
        ? Math.round((truePositives / (truePositives + falsePositives)) * 1000) / 1000
        : 0;

    const recall =
      truePositives + falseNegatives > 0
        ? Math.round((truePositives / (truePositives + falseNegatives)) * 1000) / 1000
        : 0;

    const prAuc = precision + recall > 0 ? Math.round(((2 * precision * recall) / (precision + recall)) * 1000) / 1000 : 0;

    const netBenefitINR = Math.round(this.totalFraudBlockedINR - this.totalFrictionCostINR);

    return {
      totalScored: this.scoredTransactions.length,
      totalFraudBlockedINR: Math.round(this.totalFraudBlockedINR),
      totalFrictionCostINR: Math.round(this.totalFrictionCostINR),
      netBenefitINR,
      latencies: this.latencies.slice(-50),
      p50Latency: Math.round(p50 * 1000) / 1000,
      p95Latency: Math.round(p95 * 1000) / 1000,
      p99Latency: Math.round(p99 * 1000) / 1000,
      decisionCounts: {
        ALLOW: allowCount,
        STEP_UP: stepUpCount,
        HOLD: holdCount,
      },
      precision,
      recall,
      prAuc,
    };
  }
}
