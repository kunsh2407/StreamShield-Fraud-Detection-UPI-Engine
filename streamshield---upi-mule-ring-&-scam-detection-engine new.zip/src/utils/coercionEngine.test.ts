import test from 'node:test';
import assert from 'node:assert/strict';
import {
  TransactionBehaviourEngine,
  BeneficiaryRiskEngine,
  CoercionContextEngine,
  AdaptiveQuestionSelector,
  RiskFusionDecisionEngine,
} from './coercionEngine';
import { CANONICAL_CUSTOMERS, CANONICAL_BENEFICIARIES } from '../data/canonicalData';
import { AnswerSubmission } from '../types';

test('TBE: accurately scores baseline amount deviations and new beneficiaries', () => {
  const ramaRao = CANONICAL_CUSTOMERS[0]; // median 1500
  const result = TransactionBehaviourEngine.score(75000, ramaRao, true, 10);
  assert.ok(result.score >= 50, `Expected high anomaly for 75k vs 1.5k median, got ${result.score}`);
  assert.ok(result.reasons.includes('AMOUNT_ABOVE_BASELINE'));
  assert.ok(result.reasons.includes('NEW_BENEFICIARY'));
});

test('BRE: identifies rapid flow-through and counterparty diversity in synthetic mules', () => {
  const mule = CANONICAL_BENEFICIARIES[2]; // flow through 0.97, 19 counterparties
  const result = BeneficiaryRiskEngine.score(mule);
  assert.ok(result.score >= 70, `Expected high beneficiary risk for mule, got ${result.score}`);
  assert.ok(result.reasons.includes('BENEFICIARY_RAPID_OUTFLOW'));
  assert.ok(result.reasons.includes('BENEFICIARY_HIGH_INFLOW_DIVERSITY'));
});

test('CCE & AQS: evaluates digital-arrest coercion answers and branches cleanly', () => {
  const answers: AnswerSubmission[] = [
    {
      question_id: 'Q_URGENCY',
      answer: 'YES',
      input_mode: 'TAP',
      answered_at: new Date().toISOString(),
    },
    {
      question_id: 'Q_THREAT',
      answer: 'YES',
      input_mode: 'VOICE',
      answered_at: new Date().toISOString(),
    },
  ];

  const cceRes = CoercionContextEngine.score(answers);
  assert.ok(cceRes.score !== null && cceRes.score >= 70, `Expected high coercion score, got ${cceRes.score}`);
  assert.ok(cceRes.reasons.includes('AUTHORITY_THREAT_REPORTED'));
  assert.ok(cceRes.reasons.includes('URGENCY_REPORTED'));

  // Test Adaptive Question Selector
  const nextQ = AdaptiveQuestionSelector.selectNextQuestion(60, 40, answers, 3);
  assert.ok(nextQ !== null);
  assert.equal(nextQ.question_id, 'Q_SECRECY');
});

test('CCE: handles SKIP without treating user as fraudster', () => {
  const answers: AnswerSubmission[] = [
    {
      question_id: 'Q_URGENCY',
      answer: 'SKIP',
      input_mode: 'TAP',
      answered_at: new Date().toISOString(),
    },
  ];

  const cceRes = CoercionContextEngine.score(answers);
  assert.equal(cceRes.score, 0); // No fraud penalization for skipping
  assert.equal(cceRes.reasons.length, 0);
});

test('RFDE: fuses all three dimensions into SAFETY_PAUSE for digital-arrest scenario', () => {
  const tbe = { score: 65, reasons: ['AMOUNT_ABOVE_BASELINE' as const, 'NEW_BENEFICIARY' as const] };
  const bre = { score: 75, reasons: ['BENEFICIARY_RAPID_OUTFLOW' as const] };
  const cce = { score: 85, reasons: ['AUTHORITY_THREAT_REPORTED' as const, 'URGENCY_REPORTED' as const] };

  const finalAssessment = RiskFusionDecisionEngine.fuse(tbe, bre, cce, 'te');
  assert.equal(finalAssessment.risk_level, 'HIGH');
  assert.equal(finalAssessment.recommended_action, 'SAFETY_PAUSE');
  assert.ok(finalAssessment.overall_risk_score >= 80);
  assert.ok(finalAssessment.explanations.length >= 1);
  // Telugu explanation check
  assert.ok(finalAssessment.explanations.some((exp) => exp.includes('పోలీస్') || exp.includes('బెదిరింపులు')));
});
