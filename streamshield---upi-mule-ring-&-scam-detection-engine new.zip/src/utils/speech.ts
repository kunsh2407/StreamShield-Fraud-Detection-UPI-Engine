import { Language } from '../types';

export class WebSpeechController {
  private static synth = typeof window !== 'undefined' ? window.speechSynthesis : null;

  public static speak(text: string, lang: Language, rate: number = 0.85): void {
    if (!this.synth) return;
    try {
      this.synth.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      const langMap: Record<Language, string> = {
        en: 'en-IN',
        te: 'te-IN',
        hi: 'hi-IN',
      };
      utterance.lang = langMap[lang] || 'en-IN';
      utterance.rate = rate;
      utterance.pitch = 1.0;

      const voices = this.synth.getVoices();
      const targetVoice = voices.find((v) => v.lang.startsWith(lang)) || voices.find((v) => v.lang.includes('IN'));
      if (targetVoice) {
        utterance.voice = targetVoice;
      }

      this.synth.speak(utterance);
    } catch {
      // Safe silent fallback when browser speech engine is unavailable
    }
  }

  public static stop(): void {
    if (this.synth) {
      try {
        this.synth.cancel();
      } catch {
        // ignore
      }
    }
  }
}
