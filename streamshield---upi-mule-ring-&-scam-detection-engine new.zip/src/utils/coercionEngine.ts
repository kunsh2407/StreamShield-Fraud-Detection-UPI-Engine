import {
  CustomerProfile,
  BeneficiaryProfile,
  CanonicalQuestion,
  AnswerSubmission,
  ComponentScores,
  RiskAssessment,
  RiskLevel,
  RecommendedAction,
  CanonicalReasonCode,
  Language,
  QuestionId,
} from '../types';
import { CANONICAL_QUESTIONS } from '../data/canonicalData';

export class TransactionBehaviourEngine {
  public static score(
    amount: number,
    customer: CustomerProfile,
    isNewBeneficiary: boolean,
    hour: number = new Date().getHours()
  ): { score: number; reasons: CanonicalReasonCode[] } {
    const reasons: CanonicalReasonCode[] = [];
    let anomalyScore = 0;

    // 1. Amount deviation from customer's median and MAD
    const median = customer.baseline_amount_median;
    const mad = Math.max(100, customer.baseline_amount_mad);
    const deviationRatio = amount / median;

    if (deviationRatio > 3.0) {
      anomalyScore += Math.min(50, Math.round((deviationRatio - 1) * 8));
      reasons.push('AMOUNT_ABOVE_BASELINE');
    } else if (deviationRatio > 1.8) {
      anomalyScore += 20;
      reasons.push('AMOUNT_ABOVE_BASELINE');
    } else {
      anomalyScore += Math.min(15, Math.round(deviationRatio * 4));
    }

    // 2. New Beneficiary
    if (isNewBeneficiary) {
      anomalyScore += 25;
      reasons.push('NEW_BENEFICIARY');
    }

    // 3. Unusual time of day
    if (!customer.usual_active_hours.includes(hour)) {
      anomalyScore += 15;
      reasons.push('UNUSUAL_PAYMENT_TIME');
    }

    const boundedScore = Math.min(100, Math.max(5, anomalyScore));
    return { score: boundedScore, reasons };
  }
}

export class BeneficiaryRiskEngine {
  public static score(
    beneficiary: BeneficiaryProfile
  ): { score: number; reasons: CanonicalReasonCode[] } {
    const reasons: CanonicalReasonCode[] = [];
    let risk = 0;

    // 1. Flow-through ratio (proportion of funds moving out quickly)
    if (beneficiary.flow_through_ratio >= 0.90) {
      risk += 35;
      reasons.push('BENEFICIARY_RAPID_OUTFLOW');
    } else if (beneficiary.flow_through_ratio >= 0.70) {
      risk += 18;
    }

    // 2. High inflow counterparty diversity in 24h
    if (beneficiary.customer_counterparties_30d >= 15 && (beneficiary.account_age_days ?? 0) < 30) {
      risk += 30;
      reasons.push('BENEFICIARY_HIGH_INFLOW_DIVERSITY');
    }

    // 3. Graph degree / network connections
    if (beneficiary.network_degree >= 8) {
      risk += 20;
      reasons.push('BENEFICIARY_NETWORK_LINKS');
    }

    // 4. Synthetic report count
    if (beneficiary.synthetic_report_count > 0) {
      risk += Math.min(30, beneficiary.synthetic_report_count * 8);
    }

    const bounded = Math.min(100, Math.max(5, risk));
    return { score: bounded, reasons };
  }
}

export class CoercionContextEngine {
  public static score(
    answers: AnswerSubmission[]
  ): { score: number | null; reasons: CanonicalReasonCode[] } {
    if (answers.length === 0) {
      return { score: null, reasons: [] };
    }

    let coercionScore = 0;
    const reasons: CanonicalReasonCode[] = [];

    for (const sub of answers) {
      if (sub.answer === 'YES') {
        switch (sub.question_id) {
          case 'Q_THREAT':
            coercionScore += 45;
            reasons.push('AUTHORITY_THREAT_REPORTED');
            break;
          case 'Q_URGENCY':
            coercionScore += 28;
            reasons.push('URGENCY_REPORTED');
            break;
          case 'Q_SECRECY':
            coercionScore += 30;
            reasons.push('SECRECY_REQUEST_REPORTED');
            break;
          case 'Q_GUIDANCE':
            coercionScore += 26;
            reasons.push('REMOTE_GUIDANCE_REPORTED');
            break;
          case 'Q_IDENTITY':
            coercionScore += 32;
            reasons.push('IMPERSONATION_REPORTED');
            break;
          case 'Q_PURPOSE':
            // Answering YES to "Do you personally know why" is reassuring
            coercionScore = Math.max(0, coercionScore - 15);
            break;
        }
      } else if (sub.answer === 'NO') {
        if (sub.question_id === 'Q_PURPOSE') {
          coercionScore += 20;
          reasons.push('INSUFFICIENT_CONTEXT');
        }
      } else if (sub.answer === 'NOT_SURE') {
        if (sub.question_id === 'Q_PURPOSE') {
          coercionScore += 15;
          reasons.push('INSUFFICIENT_CONTEXT');
        }
      }
      // SKIP and NEED_HELP are preserved with explicit uncertainty, never scored as positive fraud
    }

    const bounded = Math.min(100, Math.max(0, coercionScore));
    return { score: bounded, reasons };
  }
}

export class AdaptiveQuestionSelector {
  public static selectNextQuestion(
    tbeScore: number,
    breScore: number,
    answers: AnswerSubmission[],
    maxQuestions: number = 3
  ): CanonicalQuestion | null {
    if (answers.length >= maxQuestions) {
      return null;
    }

    const answeredIds = new Set(answers.map((a) => a.question_id));
    const findQ = (id: QuestionId) => CANONICAL_QUESTIONS.find((q) => q.question_id === id) || null;

    // Blueprint Section 7.3 Decision Tree
    // If no questions answered yet:
    if (answers.length === 0) {
      if (tbeScore >= 40 || breScore >= 35) {
        return findQ('Q_URGENCY');
      }
      return null; // Safe transaction, no questions needed
    }

    const lastAnswer = answers[answers.length - 1];

    if (lastAnswer.question_id === 'Q_URGENCY') {
      if (lastAnswer.answer === 'YES') {
        return !answeredIds.has('Q_THREAT') ? findQ('Q_THREAT') : null;
      } else {
        // If not urgent, but beneficiary has risk signals -> ask identity/impersonation
        if (breScore >= 45 && !answeredIds.has('Q_IDENTITY')) {
          return findQ('Q_IDENTITY');
        }
        if (!answeredIds.has('Q_PURPOSE')) {
          return findQ('Q_PURPOSE');
        }
      }
    }

    if (lastAnswer.question_id === 'Q_THREAT') {
      if (lastAnswer.answer === 'YES') {
        return !answeredIds.has('Q_SECRECY') ? findQ('Q_SECRECY') : null;
      } else {
        return !answeredIds.has('Q_GUIDANCE') ? findQ('Q_GUIDANCE') : null;
      }
    }

    if (lastAnswer.question_id === 'Q_SECRECY') {
      if (!answeredIds.has('Q_IDENTITY')) {
        return findQ('Q_IDENTITY');
      }
    }

    // Default fallback to unasked relevant questions
    const fallbackIds: QuestionId[] = ['Q_IDENTITY', 'Q_GUIDANCE', 'Q_PURPOSE'];
    for (const id of fallbackIds) {
      if (!answeredIds.has(id)) {
        return findQ(id);
      }
    }

    return null;
  }
}

export class RiskFusionDecisionEngine {
  public static fuse(
    tbe: { score: number; reasons: CanonicalReasonCode[] },
    bre: { score: number; reasons: CanonicalReasonCode[] },
    cce: { score: number | null; reasons: CanonicalReasonCode[] },
    language: Language = 'en'
  ): RiskAssessment {
    const tScore = tbe.score;
    const bScore = bre.score;
    const cScore = cce.score;

    let overallScore: number;

    if (cScore !== null) {
      // Coercion context present (Payer-side APP scam protection active)
      if (cScore >= 60) {
        // High social engineering pressure reported (digital arrest / threat / urgency)
        overallScore = Math.round(0.15 * tScore + 0.25 * bScore + 0.60 * cScore);
        overallScore = Math.max(overallScore, cScore); // Coercion takes precedence
      } else if (cScore === 0) {
        // User confirmed no pressure
        overallScore = Math.round(0.45 * tScore + 0.55 * bScore);
      } else {
        overallScore = Math.round(0.25 * tScore + 0.35 * bScore + 0.40 * cScore);
      }
    } else {
      // Initial assessment before questionnaire
      overallScore = Math.round(0.40 * tScore + 0.60 * bScore);
    }

    overallScore = Math.min(100, Math.max(0, overallScore));

    // Risk level classification (Blueprint 6.2 defaults: LOW 0-29, MEDIUM 30-64, HIGH 65-100)
    let risk_level: RiskLevel = 'LOW';
    let recommended_action: RecommendedAction = 'ALLOW';

    if (overallScore >= 65) {
      risk_level = 'HIGH';
      recommended_action = bScore >= 80 ? 'BANK_REVIEW' : 'SAFETY_PAUSE';
    } else if (overallScore >= 30) {
      risk_level = 'MEDIUM';
      recommended_action = tScore >= 50 || bScore >= 50 ? 'VERIFY' : 'INFORM';
    } else {
      risk_level = 'LOW';
      recommended_action = 'ALLOW';
    }

    // Aggregate reason codes
    const allReasons = Array.from(new Set([...tbe.reasons, ...bre.reasons, ...cce.reasons]));

    // Generate human-readable explanations in selected language
    const explanations = this.generateExplanations(allReasons, risk_level, language);

    const requires_questions = cScore === null && (tScore >= 35 || bScore >= 30);

    return {
      overall_risk_score: overallScore,
      risk_level,
      recommended_action,
      component_scores: {
        transaction_anomaly_score: tScore,
        beneficiary_risk_score: bScore,
        coercion_risk_score: cScore,
      },
      reason_codes: allReasons,
      explanations,
      requires_questions,
      is_simulated: true,
    };
  }

  private static generateExplanations(
    reasons: CanonicalReasonCode[],
    level: RiskLevel,
    lang: Language
  ): string[] {
    const explanations: string[] = [];

    if (lang === 'te') {
      if (reasons.includes('AUTHORITY_THREAT_REPORTED')) {
        explanations.push('పోలీస్ లేదా అధికారిక బెదిరింపులు ఉన్నట్లు సమాచారం అందింది. నిజమైన పోలీసులు ఎప్పుడూ UPI ద్వారా డబ్బు డిమాండ్ చేయరు.');
      }
      if (reasons.includes('URGENCY_REPORTED')) {
        explanations.push('ఈ చెల్లింపు అత్యవసరంగా చేయాలని ఒత్తిడి ఉన్నట్లు గుర్తించబడింది.');
      }
      if (reasons.includes('SECRECY_REQUEST_REPORTED')) {
        explanations.push('కుటుంబ సభ్యులకు లేదా బ్యాంకుకు చెప్పవద్దని మోసగాళ్లు తరచుగా ఒంటరిగా ఉంచుతారు.');
      }
      if (reasons.includes('AMOUNT_ABOVE_BASELINE')) {
        explanations.push('ఈ మొత్తం మీ సాధారణ లావాదేవీల పరిమాణం కంటే గణనీయంగా ఎక్కువగా ఉంది.');
      }
      if (reasons.includes('BENEFICIARY_RAPID_OUTFLOW') || reasons.includes('BENEFICIARY_HIGH_INFLOW_DIVERSITY')) {
        explanations.push('లబ్ధిదారుడి ఖాతా అనుమానాస్పదంగా నిధులను వెంటనే వేరే ఖాతాలకు తరలిస్తున్న లక్షణాలు కలిగి ఉంది.');
      }
      if (explanations.length === 0) {
        explanations.push(
          level === 'LOW'
            ? 'ఎలాంటి ప్రధాన హెచ్చరిక సంకేతాలు కనుగొనబడలేదు. కొనసాగే ముందు లబ్ధిదారుడి పేరును ఒకసారి సరిచూసుకోండి.'
            : 'దయచేసి ఒక క్షణం ఆగి ఈ చెల్లింపు వివరాలను స్వతంత్రంగా నిర్ధారించుకోండి.'
        );
      }
    } else if (lang === 'hi') {
      if (reasons.includes('AUTHORITY_THREAT_REPORTED')) {
        explanations.push('पुलिस या कानूनी कार्रवाई की धमकी की सूचना मिली है। असली पुलिस कभी भी निजी UPI पर पैसे ट्रांसफर करने के लिए नहीं कहती।');
      }
      if (reasons.includes('URGENCY_REPORTED')) {
        explanations.push('यह भुगतान तुरंत करने का असामान्य दबाव रिपोर्ट किया गया है।');
      }
      if (reasons.includes('SECRECY_REQUEST_REPORTED')) {
        explanations.push('परिवार या बैंक से छिपाने के लिए कहना साइबर अपराधियों का प्रमुख पैंतरा है।');
      }
      if (reasons.includes('AMOUNT_ABOVE_BASELINE')) {
        explanations.push('यह राशि आपके सामान्य भुगतान औसत से काफी अधिक है।');
      }
      if (reasons.includes('BENEFICIARY_RAPID_OUTFLOW') || reasons.includes('BENEFICIARY_HIGH_INFLOW_DIVERSITY')) {
        explanations.push('प्राप्तकर्ता खाते में संदिग्ध म्यूल नेटवर्क के संकेत पाए गए हैं।');
      }
      if (explanations.length === 0) {
        explanations.push(
          level === 'LOW'
            ? 'कोई बड़ा जोखिम संकेत नहीं मिला। आगे बढ़ने से पहले प्राप्तकर्ता का नाम जांच लें।'
            : 'कृपया रुकें और इस भुगतान की स्थिति की स्वतंत्र रूप से जांच करें।'
        );
      }
    } else {
      // English
      if (reasons.includes('AUTHORITY_THREAT_REPORTED')) {
        explanations.push('Threat of arrest or legal penalty reported. Legitimate police or CBI officers never demand funds to private UPI IDs.');
      }
      if (reasons.includes('URGENCY_REPORTED')) {
        explanations.push('Unusual urgency reported connected to this payment initiation.');
      }
      if (reasons.includes('SECRECY_REQUEST_REPORTED')) {
        explanations.push('Instructions not to tell family or bank are a hallmark of social engineering isolation.');
      }
      if (reasons.includes('AMOUNT_ABOVE_BASELINE')) {
        explanations.push('Payment amount deviates significantly from this customer’s established baseline range.');
      }
      if (reasons.includes('BENEFICIARY_RAPID_OUTFLOW')) {
        explanations.push('Recipient account exhibits rapid fund pass-through characteristic of mule accounts.');
      }
      if (explanations.length === 0) {
        explanations.push(
          level === 'LOW'
            ? 'No major warning signs were found. Verify the recipient name before continuing.'
            : 'This payment differs from your usual activity. Please verify recipient details independently.'
        );
      }
    }

    return explanations;
  }
}

// Web Speech API Voice Controller
export class WebSpeechController {
  public static speak(text: string, lang: Language = 'en', rate: number = 0.9): void {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
      return;
    }

    window.speechSynthesis.cancel(); // Stop any active speech

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = rate; // slightly slower for senior accessibility
    utterance.pitch = 1.0;

    const langCodes: Record<Language, string> = {
      en: 'en-IN',
      te: 'te-IN',
      hi: 'hi-IN',
    };
    utterance.lang = langCodes[lang] || 'en-IN';

    // Find native or fallback voice
    const voices = window.speechSynthesis.getVoices();
    const matchingVoice = voices.find((v) => v.lang.startsWith(utterance.lang) || v.lang.startsWith(lang));
    if (matchingVoice) {
      utterance.voice = matchingVoice;
    }

    window.speechSynthesis.speak(utterance);
  }

  public static stop(): void {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
  }
}
