export type DetectedChannel = 'PHONE_APP' | 'LAPTOP_WEB';

export interface DeviceContextInfo {
  deviceType: 'PHONE' | 'LAPTOP';
  channel: DetectedChannel;
  label: string;
  osLabel: string;
  browserLabel: string;
}

export function detectDeviceContext(userAgentInput?: string, viewportWidth?: number): DeviceContextInfo {
  const ua =
    userAgentInput ??
    (typeof navigator !== 'undefined' && typeof navigator.userAgent === 'string'
      ? navigator.userAgent
      : '');
  const width =
    viewportWidth ??
    (typeof window !== 'undefined' && typeof window.innerWidth === 'number'
      ? window.innerWidth
      : 1440);

  const lowerUa = ua.toLowerCase();
  const isMobileUa = /iphone|ipod|android.*mobile|windows phone|blackberry|mobile/.test(lowerUa);
  const isPhone = isMobileUa || (width > 0 && width <= 640);

  let osLabel = 'Desktop OS';
  if (/android/.test(lowerUa)) osLabel = 'Android';
  else if (/iphone|ipad|ipod/.test(lowerUa)) osLabel = 'iOS';
  else if (/mac os x|macintosh/.test(lowerUa)) osLabel = 'macOS';
  else if (/windows/.test(lowerUa)) osLabel = 'Windows';
  else if (/linux/.test(lowerUa)) osLabel = 'Linux';

  let browserLabel = 'Web Browser';
  if (/edg\//.test(lowerUa)) browserLabel = 'Edge';
  else if (/chrome|crios/.test(lowerUa)) browserLabel = 'Chrome';
  else if (/firefox|fxios/.test(lowerUa)) browserLabel = 'Firefox';
  else if (/safari/.test(lowerUa)) browserLabel = 'Safari';

  return isPhone
    ? {
        deviceType: 'PHONE',
        channel: 'PHONE_APP',
        label: `Mobile Phone (${osLabel} · ${browserLabel})`,
        osLabel,
        browserLabel,
      }
    : {
        deviceType: 'LAPTOP',
        channel: 'LAPTOP_WEB',
        label: `Laptop / Desktop (${osLabel} · ${browserLabel})`,
        osLabel,
        browserLabel,
      };
}
