import React, { createContext, useContext, useEffect, useState } from 'react';
import { onAuthStateChanged, signInWithPopup, signOut } from 'firebase/auth';
import { auth, googleAuthProvider } from '../lib/firebase';
import { PortalUser } from '../types';

const PORTAL_TOKEN_KEY = 'streamshield_portal_token';
const PORTAL_USER_KEY = 'streamshield_portal_user';

interface AuthContextValue {
  user: PortalUser | null;
  loading: boolean;
  authError: string | null;
  getIdToken: () => Promise<string | null>;
  loginAsUser: (identifier: string, password: string) => Promise<void>;
  loginAsAdmin: (adminId: string, password: string) => Promise<void>;
  signInWithGoogle: () => Promise<void>;
  logout: () => Promise<void>;
  clearError: () => void;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<PortalUser | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [authError, setAuthError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;

    const restoreSession = async () => {
      const savedToken = localStorage.getItem(PORTAL_TOKEN_KEY);
      if (savedToken) {
        try {
          const resp = await fetch('/api/auth/me', {
            headers: { Authorization: `Bearer ${savedToken}` },
          });
          if (resp.ok) {
            const data = await resp.json();
            if (!cancelled) {
              const restored: PortalUser = {
                uid: data.uid,
                email: data.email || '',
                displayName: data.displayName || data.uid,
                role: data.role === 'ADMIN' ? 'ADMIN' : 'USER',
                customerId: data.customerId || undefined,
                adminId: data.adminId || undefined,
                authProvider: data.authProvider === 'GOOGLE' ? 'GOOGLE' : 'CREDENTIALS',
              };
              setUser(restored);
              localStorage.setItem(PORTAL_USER_KEY, JSON.stringify(restored));
              setLoading(false);
              return;
            }
          }
        } catch {
          // Fall through to clear invalid token
        }
        localStorage.removeItem(PORTAL_TOKEN_KEY);
        localStorage.removeItem(PORTAL_USER_KEY);
      }

      if (!cancelled) {
        setLoading(false);
      }
    };

    restoreSession();

    const unsubscribe = onAuthStateChanged(auth, async (fbUser) => {
      if (fbUser && !localStorage.getItem(PORTAL_TOKEN_KEY)) {
        try {
          const token = await fbUser.getIdToken();
          const resp = await fetch('/api/auth/me', {
            headers: { Authorization: `Bearer ${token}` },
          });
          if (resp.ok && !cancelled) {
            const data = await resp.json();
            setUser({
              uid: fbUser.uid,
              email: fbUser.email || '',
              displayName: fbUser.displayName || fbUser.email || 'UPI User',
              role: 'USER',
              customerId: data.customerId || 'CUS_0002',
              authProvider: 'GOOGLE',
            });
          }
        } catch {
          // Non-fatal
        } finally {
          if (!cancelled) setLoading(false);
        }
      }
    });

    return () => {
      cancelled = true;
      unsubscribe();
    };
  }, []);

  const getIdToken = async (): Promise<string | null> => {
    const portalToken = localStorage.getItem(PORTAL_TOKEN_KEY);
    if (portalToken) return portalToken;
    if (auth.currentUser) {
      return auth.currentUser.getIdToken();
    }
    return null;
  };

  const loginAsUser = async (identifier: string, password: string) => {
    setAuthError(null);
    const resp = await fetch('/api/auth/user/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ identifier, password }),
    });
    const data = await resp.json();
    if (!resp.ok) {
      const msg = data?.error?.message || 'Unable to sign in as UPI User.';
      setAuthError(msg);
      throw new Error(msg);
    }
    const loggedIn: PortalUser = {
      uid: data.user.uid,
      email: data.user.email,
      displayName: data.user.name || data.user.displayName || data.user.customerId,
      role: 'USER',
      customerId: data.user.customerId,
      authProvider: 'CREDENTIALS',
    };
    localStorage.setItem(PORTAL_TOKEN_KEY, data.token);
    localStorage.setItem(PORTAL_USER_KEY, JSON.stringify(loggedIn));
    setUser(loggedIn);
  };

  const loginAsAdmin = async (adminId: string, password: string) => {
    setAuthError(null);
    const resp = await fetch('/api/auth/admin/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ adminId, password }),
    });
    const data = await resp.json();
    if (!resp.ok) {
      const msg = data?.error?.message || 'Invalid Bank Administrator credentials.';
      setAuthError(msg);
      throw new Error(msg);
    }
    const loggedIn: PortalUser = {
      uid: data.user.uid,
      email: data.user.email,
      displayName: data.user.name || data.user.displayName || data.user.adminId,
      role: 'ADMIN',
      adminId: data.user.adminId,
      authProvider: 'CREDENTIALS',
    };
    localStorage.setItem(PORTAL_TOKEN_KEY, data.token);
    localStorage.setItem(PORTAL_USER_KEY, JSON.stringify(loggedIn));
    setUser(loggedIn);
  };

  const signInWithGoogle = async () => {
    setAuthError(null);
    try {
      localStorage.removeItem(PORTAL_TOKEN_KEY);
      localStorage.removeItem(PORTAL_USER_KEY);
      const cred = await signInWithPopup(auth, googleAuthProvider);
      const token = await cred.user.getIdToken();
      const resp = await fetch('/api/auth/me', {
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = resp.ok ? await resp.json() : {};
      setUser({
        uid: cred.user.uid,
        email: cred.user.email || '',
        displayName: cred.user.displayName || cred.user.email || 'UPI User',
        role: 'USER',
        customerId: data.customerId || 'CUS_0002',
        authProvider: 'GOOGLE',
      });
    } catch (err: any) {
      setAuthError(err?.message || 'Google sign-in could not be completed.');
    }
  };

  const logout = async () => {
    setAuthError(null);
    localStorage.removeItem(PORTAL_TOKEN_KEY);
    localStorage.removeItem(PORTAL_USER_KEY);
    setUser(null);
    if (auth.currentUser) {
      await signOut(auth);
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        loading,
        authError,
        getIdToken,
        loginAsUser,
        loginAsAdmin,
        signInWithGoogle,
        logout,
        clearError: () => setAuthError(null),
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) {
    throw new Error('useAuth must be used inside AuthProvider');
  }
  return ctx;
}
