export type Language = 'en' | 'te' | 'hi';

export type RiskLevel = 'LOW' | 'MEDIUM' | 'HIGH';

export type RecommendedAction = 'ALLOW' | 'INFORM' | 'VERIFY' | 'SAFETY_PAUSE' | 'BANK_REVIEW';

export type PaymentStatus =
  | 'ASSESSMENT_PENDING_CONTEXT'
  | 'QUESTIONNAIRE_IN_PROGRESS'
  | 'ASSESSMENT_COMPLETE'
  | 'SIMULATION_CONTINUED'
  | 'SIMULATION_PAUSED'
  | 'SIMULATION_CANCELLED'
  | 'REFERRED_FOR_REVIEW'
  | 'APPROVED_BY_BANK'
  | 'TERMINATED_SCAM';

export type PortalRole = 'USER' | 'ADMIN';

export interface PortalUser {
  uid: string;
  email: string;
  displayName: string;
  role: PortalRole;
  customerId?: string;
  adminId?: string;
  authProvider: 'CREDENTIALS' | 'GOOGLE';
}

export type QuestionId =
  | 'Q_URGENCY'
  | 'Q_THREAT'
  | 'Q_SECRECY'
  | 'Q_GUIDANCE'
  | 'Q_IDENTITY'
  | 'Q_PURPOSE';

export type QuestionAnswer = 'YES' | 'NO' | 'NOT_SURE' | 'SKIP' | 'NEED_HELP';

export type InputMode = 'TAP' | 'VOICE' | 'TEXT';

export type CustomerChoice =
  | 'CONTINUE_SIMULATED'
  | 'PAUSE_AND_VERIFY'
  | 'CANCEL_SIMULATED'
  | 'REQUEST_BANK_REVIEW';

export type FeedbackOutcome =
  | 'CONFIRMED_SCAM'
  | 'CONFIRMED_LEGITIMATE'
  | 'UNRESOLVED'
  | 'USER_CANCELLED'
  | 'REFERRED_FOR_REVIEW';

export type FeedbackLabelSource = 'SYNTHETIC_SCENARIO' | 'DEMO_USER' | 'CUSTOMER' | 'REVIEWER';

export type CanonicalReasonCode =
  | 'NEW_BENEFICIARY'
  | 'AMOUNT_ABOVE_BASELINE'
  | 'UNUSUAL_PAYMENT_TIME'
  | 'HIGH_PAYMENT_VELOCITY'
  | 'BENEFICIARY_HIGH_INFLOW_DIVERSITY'
  | 'BENEFICIARY_RAPID_OUTFLOW'
  | 'BENEFICIARY_NETWORK_LINKS'
  | 'URGENCY_REPORTED'
  | 'AUTHORITY_THREAT_REPORTED'
  | 'SECRECY_REQUEST_REPORTED'
  | 'REMOTE_GUIDANCE_REPORTED'
  | 'IMPERSONATION_REPORTED'
  | 'INSUFFICIENT_CONTEXT';

export interface CustomerProfile {
  customer_id: string;
  name: string;
  preferred_language: Language;
  profile_group: 'SENIOR' | 'GENERAL' | 'LIMITED_LITERACY_TEST';
  baseline_txn_count_30d: number;
  baseline_amount_median: number;
  baseline_amount_mad: number;
  usual_active_hours: number[];
  occupation: string;
  age: number;
}

export interface BeneficiaryProfile {
  beneficiary_id: string;
  vpa: string;
  name: string;
  account_age_days: number | null;
  customer_counterparties_30d: number;
  incoming_txn_count_24h: number;
  incoming_amount_24h: number;
  outgoing_amount_24h: number;
  flow_through_ratio: number;
  network_degree: number;
  synthetic_report_count: number;
  category: string;
  risk_tier?: 'LOW' | 'MEDIUM' | 'HIGH';
}

export interface ComponentScores {
  transaction_anomaly_score: number;
  beneficiary_risk_score: number;
  coercion_risk_score: number | null;
}

export interface RiskAssessment {
  overall_risk_score: number;
  risk_level: RiskLevel;
  recommended_action: RecommendedAction;
  component_scores: ComponentScores;
  reason_codes: CanonicalReasonCode[];
  explanations: string[];
  requires_questions: boolean;
  is_simulated: boolean;
  scoring_latency_ms?: number;
  model_version?: string;
  policy_version?: string;
}

export interface CanonicalQuestion {
  question_id: QuestionId;
  text?: string;
  translations: {
    en: string;
    te: string;
    hi: string;
  };
  audio_prompts: {
    en: string;
    te: string;
    hi: string;
  };
  intent?: string;
  triggered_reason_code?: CanonicalReasonCode;
  answer_options: QuestionAnswer[];
  audio_available?: boolean;
}

export interface AnswerSubmission {
  question_id: QuestionId;
  answer: QuestionAnswer;
  input_mode: InputMode;
  answered_at: string;
}

export interface SimulatedPaymentSession {
  payment_id: string;
  customer_id: string;
  beneficiary_id: string;
  beneficiary_name?: string;
  beneficiary_vpa?: string;
  amount: number;
  currency: 'INR';
  purpose: string;
  language: Language;
  channel: 'WEB_SIMULATOR' | 'PHONE_APP' | 'LAPTOP_WEB';
  status: PaymentStatus;
  created_at: string;
  is_simulated: true;
  initial_assessment?: RiskAssessment;
  final_assessment?: RiskAssessment;
  answers: AnswerSubmission[];
  customer_choice?: CustomerChoice;
  feedback?: {
    outcome: FeedbackOutcome;
    label_source: FeedbackLabelSource;
    notes?: string;
  };
}

export interface UserAccountSummary {
  profile: CustomerProfile;
  vpa: string;
  average_risk_score: number;
  latest_risk_score: number;
  total_transactions: number;
  pending_review_count: number;
  approved_count: number;
  terminated_count: number;
  transactions: SimulatedPaymentSession[];
}

export type Decision = 'ALLOW' | 'STEP_UP' | 'HOLD';

export type TransactionType = 'P2P' | 'P2M' | 'MULE_FAN_IN' | 'MULE_CIRCULAR_SMURF' | 'PHISHING_SWEEP';

export interface UPITransaction {
  tx_id: string;
  timestamp: number;
  sender: string;
  receiver: string;
  amount: number;
  device_id: string;
  is_new_account: boolean;
  tx_type: TransactionType;
  label?: number;
  round: 1 | 2;
  note?: string;
}

export interface FeatureBreakdown {
  velocity_60s: number;
  amount_ratio: number;
  unique_users_on_device: number;
  receiver_in_degree: number;
  receiver_out_degree: number;
  pass_through_ratio: number;
  is_new_account: number;
  sender_risk_cached: number;
  receiver_risk_cached: number;
}

export interface ScoredTransaction extends UPITransaction {
  risk_score: number;
  decision: Decision;
  reasons: string[];
  latency_ms: number;
  features: FeatureBreakdown;
  shap_contributions?: {
    feature: string;
    impact: number;
    description: string;
  }[];
  frozen?: boolean;
}

export interface EngineStats {
  totalScored: number;
  totalFraudBlockedINR: number;
  totalFrictionCostINR: number;
  netBenefitINR: number;
  latencies: number[];
  p50Latency: number;
  p95Latency: number;
  p99Latency: number;
  decisionCounts: {
    ALLOW: number;
    STEP_UP: number;
    HOLD: number;
  };
  precision: number;
  recall: number;
  prAuc: number;
}

export interface GraphNode {
  id: string;
  label: string;
  type: 'genuine' | 'mule' | 'victim' | 'frozen';
  x: number;
  y: number;
  vx: number;
  vy: number;
  inDegree: number;
  outDegree: number;
  riskScore: number;
  totalReceived: number;
  totalSent: number;
  isNewAccount?: boolean;
}

export interface GraphEdge {
  id: string;
  source: string;
  target: string;
  amount: number;
  timestamp: number;
  isFraud: boolean;
  decision: Decision;
}

export interface AblationModelMetrics {
  key: string;
  name: string;
  modules: string;
  description: string;
  threshold: number;
  precision: number;
  recall: number;
  f1: number;
  prAuc: number;
  brierScore: number;
  fpRate: number;
  fnRate: number;
  digitalArrestCaughtPercent: number;
  confusionMatrix: {
    tp: number;
    fp: number;
    tn: number;
    fn: number;
  };
  avgLatencyMs: number;
  p50LatencyMs: number;
  p95LatencyMs: number;
}

export interface AblationReport {
  generated_at: string | null;
  dataset_summary: {
    total_scenarios: number;
    test_scenarios: number;
    test_positive_rate: number;
    avg_questions_per_payment: number;
    questionnaire_skip_rate: number;
    split_strategy: string;
  } | null;
  models: AblationModelMetrics[];
}

export interface AdminMetricsSummary {
  total_payments: number;
  count_by_risk_level: Record<string, number>;
  count_by_recommended_action: Record<string, number>;
  feedback_outcome_counts: Record<string, number>;
  avg_scoring_latency_ms: number;
  p99_scoring_latency_ms: number;
}
