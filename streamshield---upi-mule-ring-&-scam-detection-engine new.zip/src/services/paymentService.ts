import { apiRequest } from './apiClient';
import {
  AblationReport,
  AdminMetricsSummary,
  AnswerSubmission,
  CanonicalQuestion,
  CustomerChoice,
  FeedbackLabelSource,
  FeedbackOutcome,
  InputMode,
  Language,
  PaymentStatus,
  QuestionAnswer,
  QuestionId,
  RiskAssessment,
  SimulatedPaymentSession,
  UserAccountSummary,
} from '../types';

export interface InitiatePaymentPayload {
  customer_id: string;
  beneficiary_id: string;
  amount: number;
  currency: 'INR';
  purpose: string;
  language: Language;
  channel: 'WEB_SIMULATOR' | 'PHONE_APP' | 'LAPTOP_WEB';
  custom_vpa?: string;
}

export interface InitiatePaymentResult {
  payment_id: string;
  status: PaymentStatus;
  is_simulated: boolean;
  initial_assessment: RiskAssessment;
  next_question: CanonicalQuestion | null;
}

export interface SubmitAnswerResult {
  payment_id: string;
  questionnaire_status: 'IN_PROGRESS' | 'COMPLETED';
  questions_answered: number;
  max_questions: number;
  next_question: CanonicalQuestion | null;
  final_assessment: RiskAssessment | null;
}

export interface DemoScoreResult {
  payment_id: string;
  status: PaymentStatus;
  is_simulated: boolean;
  assessment: RiskAssessment;
  next_question: CanonicalQuestion | null;
  questions_answered: number;
  max_questions: number;
}

export const paymentService = {
  async fetchUserAccount(token: string, customerId?: string): Promise<UserAccountSummary> {
    const query = customerId ? `?customer_id=${encodeURIComponent(customerId)}` : '';
    return apiRequest<UserAccountSummary>(`/api/v1/user/account${query}`, { token });
  },

  async initiatePayment(
    payload: InitiatePaymentPayload,
    token: string | null
  ): Promise<InitiatePaymentResult> {
    if (token) {
      return apiRequest<InitiatePaymentResult>('/api/v1/payments/initiate', {
        method: 'POST',
        body: payload,
        token,
      });
    }
    const demo = await apiRequest<DemoScoreResult>('/api/v1/demo/score', {
      method: 'POST',
      body: { ...payload, answers: [] },
    });
    return {
      payment_id: demo.payment_id,
      status: demo.status,
      is_simulated: demo.is_simulated,
      initial_assessment: demo.assessment,
      next_question: demo.next_question,
    };
  },

  async submitAnswer(
    paymentId: string,
    payload: {
      question_id: QuestionId;
      answer: QuestionAnswer;
      input_mode: InputMode;
    },
    token: string | null,
    contextForDemo?: {
      customer_id: string;
      beneficiary_id: string;
      amount: number;
      purpose: string;
      language: Language;
      custom_vpa?: string;
      answers: AnswerSubmission[];
    }
  ): Promise<SubmitAnswerResult> {
    if (token && !paymentId.startsWith('DEMO_')) {
      return apiRequest<SubmitAnswerResult>(`/api/v1/payments/${paymentId}/answers`, {
        method: 'POST',
        body: payload,
        token,
      });
    }
    const demo = await apiRequest<DemoScoreResult>('/api/v1/demo/score', {
      method: 'POST',
      body: {
        customer_id: contextForDemo?.customer_id || 'CUS_0001',
        beneficiary_id: contextForDemo?.beneficiary_id || 'BEN_0601',
        amount: contextForDemo?.amount || 75000,
        currency: 'INR',
        purpose: contextForDemo?.purpose || 'Payment transfer',
        language: contextForDemo?.language || 'en',
        custom_vpa: contextForDemo?.custom_vpa,
        answers: contextForDemo?.answers || [],
      },
    });
    return {
      payment_id: paymentId,
      questionnaire_status: demo.next_question ? 'IN_PROGRESS' : 'COMPLETED',
      questions_answered: demo.questions_answered,
      max_questions: demo.max_questions,
      next_question: demo.next_question,
      final_assessment: demo.next_question ? null : demo.assessment,
    };
  },

  async recordDecision(
    paymentId: string,
    customerChoice: CustomerChoice,
    token: string | null,
    options?: { reportFraud?: boolean }
  ): Promise<{ payment_id: string; status: PaymentStatus; message_key?: string }> {
    if (token && !paymentId.startsWith('DEMO_')) {
      return apiRequest(`/api/v1/payments/${paymentId}/decision`, {
        method: 'POST',
        body: {
          customer_choice: customerChoice,
          report_fraud: Boolean(options?.reportFraud),
        },
        token,
      });
    }
    const map: Record<CustomerChoice, PaymentStatus> = {
      CONTINUE_SIMULATED: 'SIMULATION_CONTINUED',
      PAUSE_AND_VERIFY: 'SIMULATION_PAUSED',
      CANCEL_SIMULATED: 'SIMULATION_CANCELLED',
      REQUEST_BANK_REVIEW: 'REFERRED_FOR_REVIEW',
    };
    return { payment_id: paymentId, status: map[customerChoice] };
  },

  async submitFeedback(
    paymentId: string,
    outcome: FeedbackOutcome,
    labelSource: FeedbackLabelSource,
    notes: string | undefined,
    token: string | null
  ): Promise<{ feedback_id: string; saved: boolean; updated_status?: PaymentStatus | null }> {
    if (token && !paymentId.startsWith('DEMO_')) {
      return apiRequest('/api/v1/feedback', {
        method: 'POST',
        body: { payment_id: paymentId, outcome, label_source: labelSource, notes },
        token,
      });
    }
    return { feedback_id: `LOCAL_${Date.now()}`, saved: true };
  },

  async fetchAdminAlerts(token: string): Promise<{ items: SimulatedPaymentSession[]; count: number }> {
    return apiRequest('/api/v1/admin/alerts?limit=50', { token });
  },

  async fetchAdminMetrics(token: string): Promise<AdminMetricsSummary> {
    return apiRequest('/api/v1/admin/metrics', { token });
  },

  async fetchAblationReport(token?: string | null): Promise<AblationReport> {
    return apiRequest<AblationReport>('/api/v1/evaluation/ablation', { token });
  },
};
