# STREAMSHIELD — MASTER PROJECT BLUEPRINT

**Document type:** Canonical product + engineering specification  
**Version:** 1.0  
**Date:** 12 November 2026  
**Project stage:** Hackathon prototype / proof of concept  
**Status:** Proposed design; implementation and measured performance are not yet established

> **Purpose of this document**  
> This is the single source of truth for every human contributor and every AI assistant helping with StreamShield. Share this document, or at minimum the “Global context for every AI” section, with every contributor. Do not let individual contributors invent their own product scope, API names, field names, risk labels, or user journeys.

---

# 0. NON-NEGOTIABLE PROJECT CONTEXT

## 0.1 Product in one sentence

**StreamShield is a proposed, bank-integrated, real-time payment-protection layer that combines transaction-behaviour analysis, beneficiary/mule-risk intelligence, and victim-side social-engineering context to help prevent people from being manipulated into authorising fraudulent digital payments.**

## 0.2 Core product idea

Do not only ask: **“Is the receiving account suspicious?”**  
Also ask: **“Could the person sending this money be under pressure or manipulation?”**

StreamShield combines both perspectives:

1. **Beneficiary-side detection:** identify accounts and transaction flows that exhibit possible mule-account or suspicious-network behaviour.
2. **Payer-side protection:** identify possible social engineering, coercion, impersonation, urgency, secrecy, or scam pressure affecting the person initiating a payment.
3. **Accessible intervention:** explain the risk in plain language and in the customer's chosen language, using voice and visual interaction as well as text.

## 0.3 Target users and buyers

- **Primary design users:** senior citizens and people with limited digital literacy or limited English literacy.
- **Other beneficiaries:** all everyday digital-payment users, including students, workers, families, and small-business owners.
- **Likely buyers/integration partners:** banks, UPI apps, payment service providers, and other authorised financial institutions.
- **Preferred product model:** B2B bank/payment-provider integration. The hackathon prototype will simulate this integration; it will not connect to live UPI rails.

Age is not an eligibility condition. The product should be useful to anyone and especially understandable to people who need additional assistance.

## 0.4 Product positioning

StreamShield is **not** a replacement for RBI systems, a bank's fraud controls, NPCI/UPI infrastructure, law enforcement, or customer authentication. It is a proposed additional decision-support and customer-protection layer that could consume authorised beneficiary-risk signals and add payer-context assessment and accessible intervention.

## 0.5 What we are building now

A demonstrable prototype with:

- simulated payment initiation;
- synthetic customer histories and beneficiary profiles;
- transaction anomaly scoring;
- beneficiary/mule-pattern scoring;
- a short, adaptive social-engineering questionnaire;
- a risk-fusion and intervention decision;
- a multilingual, voice-assisted customer experience;
- an investigator/admin dashboard;
- a feedback and evaluation loop.

**The prototype does not move, hold, reverse, or block real money.** It demonstrates decisions using simulated payments. Real production action would require authorised integration, bank policy, legal/regulatory review, and operational controls.

---

# 1. PROBLEM STATEMENT

## 1.1 The problem

In an authorised push payment (APP) scam, a victim is manipulated into initiating and authorising a payment themselves. Examples include fake digital-arrest threats, fake bank/KYC calls, investment scams, impersonation of relatives, and other social-engineering schemes.

A payment can appear technically valid because the customer is using their own device and completing the normal authentication process. Authentication proves that the payment was authorised through the required mechanism; it does not necessarily prove that the customer understood the situation or acted free from manipulation.

## 1.2 Example scenario

A caller pretends to be a police officer, claims that the customer's identity is linked to a criminal case, tells the customer not to speak to family, and demands an immediate transfer of ₹75,000 to “avoid arrest.” The customer opens a payment app and initiates the transfer.

A conventional transaction-only check may see a validly authenticated payment. StreamShield attempts to add context:

- Is the recipient new or unusually risky?
- Is the payment atypical for this customer?
- Is the customer reporting urgency, threats, secrecy, impersonation, or remote guidance?
- Are there authorised beneficiary-risk signals or suspicious transaction-network patterns?

The system then provides a clear, proportionate intervention before the simulated payment is completed.

## 1.3 Why both sides matter

- A mule-risk recipient score alone may miss a newly created or previously unseen fraud account.
- A payer's unusual transaction alone may be a legitimate emergency or business payment.
- A user questionnaire alone can be unreliable if the victim is frightened, coached, confused, or unwilling to disclose.
- A robust approach combines independent signals and explains uncertainty. No single signal should automatically label a customer or beneficiary as criminal.

---

# 2. EXISTING ECOSYSTEM AND OUR RELATIONSHIP TO IT

## 2.1 RBI MuleHunter.ai

RBI's published Annual Report 2025–26 describes MuleHunter.ai as using diverse behavioural and transactional features derived from real-world fraud patterns and ecosystem-level learnings to assign a confidence score to each bank account indicating its likelihood of being a mule. The same report states that it had been implemented in 26 banks as of 31 March 2026, with implementation underway in four more; the bank decides what action to take after receiving the score, based on its own assessment and enhanced due diligence.

**What this means for StreamShield:** mule-account detection is already an active area of work in India's banking ecosystem. We should not claim that StreamShield invented mule detection or that RBI only uses simple rules. Our prototype will implement its own transparent, synthetic-data-based beneficiary risk model for demonstration, and the design can conceptually accept authorised risk signals from a bank or shared intelligence service in a real deployment.

## 2.2 RBI Digital Payments Intelligence Platform (DPIP)

RBI material describes DPIP as an ecosystem-level digital-payment fraud-intelligence initiative intended to support risk identification and information sharing. RBI's Annual Report 2025–26 says that, for 2026–27, it is exploring full-scale implementation of DPIP. A separate RBI planning document lists December 2026 as a target for operationalisation. These are planning statements, not evidence in this blueprint that full-scale DPIP is already live on 12 November 2026.

**What this means for StreamShield:** do not claim to connect to DPIP. In the hackathon, beneficiary intelligence is synthetic. In a future authorised deployment, StreamShield could consume an approved beneficiary-risk signal if an institution and the relevant platform permit it.

## 2.3 Other commercial products

Commercial fraud vendors advertise overlapping capabilities, including behavioural analytics, social-engineering/coercion signals, device or remote-access signals, mule intelligence, and payment interventions. Public product descriptions are vendor claims and do not provide access to their proprietary models or a directly comparable benchmark.

**What this means for StreamShield:** our goal is not to claim that these capabilities are new. Our goal is to build a high-quality, testable, accessible implementation and measure it honestly against reproducible baselines.

## 2.4 Our proposed contribution

StreamShield's proposed product contribution is the **integrated customer-protection experience**:

- beneficiary/mule-risk assessment;
- payer transaction-behaviour assessment;
- explicit, adaptive social-engineering context;
- clear and accessible intervention, particularly for users who do not read English comfortably.

This is a design focus, not a proven unique market capability. Do not claim no other product does any of these things.

---

# 3. SCOPE, NON-GOALS, AND ASSUMPTIONS

## 3.1 In scope for hackathon MVP

1. Simulated UPI-like payment flow.
2. Synthetic customer profiles and transaction history.
3. New-beneficiary and unusual-payment detection.
4. Synthetic beneficiary/mule-risk scoring and simple graph/network features.
5. Adaptive questions about possible scam pressure.
6. Multi-signal risk fusion.
7. Explainable decision output.
8. Accessible customer flow with English, Telugu, and Hindi as initial target languages.
9. Voice playback and speech input where implementation time and browser/device support allow; typed/tap controls must always remain available.
10. Admin dashboard and feedback capture.
11. Offline evaluation on held-out synthetic scenarios.

## 3.2 Explicitly out of scope for MVP

- Connecting to real UPI, NPCI, bank, telecom, or RBI systems.
- Accessing live bank transaction histories or cross-bank customer information.
- Intercepting transactions in third-party UPI applications.
- Reading calls, SMS, WhatsApp, screen content, contacts, or other private device data without explicit consent and a lawful integration.
- Always-on microphone monitoring or covert recording.
- Automatically freezing accounts, blocking real transactions, or reversing funds.
- Claiming that a simulated mule score is an RBI score.
- Claiming that our model has beaten DeepID, Darwinium, Outseer, MuleHunter.ai, or DPIP.
- Voice cloning, speaker identification, emotion diagnosis, or inferring fraud from voice tone alone.
- Large-scale distributed streaming infrastructure (Kafka/Flink) in the first MVP unless actual throughput needs justify it.

## 3.3 Assumptions

- The hackathon demonstration uses generated/synthetic data only.
- Any “payment” shown in the demo is simulated and has no banking effect.
- The prototype can use a manually selected demo customer profile rather than authenticating a real bank customer.
- Language and speech services may be local, browser-supported, or external; the implementation must identify which and document any data sent to a third party.
- The first release is a web application designed mobile-first.

---

# 4. PRODUCT USERS AND USER JOURNEYS

## 4.1 Personas

### Persona A — Senior citizen / limited digital literacy
- May prefer Telugu or Hindi over English.
- May not understand technical terms such as “mule account,” “APP fraud,” or “risk score.”
- Needs large touch targets, short prompts, spoken instructions, and calm language.
- May be under pressure during a scam and need clear steps rather than a long explanation.

### Persona B — Everyday UPI user
- Wants fast payments and does not want unnecessary interruptions.
- Needs warnings only when relevant and useful.
- Must be able to understand why a warning appeared and how to continue safely.

### Persona C — Bank fraud analyst (dashboard user)
- Needs a concise event summary, component scores, reason codes, and a review trail.
- Must not see a score presented as proof of guilt.
- Needs feedback fields for confirmed fraud, legitimate payment, unresolved, and customer-cancelled outcomes.

## 4.2 User journey A — Normal legitimate payment

1. User selects a demo profile, enters recipient and amount.
2. Frontend sends payment initiation request.
3. Backend retrieves the selected synthetic customer baseline and recipient profile.
4. Engines calculate transaction, beneficiary, and initial context risk.
5. Risk decision is LOW.
6. UI gives a simple confirmation and allows the simulated payment to continue.
7. Event is stored for evaluation.

Expected result: quick, low-friction experience.

## 4.3 User journey B — Possible coercion / digital-arrest scam

1. User enters a large or unusual payment to a new recipient.
2. Initial assessment finds one or more signals and decides that additional context is useful.
3. UI asks one short question in the user's chosen language, with audio playback and tap-to-answer controls.
4. Depending on the answer, the system chooses the next most useful question. Maximum default: three questions; never keep interrogating indefinitely.
5. Coercion Context Engine updates its score and reason codes.
6. Risk Fusion Engine produces final risk level and action.
7. High-risk UI says, in plain language, that someone may be pressuring the user; recommends stopping, ending the call if safe, and independently contacting the bank or a trusted person using a known official number.
8. Demo simulates a safety pause or bank review. It does not move or block real money.

## 4.4 User journey C — Suspicious beneficiary, no disclosed coercion

1. User initiates payment to a beneficiary with synthetic network-risk signals.
2. Beneficiary Risk Engine returns a higher score and reason codes.
3. The user may say nobody is pressuring them.
4. The system must not treat “No” as proof that the payment is safe. It combines beneficiary, transaction, and context signals.
5. The system may show a beneficiary warning or request independent verification.

## 4.5 User journey D — Legitimate unusual payment

1. User initiates a large payment that differs from their baseline, for example a medical or education payment.
2. Transaction anomaly score increases, but beneficiary/context signals are reassuring.
3. System asks a short clarifying question only if needed.
4. It can classify as medium risk or allow with an informational warning, depending on calibrated evidence and policy.
5. It must not call the user a fraudster or assume an unusual payment is fraudulent.

## 4.6 User journey E — User cannot or does not want to answer

- Provide “I don't know,” “Skip,” and “I need help” options where appropriate.
- Not answering is not proof of fraud.
- The system should keep the uncertainty explicit and use other available signals.
- Do not punish users for disability, speech-recognition errors, language mismatch, or inability to answer.

---

# 5. PRODUCT MODULES — CANONICAL NAMES AND RESPONSIBILITIES

Use these exact module names throughout code, documentation, APIs, and presentations.

## 5.1 Payment Simulator (PS)

**Responsibility:** collect demo payment inputs and create a simulated payment session.

Inputs: customer ID, beneficiary ID/details, amount, currency, purpose, selected language.  
Outputs: payment session ID and initial assessment request.

Must not initiate a real bank transaction.

## 5.2 Transaction Behaviour Engine (TBE)

**Responsibility:** compare the current payment and recent activity against the selected synthetic customer's baseline.

Initial features:
- amount deviation from customer's historical median/typical range;
- new beneficiary indicator;
- beneficiary age in customer's saved list, if available;
- transaction count/amount in short rolling windows;
- unusual time-of-day indicator;
- recent failed/cancelled attempts, if included in synthetic data;
- first-time/high-value combination.

Output: `transaction_anomaly_score` from 0 to 100 plus reason codes.

## 5.3 Beneficiary Risk Engine (BRE)

**Responsibility:** estimate whether the recipient has suspicious/mule-like patterns using only authorised or synthetic data.

Initial features:
- number of distinct incoming counterparties in a time window;
- incoming amount and transaction velocity;
- proportion of funds moving out quickly (synthetic flow-through ratio);
- number of hops / connections in synthetic transaction graph;
- recurrence of the same intermediary patterns;
- known synthetic reports or risk flags;
- account age and sudden activity change, where synthetic data provides it.

Output: `beneficiary_risk_score` from 0 to 100, reason codes, and `intelligence_source` (for MVP this must say `SYNTHETIC`).

Important: these indicators are not proof. Do not label a beneficiary “criminal” in the user interface. Use wording such as “recipient has risk indicators” or “recipient details need independent verification.”

## 5.4 Coercion Context Engine (CCE)

**Responsibility:** assess user-provided answers for indicators of social engineering or pressure.

Initial signals:
- urgency / “must pay now”;
- threat of arrest, legal action, account closure, or penalty;
- impersonation of police, bank, government, company, or family member;
- secrecy / instructed not to tell anyone;
- caller staying on the line or remotely guiding the payment;
- request to install an app, share screen, or follow step-by-step instructions (only if the user voluntarily reports it);
- false verification, KYC, prize, investment, job, or family-emergency story.

Output: `coercion_risk_score` from 0 to 100, reason codes, and answered-question summary. Never infer coercion from voice tone or demographic category alone.

## 5.5 Adaptive Question Selector (AQS)

**Responsibility:** ask the smallest number of useful questions to reduce uncertainty.

Rules:
- Ask only relevant questions based on current evidence.
- Maximum three questions in the MVP by default.
- Questions must be short, non-technical, and translated consistently.
- Provide “Yes”, “No”, “Not sure”, “Skip”, and “Need help” where appropriate.
- Do not interpret skip/refusal as a positive fraud label.
- Keep a simple deterministic decision tree for MVP; expected-information-gain selection can be a later research enhancement.

## 5.6 Risk Fusion & Decision Engine (RFDE)

**Responsibility:** combine engine outputs into one explainable risk assessment and recommended action.

Inputs:
- transaction anomaly score;
- beneficiary risk score;
- coercion risk score (may be absent before questionnaire);
- confidence/availability flags;
- relevant reason codes;
- policy thresholds/configuration.

Outputs:
- `overall_risk_score` (0–100 index for MVP; do not call it a real-world probability);
- `risk_level`: `LOW`, `MEDIUM`, or `HIGH`;
- `recommended_action`: `ALLOW`, `INFORM`, `VERIFY`, `SAFETY_PAUSE`, or `BANK_REVIEW`;
- `reason_codes` and human-readable explanations;
- whether follow-up questions are recommended.

MVP implementation:
1. Start with transparent rules or a simple baseline model.
2. Keep each component score separate.
3. Fit/tune a fusion model only using training data and evaluate on held-out customers/scenarios.
4. If using probabilities, calibrate them and label them correctly. Otherwise keep the output as a risk index.
5. Do not use arbitrary hand-picked weighted sums and then claim the result is a calibrated fraud probability.

The decision policy is separate from the model. A high score recommends an intervention; it does not itself execute a bank block.

## 5.7 Accessible Intervention Layer (AIL)

**Responsibility:** present the decision in a simple, localised, non-alarming way and let the customer make an informed next choice.

Must support:
- English, Telugu, and Hindi as initial language targets;
- large text and touch targets;
- high contrast and readable typography;
- short sentences and familiar vocabulary;
- audio playback of every warning/question;
- speech input where supported, with tap/typed fallback;
- icons paired with labels (never icons alone for critical actions);
- clear progress indicator for questions;
- persistent language switch;
- accessible “repeat audio” and “speak slower” controls where supported;
- no shame, blame, or accusatory wording.

## 5.8 Feedback & Evaluation Service (FES)

**Responsibility:** store anonymised/synthetic demo outcomes and provide data for evaluation.

Allowed outcomes:
- `CONFIRMED_SCAM`;
- `CONFIRMED_LEGITIMATE`;
- `UNRESOLVED`;
- `USER_CANCELLED`;
- `REFERRED_FOR_REVIEW`.

`USER_CANCELLED` is not automatically `CONFIRMED_SCAM`.

## 5.9 Admin / Analyst Dashboard (AAD)

**Responsibility:** show simulated risk events for the hackathon evaluator or demo analyst.

Display:
- event ID and timestamp;
- masked customer and beneficiary identifiers;
- amount and purpose;
- overall score/level/action;
- component scores;
- reason codes;
- questionnaire completion status;
- outcome/feedback status.

Do not display real customer personal information. For the prototype, all records are synthetic.

---

# 6. RISK MODEL AND DECISION DESIGN

## 6.1 Keep three risk dimensions separate

1. **Transaction anomaly:** how unusual is this payment for this customer?
2. **Beneficiary/mule risk:** how suspicious is the receiving account or its synthetic transaction network?
3. **Coercion context:** how much evidence suggests the payer is being manipulated?

Do not collapse these into one score before preserving the component outputs. Reasons should show which dimension caused the intervention.

## 6.2 Score semantics

All MVP component scores and overall score use the range `0` to `100`.

- `0` means no risk indicators detected by this prototype's available signals.
- `100` means the strongest risk evidence represented by the prototype's model/rules.
- Scores are not legal findings, proof of fraud, or automatically calibrated real-world probabilities.

Risk-level thresholds are configuration values and must be versioned. Initial demo defaults (not validated thresholds):
- LOW: 0–29
- MEDIUM: 30–64
- HIGH: 65–100

These thresholds are only for a demo baseline. Tune them on a validation set and report the resulting false-positive/false-negative trade-off.

## 6.3 Action policy

| Risk level / context | Suggested action | User experience |
|---|---|---|
| Low | `ALLOW` | Simple confirmation; do not interrupt unnecessarily |
| Medium | `INFORM` or `VERIFY` | Explain the specific reason; suggest verifying the recipient independently |
| High | `SAFETY_PAUSE` | Clearly recommend stopping and independently checking the situation |
| Severe indicators / policy referral | `BANK_REVIEW` | Demo shows referral state; actual bank action requires authorised bank policy |

Actions are recommendations for the simulator. Actual processing decisions in production belong to the authorised bank/payment provider under its controls and applicable requirements.

## 6.4 Explanation format

Machine reason codes are stable identifiers. User-facing messages are localised separately.

Initial reason codes:
- `NEW_BENEFICIARY`
- `AMOUNT_ABOVE_BASELINE`
- `UNUSUAL_PAYMENT_TIME`
- `HIGH_PAYMENT_VELOCITY`
- `BENEFICIARY_HIGH_INFLOW_DIVERSITY`
- `BENEFICIARY_RAPID_OUTFLOW`
- `BENEFICIARY_NETWORK_LINKS`
- `URGENCY_REPORTED`
- `AUTHORITY_THREAT_REPORTED`
- `SECRECY_REQUEST_REPORTED`
- `REMOTE_GUIDANCE_REPORTED`
- `IMPERSONATION_REPORTED`
- `INSUFFICIENT_CONTEXT`

Never generate a reason code that is not in the shared catalogue without updating this blueprint and API schema.

---

# 7. ADAPTIVE QUESTIONNAIRE

## 7.1 Design principles

- Do not show all questions to every customer.
- Ask one question at a time.
- Use one idea per sentence.
- Keep options large and simple.
- Use audio in the selected language.
- Offer “Not sure,” “Skip,” and “Need help.”
- Maximum three questions by default.
- Never assume the user is lying or that no answer means safety.

## 7.2 Canonical MVP question bank

| Question ID | English text | Intent / reason code |
|---|---|---|
| `Q_URGENCY` | Is someone asking you to send this money immediately? | urgency / `URGENCY_REPORTED` |
| `Q_THREAT` | Has anyone threatened to arrest you, fine you, or block your account if you do not pay? | threat / `AUTHORITY_THREAT_REPORTED` |
| `Q_SECRECY` | Has anyone told you not to tell your family, bank, or anyone else about this payment? | secrecy / `SECRECY_REQUEST_REPORTED` |
| `Q_GUIDANCE` | Is someone staying on a call or guiding you step by step while you make this payment? | remote guidance / `REMOTE_GUIDANCE_REPORTED` |
| `Q_IDENTITY` | Is the person claiming to be from the police, bank, government, or another organisation? | impersonation / `IMPERSONATION_REPORTED` |
| `Q_PURPOSE` | Do you personally know why this person needs the money? | context / `INSUFFICIENT_CONTEXT` when unclear |

Answers: `YES`, `NO`, `NOT_SURE`, `SKIP`, `NEED_HELP`.

## 7.3 Simple deterministic selection for MVP

- If amount is unusually high and beneficiary is new: ask `Q_URGENCY`.
- If user answers YES to urgency: ask `Q_THREAT`.
- If threat is YES: ask `Q_SECRECY`.
- If no threat but beneficiary risk is high: ask `Q_IDENTITY` or `Q_PURPOSE`.
- If there is already strong context, do not ask redundant questions. Stop when the policy can make a useful decision or when three questions have been asked.

The team may change the branching policy, but all clients must use the same question IDs and answer enums.

## 7.4 Translation requirements

Create a single translation catalogue, not separate translations invented by each frontend component. Store question IDs and translations in one file or service. Telugu and Hindi translations must be reviewed by fluent speakers. Maintain the same intent across translations; do not add extra claims or threats during translation.

---

# 8. DATA STRATEGY AND DATA DICTIONARY

## 8.1 Data policy

The hackathon prototype uses synthetic data only. Do not upload real bank statements, UPI IDs, phone numbers, PINs, OTPs, call recordings, contact lists, or private messages. Do not ask test participants to make real payments.

## 8.2 Required synthetic entities

### A. Customer profile

| Field | Type | Meaning |
|---|---|---|
| `customer_id` | string | Synthetic unique customer ID, e.g. `CUS_0001` |
| `preferred_language` | enum | `en`, `te`, `hi` |
| `profile_group` | enum | `SENIOR`, `GENERAL`, `LIMITED_LITERACY_TEST` (test persona only; not a fraud feature) |
| `baseline_txn_count_30d` | integer | Synthetic 30-day transaction count |
| `baseline_amount_median` | number | Median transaction amount |
| `baseline_amount_mad` | number | Median absolute deviation of amount |
| `usual_active_hours` | array | Synthetic hours of normal activity |

Never use age or literacy group as a fraud signal. These fields are for usability testing and language/accessibility defaults only.

### B. Beneficiary profile

| Field | Type | Meaning |
|---|---|---|
| `beneficiary_id` | string | Synthetic ID, e.g. `BEN_0101` |
| `account_age_days` | integer/null | Synthetic account age where available |
| `customer_counterparties_30d` | integer | Distinct incoming counterparties |
| `incoming_txn_count_24h` | integer | Incoming transactions in 24h |
| `incoming_amount_24h` | number | Total incoming amount in 24h |
| `outgoing_amount_24h` | number | Total outgoing amount in 24h |
| `flow_through_ratio` | number | Outgoing/incoming amount, bounded/handled safely |
| `network_degree` | integer | Synthetic number of graph connections |
| `synthetic_report_count` | integer | Simulated reports/flags |

### C. Payment event

| Field | Type | Meaning |
|---|---|---|
| `payment_id` | string | Unique simulated event ID |
| `customer_id` | string | Synthetic customer ID |
| `beneficiary_id` | string | Synthetic beneficiary ID |
| `amount` | number | Positive amount in INR |
| `currency` | string | `INR` for this prototype |
| `purpose` | string/null | User-selected short purpose |
| `created_at` | ISO 8601 timestamp | Time of simulated initiation |
| `is_new_beneficiary` | boolean | Whether recipient is new for this customer |
| `channel` | enum | `WEB_SIMULATOR` for MVP |

### D. Question answer

| Field | Type | Meaning |
|---|---|---|
| `question_id` | enum | One of the canonical `Q_*` IDs |
| `answer` | enum | `YES`, `NO`, `NOT_SURE`, `SKIP`, `NEED_HELP` |
| `answered_at` | ISO 8601 timestamp | Answer time |
| `input_mode` | enum | `TAP`, `VOICE`, `TEXT` |

Do not store raw audio in the MVP. Speech recognition should produce a transient answer that the user can confirm.

### E. Outcome label

| Field | Type | Meaning |
|---|---|---|
| `outcome` | enum | `CONFIRMED_SCAM`, `CONFIRMED_LEGITIMATE`, `UNRESOLVED`, `USER_CANCELLED`, `REFERRED_FOR_REVIEW` |
| `label_source` | enum | `SYNTHETIC_SCENARIO`, `DEMO_USER`, `REVIEWER` |

A customer cancelling a payment must not automatically label it as fraud.

## 8.3 Dataset generation

Create a labelled synthetic dataset with a first target of approximately 2,000 scenarios. Proposed scenario categories (adjustable during implementation):
- digital-arrest / authority impersonation;
- fake KYC / account-block threat;
- investment or high-return scam;
- family-emergency impersonation;
- other social-engineering pressure;
- legitimate everyday payments;
- legitimate unusual payments (medical, education, rent, business, emergency).

Include hard negatives: large legitimate payments, new legitimate beneficiaries, late-night payments, urgent legitimate transfers, and high transaction volume from a business profile. Do not encode a shortcut such as “every high-value payment is fraud” or “every senior customer is at risk.”

Split data by customer and scenario family, and preferably by generation time/seed, to reduce leakage. Never randomly split near-duplicate transactions from the same generated scam scenario into both train and test sets.

## 8.4 Dataset files

Canonical MVP files:
- `data/customers.csv`
- `data/beneficiaries.csv`
- `data/payments.csv`
- `data/scenario_labels.csv`
- `data/question_answers.csv` (can be generated during demo rather than stored in advance)

Store the generator seed and generation script in the repository.

## 8.5 Model targets

Keep labels distinct:
- `beneficiary_is_mule_like` — synthetic beneficiary-level label;
- `payment_is_scam_induced` — synthetic payment-level APP/social-engineering label;
- `coercion_present` — synthetic scenario-level context label.

Do not train one ambiguous “fraud” label that mixes mule-account status, payment scam status, and customer behaviour.

---

# 9. MODEL DEVELOPMENT AND EVALUATION

## 9.1 MVP model sequence

Build in this order:

1. Rule-based baseline for transparent behaviour and beneficiary features.
2. Logistic Regression baseline for a simple, interpretable classifier.
3. Random Forest or XGBoost comparison if the dataset and time support it.
4. Calibration and threshold tuning using validation data.
5. Explainability through reason codes; SHAP can be used for offline analysis, not as a substitute for clear customer wording.

The product must work even if a trained model is unavailable: deterministic baseline rules should provide a working demo.

## 9.2 Ablation comparison

Evaluate at least three systems on the same held-out test cases:
- **Model A:** transaction behaviour only (`TBE`).
- **Model B:** transaction behaviour + beneficiary/mule risk (`TBE + BRE`).
- **Model C:** transaction behaviour + beneficiary/mule risk + coercion context (`TBE + BRE + CCE`).

This tests whether payer-side context adds value to the combined approach. It does not prove superiority over proprietary commercial systems.

## 9.3 Metrics

Report actual measured results, not invented targets:
- precision;
- recall;
- F1 (with caution about class imbalance);
- PR-AUC;
- false-positive rate;
- false-negative rate;
- confusion matrix;
- calibration/Brier score if probabilities are produced;
- p50 and p95 scoring latency;
- average questions per payment;
- questionnaire completion/skip rate;
- user comprehension and safe-decision rate in fictional usability scenarios.

For imbalanced fraud data, PR-AUC and false-positive burden are particularly important. Report class balance and the threshold used.

## 9.4 Usability evaluation

Use fictional scenarios only. Compare:
- Group A: generic technical warning;
- Group B: StreamShield plain-language, regional-language/voice-supported warning.

Measure comprehension, ability to identify the scam tactic, confidence in next steps, time taken, and whether the participant understands how to independently verify the request. Do not use real money or induce actual scam calls.

## 9.5 Performance and scale

For the hackathon, measure local/API response latency and test a batch of simulated requests. Do not claim UPI-scale throughput based on a laptop demo. Kafka/Flink/distributed processing is a future architecture option, not an MVP requirement.

---

# 10. USER EXPERIENCE AND ACCESSIBILITY SPECIFICATION

## 10.1 Mandatory principles

1. Mobile-first layout.
2. One primary task per screen.
3. Large buttons and touch targets (target at least 44 x 44 CSS pixels).
4. Strong text/background contrast.
5. Plain-language sentences; avoid jargon.
6. Do not rely on colour alone to express risk.
7. Every critical icon must have a text label.
8. Persistent language selector.
9. Audio playback for questions and important warnings.
10. Tap/typed fallback for speech failures.
11. Clear “Back,” “Repeat,” “Skip,” and “Need help” controls where appropriate.
12. Do not shame or blame the customer.
13. Do not create panic with unsupported statements such as “Your money is definitely being stolen.”
14. Do not force disclosure of sensitive details.

## 10.2 Language priority

Initial prototype: English, Telugu, Hindi. Add other Indian languages after the core flow is stable.

Use a central translation catalogue with stable keys. Example structure:

```json
{
  "payment.warning.title": {
    "en": "Please pause and check",
    "te": "దయచేసి ఒక్క క్షణం ఆగి పరిశీలించండి",
    "hi": "कृपया रुकें और जाँच करें"
  }
}
```

The above is an illustrative format; all production translations must be reviewed by fluent speakers.

## 10.3 Example user-facing copy

LOW:
- EN: “No major warning signs were found. Check the recipient name before continuing.”
- TE/HI: translate the same meaning, not a stronger claim.

MEDIUM:
- EN: “This payment is different from your usual activity. Do you know and trust this person?”

HIGH:
- EN: “Someone may be pressuring you to send this money. Please pause. Do not rely on a phone call or message to verify the request.”

Trusted verification guidance:
- “End the call if you feel safe doing so. Contact your bank using the number shown on your bank card or official app. You may also speak to someone you trust.”

Avoid putting the trusted contact in control of the user's account or PIN. Never ask the user to share a UPI PIN, OTP, password, or card details with anyone, including StreamShield.

## 10.4 Voice design

- Text-to-speech reads the visible question/warning.
- Speech-to-text can map the user's spoken response to a permitted answer enum.
- Always show the recognised answer and ask for confirmation when confidence is low.
- Provide tap options as an equal alternative.
- Do not store raw audio in MVP.
- Do not infer fraud from accent, fluency, hesitation, pitch, or emotional tone.
- If browser speech support is unavailable, the app remains fully usable through text and buttons.

---

# 11. SYSTEM ARCHITECTURE

## 11.1 Recommended MVP architecture

```text
[React + Vite Mobile-First Frontend]
          |
          | HTTPS JSON API
          v
[FastAPI Backend]
          |
          +--> [Payment Session Service]
          |
          +--> [Transaction Behaviour Engine - TBE]
          |
          +--> [Beneficiary Risk Engine - BRE]
          |
          +--> [Coercion Context Engine - CCE]
          |          |
          |          +--> [Adaptive Question Selector - AQS]
          |
          +--> [Risk Fusion & Decision Engine - RFDE]
          |
          +--> [Accessible Content / Translation Catalogue]
          |
          +--> [Feedback & Evaluation Service - FES]
          |
          +--> [Admin / Analyst Dashboard API]
          |
          v
[PostgreSQL]
  customers | beneficiaries | payments | assessments
  questions | answers | feedback | audit_events

[Offline Python Pipeline]
  synthetic data generator -> training/evaluation -> model artefacts
```

## 11.2 Technology choices

- Frontend: React + Vite + TypeScript preferred. JavaScript is acceptable if the team is faster with it, but do not mix JS and TS conventions across components.
- Backend: Python + FastAPI.
- Database: PostgreSQL. SQLite is acceptable for a very early local prototype if all contributors agree; PostgreSQL is the integration target.
- ML: pandas, NumPy, scikit-learn; XGBoost optional.
- Graph features: NetworkX for synthetic beneficiary networks; do not introduce a graph database for MVP.
- Visualisations: a simple React chart/table library chosen once by the frontend lead.
- API schema: FastAPI OpenAPI is the source of truth; optionally commit a generated `openapi.json` snapshot.
- Deployment: Docker Compose optional; local development must be documented first.

## 11.3 Architecture constraints

- Backend owns all risk scoring and decision logic. Frontend must not reimplement risk calculations.
- Frontend owns presentation and interaction state only.
- Model code must be callable through stable Python functions and must not depend on HTTP request objects.
- Database IDs and API IDs use strings/UUIDs consistently.
- All timestamps are ISO 8601 with timezone; backend stores UTC.
- Currency is `INR`; amounts are numeric and positive.
- The payment is simulated, explicitly marked as such in UI and API.

---

# 12. API CONTRACT — SHARED SOURCE OF TRUTH

All contributors must use these route names, request fields, response fields, and enum values. If a change is necessary, update the OpenAPI schema and this document together before implementing separately.

Base path: `/api/v1`  
Content type: `application/json`  
All IDs: strings (UUIDs recommended).  
All timestamps: ISO 8601 UTC strings, e.g. `2026-11-12T08:30:00Z`.

## 12.1 `POST /api/v1/payments/initiate`

Creates a simulated payment session and performs an initial risk assessment.

Request:

```json
{
  "customer_id": "CUS_0001",
  "beneficiary_id": "BEN_0101",
  "amount": 75000.0,
  "currency": "INR",
  "purpose": "Other",
  "language": "te",
  "channel": "WEB_SIMULATOR"
}
```

Response:

```json
{
  "payment_id": "PAY_000001",
  "status": "ASSESSMENT_PENDING_CONTEXT",
  "is_simulated": true,
  "initial_assessment": {
    "overall_risk_score": 48,
    "risk_level": "MEDIUM",
    "recommended_action": "VERIFY",
    "component_scores": {
      "transaction_anomaly_score": 62,
      "beneficiary_risk_score": 28,
      "coercion_risk_score": null
    },
    "reason_codes": ["NEW_BENEFICIARY", "AMOUNT_ABOVE_BASELINE"],
    "requires_questions": true
  },
  "next_question": {
    "question_id": "Q_URGENCY",
    "text": "Is someone asking you to send this money immediately?",
    "answer_options": ["YES", "NO", "NOT_SURE", "SKIP", "NEED_HELP"],
    "audio_available": true
  }
}
```

`overall_risk_score` is an illustrative demo score. It is not a real-world fraud probability.

## 12.2 `POST /api/v1/payments/{payment_id}/answers`

Submits one answer and returns either the next question or a final assessment.

Request:

```json
{
  "question_id": "Q_URGENCY",
  "answer": "YES",
  "input_mode": "TAP"
}
```

Response when another question is needed:

```json
{
  "payment_id": "PAY_000001",
  "questionnaire_status": "IN_PROGRESS",
  "questions_answered": 1,
  "max_questions": 3,
  "next_question": {
    "question_id": "Q_THREAT",
    "text": "Has anyone threatened to arrest you, fine you, or block your account if you do not pay?",
    "answer_options": ["YES", "NO", "NOT_SURE", "SKIP", "NEED_HELP"],
    "audio_available": true
  }
}
```

Response when questionnaire is complete:

```json
{
  "payment_id": "PAY_000001",
  "questionnaire_status": "COMPLETED",
  "questions_answered": 2,
  "final_assessment": {
    "overall_risk_score": 91,
    "risk_level": "HIGH",
    "recommended_action": "SAFETY_PAUSE",
    "component_scores": {
      "transaction_anomaly_score": 62,
      "beneficiary_risk_score": 28,
      "coercion_risk_score": 96
    },
    "reason_codes": ["NEW_BENEFICIARY", "AMOUNT_ABOVE_BASELINE", "URGENCY_REPORTED", "AUTHORITY_THREAT_REPORTED"],
    "explanations": [
      "The payment is different from this customer's usual activity.",
      "The customer reported urgency and a threat connected to the payment."
    ],
    "is_simulated": true
  }
}
```

## 12.3 `GET /api/v1/payments/{payment_id}`

Returns the payment session, current status, selected language, and latest assessment. Do not return unnecessary private fields.

## 12.4 `POST /api/v1/payments/{payment_id}/decision`

Records the user's demo decision after seeing the recommendation.

Request:

```json
{
  "customer_choice": "PAUSE_AND_VERIFY"
}
```

Allowed `customer_choice` values:
- `CONTINUE_SIMULATED`;
- `PAUSE_AND_VERIFY`;
- `CANCEL_SIMULATED`;
- `REQUEST_BANK_REVIEW`.

Response:

```json
{
  "payment_id": "PAY_000001",
  "status": "SIMULATION_PAUSED",
  "is_simulated": true,
  "message_key": "decision.pause_confirmed"
}
```

The endpoint only updates simulator state. It must never initiate a real transfer.

## 12.5 `POST /api/v1/feedback`

Request:

```json
{
  "payment_id": "PAY_000001",
  "outcome": "UNRESOLVED",
  "label_source": "DEMO_USER",
  "notes": "Optional short note"
}
```

Response:

```json
{
  "feedback_id": "FDB_000001",
  "saved": true
}
```

## 12.6 `GET /api/v1/admin/alerts`

Returns paginated synthetic risk events. Query parameters may include `risk_level`, `recommended_action`, `limit`, and `offset`.

## 12.7 `GET /api/v1/admin/metrics`

Returns aggregate demo metrics such as count by risk level, count by action, feedback outcome counts, and average scoring latency. Do not expose raw customer details in aggregate endpoints.

## 12.8 Standard error format

```json
{
  "error": {
    "code": "INVALID_ANSWER",
    "message": "The answer value is not supported.",
    "details": {}
  }
}
```

Use HTTP status codes consistently: 400 invalid input, 404 unknown payment/customer/beneficiary, 422 schema validation error, 500 unexpected server error. Do not leak stack traces to the frontend.

---

# 13. CANONICAL ENUMS AND SHARED TYPES

Do not invent synonyms for these enums in different modules.

```text
Language:
  en | te | hi

RiskLevel:
  LOW | MEDIUM | HIGH

RecommendedAction:
  ALLOW | INFORM | VERIFY | SAFETY_PAUSE | BANK_REVIEW

PaymentStatus:
  ASSESSMENT_PENDING_CONTEXT
  QUESTIONNAIRE_IN_PROGRESS
  ASSESSMENT_COMPLETE
  SIMULATION_CONTINUED
  SIMULATION_PAUSED
  SIMULATION_CANCELLED
  REFERRED_FOR_REVIEW

QuestionAnswer:
  YES | NO | NOT_SURE | SKIP | NEED_HELP

InputMode:
  TAP | VOICE | TEXT

CustomerChoice:
  CONTINUE_SIMULATED
  PAUSE_AND_VERIFY
  CANCEL_SIMULATED
  REQUEST_BANK_REVIEW

FeedbackOutcome:
  CONFIRMED_SCAM
  CONFIRMED_LEGITIMATE
  UNRESOLVED
  USER_CANCELLED
  REFERRED_FOR_REVIEW

FeedbackLabelSource:
  SYNTHETIC_SCENARIO | DEMO_USER | REVIEWER
```

---

# 14. DATABASE DESIGN — MVP TABLES

Recommended tables:

1. `customers` — synthetic customer profile and baselines.
2. `beneficiaries` — synthetic recipient profile and features.
3. `payments` — simulated payment events and status.
4. `assessments` — initial/final scores, risk level, action, reasons, model version.
5. `questions` — canonical question IDs and translation keys (or translations in JSON/catalogue).
6. `answers` — answer enum, input mode, timestamp; no raw audio.
7. `feedback` — outcome and label source.
8. `audit_events` — important state transitions, without secrets or raw private content.

Minimum assessment fields:
- `assessment_id`;
- `payment_id`;
- `stage` (`INITIAL` or `FINAL`);
- three component scores;
- overall score;
- risk level;
- recommended action;
- reason codes (JSON array or related table);
- model/rules version;
- created timestamp.

Store money using a fixed-precision decimal type in PostgreSQL, not floating point, for persistence. API examples use JSON numbers for readability.

---

# 15. REPOSITORY STRUCTURE

Use this structure unless the team agrees to a documented change before coding:

```text
streamshield/
  README.md
  MASTER_BLUEPRINT.md
  .env.example
  .gitignore
  docker-compose.yml                 # optional for MVP

  frontend/
    package.json
    src/
      app/
      pages/
        PaymentPage.tsx
        ProtectionPage.tsx
        AdminDashboardPage.tsx
      components/
        PaymentForm.tsx
        LanguageSelector.tsx
        VoiceControls.tsx
        RiskBanner.tsx
        QuestionCard.tsx
        DecisionPanel.tsx
        ScoreBreakdown.tsx
      services/
        apiClient.ts
        paymentService.ts
      i18n/
        messages.ts
      types/
        api.ts

  backend/
    app/
      main.py
      api/
        payments.py
        feedback.py
        admin.py
      schemas/
        payment.py
        assessment.py
        feedback.py
      services/
        payment_service.py
        assessment_service.py
        question_service.py
        feedback_service.py
      engines/
        transaction_behaviour.py
        beneficiary_risk.py
        coercion_context.py
        adaptive_questions.py
        risk_fusion.py
      models/
        model_loader.py
      repositories/
      db/
        database.py
        models.py
      config.py

  ml/
    data_generator.py
    feature_engineering.py
    train_transaction_model.py
    train_beneficiary_model.py
    train_fusion_model.py
    evaluate.py
    artifacts/

  data/
    customers.csv
    beneficiaries.csv
    payments.csv
    scenario_labels.csv

  tests/
    backend/
    frontend/
    ml/
    integration/

  docs/
    API_CONTRACT.md
    DATA_DICTIONARY.md
    MODEL_CARD.md
    DEMO_SCRIPT.md
```

If using JavaScript instead of TypeScript, change file extensions consistently; do not mix type conventions casually.

---

# 16. TEAM DIVISION AND INTEGRATION CONTRACT

Recommended roles for a 4–5 person team. If the team is smaller, combine roles without changing interfaces.

## Role 1 — Frontend and accessibility

Owns:
- payment simulator screens;
- language selector;
- question flow UI;
- audio and speech interaction;
- risk explanation and decision screens;
- admin dashboard UI;
- frontend tests.

Must not:
- calculate risk scores;
- create a second copy of the backend decision rules;
- rename API fields to suit the UI;
- hardcode demo outcomes as if they were model responses.

Deliverables:
- working React app;
- API client based on the contract;
- responsive screenshots/demo flow;
- keyboard and large-touch usability check.

## Role 2 — Backend and API/database

Owns:
- FastAPI app;
- request/response schemas;
- API routes;
- database tables/repositories;
- payment session state;
- integration of all engines;
- error handling and OpenAPI.

Must not:
- implement ML logic directly inside route functions;
- create a new unreviewed API shape;
- allow real payment execution.

Deliverables:
- running API;
- OpenAPI docs;
- database setup/seed instructions;
- integration tests.

## Role 3 — Transaction and beneficiary risk / graph features

Owns:
- synthetic feature definitions;
- TBE and BRE implementation;
- synthetic beneficiary network generator;
- baseline and model evaluation for these dimensions;
- reason code output.

Must not:
- use customer age/literacy as fraud predictors;
- treat one feature as proof of mule activity;
- access real financial data.

Deliverables:
- callable engine functions;
- feature documentation;
- test fixtures;
- evaluation report.

## Role 4 — Coercion context / adaptive questions / language content

Owns:
- canonical question bank;
- CCE scoring;
- AQS branching logic;
- English/Telugu/Hindi translation catalogue;
- plain-language warning copy;
- content review with fluent speakers.

Must not:
- infer fraud from accent or voice emotion;
- label a skipped answer as fraud;
- exceed the agreed question limit without approval;
- invent different question IDs in frontend/backend.

Deliverables:
- question catalogue;
- engine functions;
- branching tests;
- translation file and review status.

## Role 5 — Integration, testing, product research (if available)

Owns:
- acceptance criteria;
- end-to-end scenarios;
- API contract consistency;
- integration test fixtures;
- RBI/competitor fact-checking;
- demo script and pitch;
- final report of limitations and measured results.

Must not:
- claim live bank/RBI integration;
- claim performance not measured;
- alter core product scope without team agreement.

## 16.1 Integration order

1. Agree on this blueprint and repository structure.
2. Backend publishes the initial OpenAPI schema and mock endpoints.
3. Frontend integrates against mock responses using exact field names.
4. ML contributors implement engine function signatures and test fixtures.
5. Backend connects real engine functions to the services.
6. Team runs the same end-to-end scenarios.
7. Only after end-to-end stability, polish visuals and add optional features.

## 16.2 Engine function signatures

Use stable interfaces similar to:

```python
def score_transaction(payment: PaymentInput, customer: CustomerProfile) -> ComponentRisk:
    ...

def score_beneficiary(beneficiary: BeneficiaryProfile, network_features: dict) -> ComponentRisk:
    ...

def score_coercion(answers: list[QuestionAnswerInput]) -> ComponentRisk:
    ...

def select_next_question(context: QuestionContext) -> Question | None:
    ...

def fuse_risk(inputs: RiskFusionInput) -> RiskAssessment:
    ...
```

The backend lead owns the final Python models/schemas. Contributors must not invent incompatible parameter or return structures.

---

# 17. SHARED DEVELOPMENT RULES

1. **One source of truth:** this blueprint and the backend OpenAPI schema.
2. **API-first:** agree on request/response shapes before separate implementation.
3. **No hidden assumptions:** document any added field, dependency, or behaviour.
4. **No duplicate business logic:** backend owns scoring and action decisions.
5. **No inconsistent names:** use canonical module names, field names, IDs, enums, and reason codes.
6. **No direct main-branch pushes:** use feature branches and pull requests/peer review.
7. **Small commits:** one feature/fix per commit with clear messages.
8. **Environment variables:** secrets and configuration are not hardcoded. Commit `.env.example`, not `.env`.
9. **Deterministic demo:** seed synthetic data so all teammates and judges can reproduce the same scenarios.
10. **Mock first:** frontend can develop with mock JSON before ML is ready.
11. **Fail safely:** if a model/service is unavailable, show a safe generic message or a clearly labelled fallback; never silently claim “low risk.”
12. **Version models and thresholds:** include `model_version` and `policy_version` in assessment records.
13. **Document changes:** any approved deviation is recorded in `CHANGELOG.md` and reflected in the API schema.

---

# 18. ACCEPTANCE CRITERIA — WHAT COUNTS AS DONE

## 18.1 End-to-end acceptance

- [ ] User can select a synthetic customer profile.
- [ ] User can select English, Telugu, or Hindi.
- [ ] User can enter a beneficiary, positive INR amount, and payment purpose.
- [ ] Frontend calls `POST /api/v1/payments/initiate`.
- [ ] Backend returns an assessment with the exact shared schema.
- [ ] If needed, the UI asks no more than three adaptive questions by default.
- [ ] Answers are submitted using canonical question IDs and answer enums.
- [ ] Final assessment includes separate TBE, BRE, and CCE component scores.
- [ ] Overall score, risk level, action, and reason codes are returned.
- [ ] UI explains the recommendation in plain language.
- [ ] Audio warning/question playback works where supported; text/tap fallback always works.
- [ ] User can pause, continue the simulation, cancel, or request demo review.
- [ ] No real payment can be initiated.
- [ ] Admin dashboard displays the simulated event and its reasons.
- [ ] Feedback can be saved without treating cancellation as fraud.
- [ ] Tests cover LOW, MEDIUM, HIGH, legitimate-unusual-payment, skipped-answer, and missing-data cases.

## 18.2 Accessibility acceptance

- [ ] Primary action buttons are large and clearly labelled.
- [ ] Critical information is not conveyed by colour alone.
- [ ] No critical instruction requires English.
- [ ] A user can replay audio.
- [ ] User can proceed without microphone permission.
- [ ] The interface does not require typing long explanations.
- [ ] Text is readable on a typical mobile screen.
- [ ] Screen reader labels exist for important controls.

## 18.3 Model/evaluation acceptance

- [ ] Synthetic dataset generation is reproducible.
- [ ] Train/validation/test split avoids scenario/customer leakage.
- [ ] Class balance and feature-generation assumptions are documented.
- [ ] Baseline metrics and confusion matrix are reported.
- [ ] A/B/C ablation comparison is performed if all engines are ready.
- [ ] False-positive cost and question burden are discussed.
- [ ] No unmeasured performance claim appears in the pitch.

---

# 19. DEMONSTRATION PLAN

A good 3–4 minute demo should tell one clear story.

## Demo scenario 1 — Legitimate payment

- Select a general synthetic customer.
- Pay a familiar recipient a normal amount.
- Show LOW risk and a fast, low-friction continuation.

## Demo scenario 2 — Fake digital-arrest scam

- Select a senior-citizen test persona with Telugu language preference. The persona is only for interface demonstration, not for risk scoring.
- Enter a large payment to a new recipient.
- Initial engine flags an unusual payment and recipient information.
- UI asks in Telugu whether someone is demanding immediate payment.
- User answers YES; next question asks about threats.
- User answers YES.
- CCE score rises; RFDE returns HIGH / `SAFETY_PAUSE`.
- UI speaks a plain-language warning and offers a safe next step.
- Demonstrate “Pause and verify”; no money is moved.

## Demo scenario 3 — Unusual but legitimate payment

- Enter a high-value payment to a trusted/known beneficiary.
- Show that unusual amount alone does not automatically mean fraud.
- Show a proportionate verification or informational response.

## Demo scenario 4 — Analyst view

- Open dashboard.
- Show the simulated event, component scores, reason codes, and recorded outcome.
- Explain that the scores are prototype outputs from synthetic data.

---

# 20. PRIVACY, SAFETY, AND TRUST REQUIREMENTS

- No real UPI PIN, OTP, password, card number, or bank login is ever requested.
- No real payments are processed.
- No covert microphone, call, SMS, screen, or contact monitoring.
- No raw voice recording is stored in MVP.
- No user is called a criminal or fraudster based on a model score.
- No demographic characteristic (age, literacy, language, disability) is used as a fraud predictor.
- A skipped question is not a fraud label.
- A cancelled payment is not a confirmed scam label.
- Explain the reason for a warning and offer a practical, independent verification step.
- Minimise data collection and define retention/deletion for any demo records.
- In a real deployment, require consent and appropriate legal basis, security review, access controls, auditability, model governance, human review, and bank/regulatory approval.
- Do not share sensitive transaction data with a trusted contact without explicit user consent and a carefully designed authorisation flow.

---

# 21. RISKS AND MITIGATIONS

| Risk | Mitigation |
|---|---|
| Too many false alarms | Tune thresholds; add legitimate hard negatives; track false-positive rate |
| User ignores warning | Plain language, relevant explanations, audio, short intervention |
| Scammer coaches victim to answer “No” | Never rely on questionnaire alone; combine with beneficiary and behaviour signals |
| Speech recognition misunderstands language | Confirm recognised answer; provide tap fallback; do not score recognition errors as fraud |
| Language translation changes meaning | Central catalogue and fluent-speaker review |
| Synthetic data produces unrealistic results | Disclose limitations; vary scenarios; avoid performance claims beyond test set |
| Frontend/backend mismatch | API-first contract, OpenAPI, shared enums, integration tests |
| Team builds incompatible modules | Canonical module names, data dictionary, engine signatures, common AI prompt |
| Judges ask about RBI/competitors | Explain complementarity; do not claim RBI lacks mule detection or DPIP is live if not verified |
| High-risk result leads to unfair denial | Separate risk scoring from decision policy; bank review and proportional interventions |

---

# 22. DEVELOPMENT PHASES

## Phase 1 — Contract and skeleton
- Freeze this blueprint.
- Create repository and folder structure.
- Backend defines schemas and mock routes.
- Frontend builds screens against mock JSON.
- Agree on sample scenarios and enums.

## Phase 2 — Working payment flow
- Implement payment initiation and state management.
- Add synthetic customers and beneficiaries.
- Add TBE and simple BRE baseline.
- Return initial assessment.

## Phase 3 — Coercion and accessibility
- Implement canonical question bank and AQS.
- Implement CCE.
- Add English/Telugu/Hindi content catalogue.
- Add audio playback and voice input with safe fallbacks.

## Phase 4 — Fusion and admin
- Implement RFDE.
- Implement intervention states.
- Integrate dashboard and feedback.
- Add event/audit records.

## Phase 5 — Evaluation and polish
- Generate held-out data.
- Run baseline and ablation experiments.
- Measure latency and user comprehension.
- Fix false positives and accessibility issues.
- Rehearse demo and prepare limitations slide.

Do not add optional technologies before the end-to-end path works.

---

# 23. SHARED AI PROMPT — COPY THIS INTO EVERY AI TOOL

The following prompt should be included whenever a different AI is asked to build one part of StreamShield. Then append only the specific task for that AI.

```text
You are contributing to StreamShield. Treat the supplied STREAMSHIELD MASTER PROJECT BLUEPRINT as the canonical source of truth. Do not redesign the product or invent new APIs, field names, enum values, module names, reason codes, or user journeys.

PRODUCT:
StreamShield is a proposed, bank-integrated real-time payment-protection layer. It combines (1) payer transaction-behaviour analysis, (2) beneficiary/mule-risk intelligence, and (3) user-provided social-engineering/coercion context. It then gives accessible, proportionate intervention before a simulated payment is completed.

CORE QUESTION:
Do not only ask “Is the receiving account suspicious?” Also ask “Could the person sending this money be manipulated?”

MVP ONLY:
Build a simulated UPI-like web demo using synthetic data. Never connect to real UPI, banks, RBI, DPIP, or live customer data. Never initiate, block, hold, reverse, or move real money. Do not claim real-world fraud accuracy or production scale.

CANONICAL MODULES:
- PS: Payment Simulator
- TBE: Transaction Behaviour Engine
- BRE: Beneficiary Risk Engine
- CCE: Coercion Context Engine
- AQS: Adaptive Question Selector
- RFDE: Risk Fusion & Decision Engine
- AIL: Accessible Intervention Layer
- FES: Feedback & Evaluation Service
- AAD: Admin / Analyst Dashboard

ACCESSIBILITY:
Target senior citizens and users with limited digital/English literacy, while remaining useful to everyone. Initial languages: English (en), Telugu (te), Hindi (hi). Use plain language, large controls, audio playback, speech input where supported, and tap/text fallback. Never require microphone permission. Never rely on colour alone. Never use age, literacy, accent, or voice emotion as fraud predictors.

RISK DIMENSIONS:
Keep three component scores separately: transaction_anomaly_score, beneficiary_risk_score, coercion_risk_score. MVP scores are 0–100 risk indices, not calibrated real-world probabilities. RFDE returns overall_risk_score, risk_level (LOW|MEDIUM|HIGH), recommended_action (ALLOW|INFORM|VERIFY|SAFETY_PAUSE|BANK_REVIEW), and reason_codes.

CANONICAL QUESTION IDS:
Q_URGENCY, Q_THREAT, Q_SECRECY, Q_GUIDANCE, Q_IDENTITY, Q_PURPOSE.
Answers: YES, NO, NOT_SURE, SKIP, NEED_HELP. Maximum three questions by default. Skipping or refusing to answer is not proof of fraud.

CANONICAL REASON CODES:
NEW_BENEFICIARY, AMOUNT_ABOVE_BASELINE, UNUSUAL_PAYMENT_TIME, HIGH_PAYMENT_VELOCITY, BENEFICIARY_HIGH_INFLOW_DIVERSITY, BENEFICIARY_RAPID_OUTFLOW, BENEFICIARY_NETWORK_LINKS, URGENCY_REPORTED, AUTHORITY_THREAT_REPORTED, SECRECY_REQUEST_REPORTED, REMOTE_GUIDANCE_REPORTED, IMPERSONATION_REPORTED, INSUFFICIENT_CONTEXT.

API:
Base path is /api/v1. Use the exact routes and request/response shapes in the blueprint:
POST /payments/initiate
POST /payments/{payment_id}/answers
GET /payments/{payment_id}
POST /payments/{payment_id}/decision
POST /feedback
GET /admin/alerts
GET /admin/metrics
Backend owns risk scoring and decisions. Frontend must not duplicate risk logic.

TECH STACK:
Frontend React + Vite (TypeScript preferred); backend Python + FastAPI; PostgreSQL; pandas/NumPy/scikit-learn; NetworkX for synthetic graph features. Keep the MVP simple. Kafka/Flink, graph databases, real integrations, call monitoring, SMS scraping, and live payment interception are out of scope.

QUALITY RULES:
1. Before coding, state which blueprint section and module your task belongs to.
2. Use exact shared field names, enums, API routes, IDs, and reason codes.
3. Do not modify files owned by another role unless explicitly asked.
4. If an interface is missing, propose the smallest compatible extension and wait for approval rather than silently inventing one.
5. Include type definitions, error handling, comments for non-obvious logic, and tests.
6. Include exact file paths and setup/run commands.
7. Explain dependencies and integration assumptions.
8. Do not hardcode fake model results as if they were genuine model outputs.
9. Clearly label synthetic/demo data and simulated payment behaviour.
10. Report completed files, interfaces used, tests run, and remaining gaps.

Now complete only this task:
[PASTE THE ASSIGNED TASK HERE]
```

---

# 24. TASK-SPECIFIC AI HANDOFF TEMPLATE

Use this after the shared AI prompt:

```text
ROLE: [Frontend / Backend / TBE+BRE / CCE+AQS / Integration+Testing]

ASSIGNED MODULES:
[Exact canonical module names]

FILES YOU MAY CREATE OR EDIT:
[List exact paths. Do not edit other paths without approval.]

INPUT CONTRACT:
[Exact schema/function/API inputs from the blueprint]

OUTPUT CONTRACT:
[Exact schema/function/API outputs from the blueprint]

DEPENDENCIES:
[What is already implemented or will be mocked]

ACCEPTANCE TESTS:
[List observable behaviours and tests]

DO NOT:
[List any role-specific forbidden changes]

Return:
1. Implementation summary.
2. Files created/modified.
3. Exact run commands.
4. Tests and results.
5. API/type assumptions.
6. Known limitations.
7. Integration steps for the next teammate.
```

---

# 25. JUDGE-FACING POSITIONING AND PITCH

## 25.1 Accurate RBI comparison

RBI's MuleHunter.ai uses behavioural and transactional features to assign a confidence score to bank accounts for potential mule activity. RBI's Annual Report 2025–26 reported implementation in 26 banks as of 31 March 2026. RBI is also pursuing DPIP for broader digital-payment fraud intelligence and information sharing; RBI's 2026–27 agenda describes full-scale implementation as being explored.

StreamShield does not claim to replace either initiative. Our prototype adds a customer-facing, payer-context protection flow to a combined beneficiary and transaction-risk assessment. It uses synthetic intelligence in the demo and is designed to be integration-compatible in principle, subject to authorisation.

## 25.2 One-minute pitch

“India's digital payments ecosystem has already made important progress in detecting mule accounts. The Reserve Bank's MuleHunter.ai uses behavioural and transactional patterns to identify bank accounts that may be acting as money mules and provide banks with a confidence score. RBI is also working towards broader payment-fraud intelligence through DPIP.

But consider a different part of the problem: a senior citizen receives a call from someone impersonating a police officer. The caller threatens arrest and pressures the person to transfer ₹75,000. The victim uses their own phone and authorises the payment. The payment may look technically valid even though the person is being manipulated.

StreamShield is our proposed additional protection layer. We combine transaction-behaviour analysis, beneficiary/mule-risk intelligence, and simple questions about urgency, threats, secrecy, and impersonation. The system estimates risk and recommends a proportionate response before the simulated payment is completed.

We are designing it for everyone, especially senior citizens and people who may not read English comfortably. They can receive clear warnings in Telugu, Hindi, or English, listen to the instructions, and respond through simple buttons or voice.

Our goal is to complement existing fraud-intelligence systems by asking two questions together: is the recipient risky, and could the person sending the money be under manipulation? StreamShield aims to make digital payments safer and more understandable for ordinary people.”

## 25.3 Claims we may make

- “We propose a combined beneficiary-risk and victim-context protection layer.”
- “Our MVP simulates transaction and beneficiary risk using synthetic data.”
- “We evaluate the value of adding coercion context through ablation tests.”
- “We design for regional-language and voice-assisted accessibility.”
- “We intend to complement authorised bank/payment-provider fraud controls.”

## 25.4 Claims we must not make without evidence

- “RBI cannot detect APP scams.”
- “RBI only uses rule-based mule detection.”
- “We are connected to MuleHunter.ai or DPIP.”
- “We have deployed in banks.”
- “We beat DeepID/Darwinium/Outseer/MuleHunter.ai.”
- “Our system has 99% accuracy” unless a reproducible evaluation genuinely demonstrates it on a clearly described test set.
- “The score is the probability the user is being scammed” unless the model has been properly calibrated and validated for that interpretation.

---

# 26. GLOSSARY

- **APP fraud:** authorised push payment fraud; a victim is manipulated into authorising a payment to a fraudster.
- **Money mule:** an account/person used to receive, move, or launder proceeds of crime; account involvement may vary and a risk flag is not proof of intent.
- **Mule ring:** a network of accounts participating in or facilitating suspicious fund flows.
- **Beneficiary:** person/account receiving the payment.
- **Payer:** person initiating the payment.
- **Coercion/social engineering:** manipulation through threats, urgency, impersonation, secrecy, or deceptive persuasion.
- **Risk score:** model/rule output indicating relative risk; not automatically a probability or finding of wrongdoing.
- **Reason code:** stable machine-readable explanation identifier.
- **Ablation study:** comparison of models with and without selected feature groups to assess their contribution.
- **Synthetic data:** artificially generated data that does not represent real customer accounts or actual bank activity.

---

# 27. OFFICIAL REFERENCE LINKS

Use these links for current fact-checking before presentations. Regulatory/product status can change; re-check official publications close to submission.

1. RBI Annual Report 2025–26 — MuleHunter.ai implementation and account confidence scoring:  
   https://rbi.org.in/scripts/AnnualReportPublications.aspx?Id=1466
2. RBI Annual Report 2025–26 / Payments Vision 2028 discussion — DPIP and 2026–27 implementation agenda:  
   https://www.rbi.org.in/Scripts/AnnualReportPublications.aspx?Id=1461
3. RBI Discussion Paper, “Exploring Safeguards in Digital Payments to Curb Frauds” (9 April 2026):  
   https://www.rbi.org.in/Scripts/PublicationsView.aspx?id=23810
4. RBI press release inviting comments on the digital-payment safeguards discussion paper:  
   https://www.rbi.org.in/Scripts/BS_PressReleaseDisplay.aspx?prid=62535
5. RBI speech explaining the system-wide intent behind MuleHunter.ai:  
   https://www.rbi.org.in/scripts/BS_SpeechesView.aspx?id=1490

---

# 28. FINAL TEAM RULE

When in doubt, do not invent a new feature or interface. Return to this blueprint, identify the module and contract involved, and propose the smallest compatible change. StreamShield succeeds only if all components behave as one product: the same customer journey, the same risk vocabulary, the same data contracts, the same safety rules, and the same accessible experience.

**End of canonical blueprint.**
