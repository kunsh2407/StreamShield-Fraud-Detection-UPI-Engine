"""Evaluate Models A (TBE), B (TBE+BRE), and C (TBE+BRE+CCE) on the held-out test split.

Outputs real measured precision, recall, F1, PR-AUC, Brier score, confusion matrix,
false-positive rate, false-negative rate, digital-arrest recall, and measured inference
latency percentiles into ml/artifacts/evaluation_metrics.json.
"""

from __future__ import annotations

import json
import time
from datetime import datetime, timezone
from pathlib import Path
import joblib
import numpy as np
import pandas as pd
from sklearn.metrics import (
    average_precision_score,
    brier_score_loss,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
)

from train_fusion_model import assemble_fusion_matrices

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
ARTIFACTS_DIR = BASE_DIR / "ml" / "artifacts"


def evaluate_single_model(
    key: str,
    name: str,
    modules: str,
    description: str,
    X_test: np.ndarray,
    y_test: np.ndarray,
    is_digital_arrest: np.ndarray,
) -> dict:
    bundle = joblib.load(ARTIFACTS_DIR / f"{key}.joblib")
    model = bundle["model"]
    threshold = float(bundle["threshold"])

    # Measure real single-sample scoring latencies across held-out test set
    latencies_ms = []
    probs_list = []
    for row_idx in range(len(X_test)):
        sample = X_test[row_idx : row_idx + 1]
        t0 = time.perf_counter()
        prob = float(model.predict_proba(sample)[0, 1])
        latencies_ms.append((time.perf_counter() - t0) * 1000.0)
        probs_list.append(prob)

    probs = np.asarray(probs_list, dtype=np.float64)
    preds = (probs >= threshold).astype(int)

    tn, fp, fn, tp = confusion_matrix(y_test, preds, labels=[0, 1]).ravel()
    precision = float(precision_score(y_test, preds, zero_division=0))
    recall = float(recall_score(y_test, preds, zero_division=0))
    f1 = float(f1_score(y_test, preds, zero_division=0))
    pr_auc = float(average_precision_score(y_test, probs))
    brier = float(brier_score_loss(y_test, probs))
    fp_rate = float(fp / max(1, fp + tn))
    fn_rate = float(fn / max(1, fn + tp))

    if is_digital_arrest.sum() > 0:
        da_caught = float(preds[is_digital_arrest].mean() * 100.0)
    else:
        da_caught = 0.0

    return {
        "key": key,
        "name": name,
        "modules": modules,
        "description": description,
        "threshold": round(threshold, 3),
        "precision": round(precision, 4),
        "recall": round(recall, 4),
        "f1": round(f1, 4),
        "prAuc": round(pr_auc, 4),
        "brierScore": round(brier, 4),
        "fpRate": round(fp_rate, 4),
        "fnRate": round(fn_rate, 4),
        "digitalArrestCaughtPercent": round(da_caught, 1),
        "confusionMatrix": {
            "tp": int(tp),
            "fp": int(fp),
            "tn": int(tn),
            "fn": int(fn),
        },
        "avgLatencyMs": round(float(np.mean(latencies_ms)), 3),
        "p50LatencyMs": round(float(np.percentile(latencies_ms, 50)), 3),
        "p95LatencyMs": round(float(np.percentile(latencies_ms, 95)), 3),
    }


def main() -> None:
    ARTIFACTS_DIR.mkdir(parents=True, exist_ok=True)
    merged, matrices, y = assemble_fusion_matrices()
    answers_df = pd.read_csv(DATA_DIR / "question_answers.csv")

    test_mask = (merged["split"] == "test").to_numpy()
    y_test = y[test_mask]
    is_digital_arrest = (merged.loc[test_mask, "scenario_family"] == "digital_arrest").to_numpy()

    test_pids = set(merged.loc[test_mask, "payment_id"])
    test_answers = answers_df[answers_df["payment_id"].isin(test_pids)]
    avg_questions = round(float(len(test_answers) / max(1, len(test_pids))), 2)
    skip_rate = round(float((test_answers["answer"] == "SKIP").mean()), 4) if len(test_answers) else 0.0

    specs = [
        (
            "model_a",
            "Model A: Transaction Only",
            "TBE",
            "Payer transaction baseline, velocity, amount deviation, and time of day. Blind to beneficiary network and coercion context.",
        ),
        (
            "model_b",
            "Model B: Tx + Beneficiary Mule Intelligence",
            "TBE + BRE",
            "Transaction baseline + synthetic beneficiary NetworkX graph degree, counterparty diversity, and flow-through ratio.",
        ),
        (
            "model_c",
            "Model C: StreamShield Full Fusion (Tx + Mule + Coercion Context)",
            "TBE + BRE + CCE (StreamShield)",
            "Combines payer transaction behavior, beneficiary mule-risk intelligence, and adaptive victim social-engineering context.",
        ),
    ]

    results = []
    for key, name, modules, desc in specs:
        results.append(
            evaluate_single_model(
                key,
                name,
                modules,
                desc,
                matrices[key][test_mask],
                y_test,
                is_digital_arrest,
            )
        )

    report = {
        "generated_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
        "dataset_summary": {
            "total_scenarios": int(len(merged)),
            "test_scenarios": int(test_mask.sum()),
            "test_positive_rate": round(float(y_test.mean()), 4),
            "avg_questions_per_payment": avg_questions,
            "questionnaire_skip_rate": skip_rate,
            "split_strategy": "Grouped strictly by customer_id to prevent customer/scenario leakage",
        },
        "models": results,
    }

    out_path = ARTIFACTS_DIR / "evaluation_metrics.json"
    out_path.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(f"Wrote real measured ablation report to {out_path}")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
