"""Train Beneficiary Risk Engine (BRE) classifier on synthetic beneficiary profiles."""

from __future__ import annotations

from pathlib import Path
import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import average_precision_score
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

from feature_engineering import BRE_FEATURE_NAMES, extract_bre_features

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
ARTIFACTS_DIR = BASE_DIR / "ml" / "artifacts"


def main() -> None:
    ARTIFACTS_DIR.mkdir(parents=True, exist_ok=True)
    beneficiaries_df = pd.read_csv(DATA_DIR / "beneficiaries.csv")
    labels_df = pd.read_csv(DATA_DIR / "scenario_labels.csv")

    # Derive beneficiary split without leakage across scenario splits
    ben_split = labels_df.groupby("beneficiary_id")["split"].first().to_dict()
    beneficiaries_df["split"] = beneficiaries_df["beneficiary_id"].map(lambda b: ben_split.get(b, "train"))

    X_all = np.asarray(
        [extract_bre_features(row) for row in beneficiaries_df.to_dict("records")],
        dtype=np.float64,
    )
    y_all = beneficiaries_df["beneficiary_is_mule_like"].to_numpy(dtype=np.int64)

    train_mask = (beneficiaries_df["split"] == "train").to_numpy()
    val_mask = (beneficiaries_df["split"] == "val").to_numpy()
    if val_mask.sum() < 10:
        # Ensure validation coverage if grouping assigned most canonical IDs to train
        val_mask = ~train_mask

    candidates = {
        "logistic_regression": Pipeline(
            [
                ("scaler", StandardScaler()),
                ("clf", LogisticRegression(max_iter=1000, class_weight="balanced", random_state=42)),
            ]
        ),
        "random_forest": RandomForestClassifier(
            n_estimators=120,
            max_depth=6,
            min_samples_leaf=3,
            class_weight="balanced",
            random_state=42,
        ),
    }

    best_name = ""
    best_model = None
    best_val_pr_auc = -1.0

    for name, model in candidates.items():
        model.fit(X_all[train_mask], y_all[train_mask])
        val_probs = model.predict_proba(X_all[val_mask])[:, 1]
        val_pr = float(average_precision_score(y_all[val_mask], val_probs))
        print(f"BRE candidate {name}: val PR-AUC={val_pr:.4f}")
        if val_pr > best_val_pr_auc:
            best_val_pr_auc = val_pr
            best_name = name
            best_model = model

    joblib.dump(
        {
            "model": best_model,
            "model_type": best_name,
            "feature_names": BRE_FEATURE_NAMES,
            "val_pr_auc": best_val_pr_auc,
            "model_version": "bre_v1.0",
        },
        ARTIFACTS_DIR / "bre_model.joblib",
    )
    print(f"Saved best BRE model ({best_name}) to ml/artifacts/bre_model.joblib")


if __name__ == "__main__":
    main()
