"""Deterministic feature engineering shared by offline ML training and online FastAPI inference.

Important fairness invariant (Blueprint Section 20):
- Never include customer age, preferred_language, or profile_group as fraud predictors.
- Never treat SKIP or NOT_SURE answers as positive fraud indicators.
"""

from __future__ import annotations

import json
import math
from typing import Any, Mapping, Sequence

TBE_FEATURE_NAMES = [
    "amount_mad_z",
    "amount_log_ratio",
    "is_new_beneficiary",
    "is_unusual_hour",
    "recent_txn_count_1h",
    "recent_cancelled_count_24h",
    "first_time_high_value",
]

BRE_FEATURE_NAMES = [
    "log_account_age_days",
    "is_cold_start_account",
    "customer_counterparties_30d",
    "incoming_txn_count_24h",
    "log_incoming_amount_24h",
    "flow_through_ratio",
    "network_degree",
    "synthetic_report_count",
]

CCE_FEATURE_NAMES = [
    "urgency_yes",
    "threat_yes",
    "secrecy_yes",
    "guidance_yes",
    "impersonation_yes",
    "purpose_unclear",
    "positive_coercion_count",
    "has_coercion_answers",
]


def extract_tbe_features(
    payment: Mapping[str, Any],
    customer: Mapping[str, Any],
) -> list[float]:
    amount = max(1.0, float(payment.get("amount", 0.0)))
    median = max(100.0, float(customer.get("baseline_amount_median", 1500.0)))
    mad = max(50.0, float(customer.get("baseline_amount_mad", 450.0)))

    amount_mad_z = min(50.0, max(0.0, (amount - median) / mad))
    amount_log_ratio = max(-5.0, math.log1p(amount) - math.log1p(median))
    is_new_ben = 1.0 if bool(payment.get("is_new_beneficiary", True)) else 0.0

    raw_hours = customer.get("usual_active_hours", [8, 9, 10, 11, 16, 17, 18])
    if isinstance(raw_hours, str):
        usual_hours = set(int(h) for h in json.loads(raw_hours))
    else:
        usual_hours = set(int(h) for h in raw_hours)

    txn_hour = int(payment.get("txn_hour", 14)) % 24
    is_unusual_hour = 0.0 if txn_hour in usual_hours else 1.0

    recent_1h = float(payment.get("recent_txn_count_1h", 0))
    recent_cancelled = float(payment.get("recent_cancelled_count_24h", 0))
    first_time_high_value = 1.0 if (is_new_ben == 1.0 and amount >= median * 5.0) else 0.0

    return [
        amount_mad_z,
        amount_log_ratio,
        is_new_ben,
        is_unusual_hour,
        recent_1h,
        recent_cancelled,
        first_time_high_value,
    ]


def extract_bre_features(beneficiary: Mapping[str, Any]) -> list[float]:
    age_raw = beneficiary.get("account_age_days")
    age_days = float(age_raw) if age_raw is not None and str(age_raw) != "nan" else 7.0
    log_age = math.log1p(max(0.0, age_days))
    is_cold_start = 1.0 if age_days < 30.0 else 0.0

    counterparties = float(beneficiary.get("customer_counterparties_30d", 0))
    in_cnt = float(beneficiary.get("incoming_txn_count_24h", 0))
    in_amt = max(0.0, float(beneficiary.get("incoming_amount_24h", 0.0)))
    log_in_amt = math.log1p(in_amt)
    ftr = min(1.0, max(0.0, float(beneficiary.get("flow_through_ratio", 0.0))))
    net_deg = float(beneficiary.get("network_degree", 0))
    reports = float(beneficiary.get("synthetic_report_count", 0))

    return [
        log_age,
        is_cold_start,
        counterparties,
        in_cnt,
        log_in_amt,
        ftr,
        net_deg,
        reports,
    ]


def extract_cce_features(answers: Sequence[Mapping[str, Any]]) -> list[float]:
    ans_by_id = {str(a.get("question_id")): str(a.get("answer")) for a in answers}

    urgency_yes = 1.0 if ans_by_id.get("Q_URGENCY") == "YES" else 0.0
    threat_yes = 1.0 if ans_by_id.get("Q_THREAT") == "YES" else 0.0
    secrecy_yes = 1.0 if ans_by_id.get("Q_SECRECY") == "YES" else 0.0
    guidance_yes = 1.0 if ans_by_id.get("Q_GUIDANCE") == "YES" else 0.0
    impersonation_yes = 1.0 if ans_by_id.get("Q_IDENTITY") == "YES" else 0.0
    # For Q_PURPOSE ("Do you personally know why this person needs the money?"),
    # 'NO' indicates unclear pretext (NOT 'SKIP' or 'NOT_SURE').
    purpose_unclear = 1.0 if ans_by_id.get("Q_PURPOSE") == "NO" else 0.0

    positive_count = urgency_yes + threat_yes + secrecy_yes + guidance_yes + impersonation_yes
    has_answers = 1.0 if len(ans_by_id) > 0 else 0.0

    return [
        urgency_yes,
        threat_yes,
        secrecy_yes,
        guidance_yes,
        impersonation_yes,
        purpose_unclear,
        positive_count,
        has_answers,
    ]
