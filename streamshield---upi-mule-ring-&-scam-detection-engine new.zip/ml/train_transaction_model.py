"""Train Transaction Behaviour Engine (TBE) classifier on synthetic payments."""

from __future__ import annotations

from pathlib import Path
import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import average_precision_score
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

from feature_engineering import TBE_FEATURE_NAMES, extract_tbe_features

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
ARTIFACTS_DIR = BASE_DIR / "ml" / "artifacts"


def build_tbe_matrix(
    payments_df: pd.DataFrame,
    customers_df: pd.DataFrame,
) -> np.ndarray:
    cust_map = customers_df.set_index("customer_id").to_dict("index")
    rows = [
        extract_tbe_features(row, cust_map[row["customer_id"]])
        for row in payments_df.to_dict("records")
    ]
    return np.asarray(rows, dtype=np.float64)


def main() -> None:
    ARTIFACTS_DIR.mkdir(parents=True, exist_ok=True)
    customers_df = pd.read_csv(DATA_DIR / "customers.csv")
    payments_df = pd.read_csv(DATA_DIR / "payments.csv")
    labels_df = pd.read_csv(DATA_DIR / "scenario_labels.csv")

    merged = payments_df.merge(labels_df[["payment_id", "payment_is_scam_induced", "split"]], on="payment_id")
    X_all = build_tbe_matrix(merged, customers_df)
    y_all = merged["payment_is_scam_induced"].to_numpy(dtype=np.int64)

    train_mask = (merged["split"] == "train").to_numpy()
    val_mask = (merged["split"] == "val").to_numpy()

    candidates = {
        "logistic_regression": Pipeline(
            [
                ("scaler", StandardScaler()),
                ("clf", LogisticRegression(max_iter=1000, class_weight="balanced", random_state=42)),
            ]
        ),
        "random_forest": RandomForestClassifier(
            n_estimators=120,
            max_depth=7,
            min_samples_leaf=4,
            class_weight="balanced",
            random_state=42,
        ),
    }

    best_name = ""
    best_model = None
    best_val_pr_auc = -1.0

    for name, model in candidates.items():
        model.fit(X_all[train_mask], y_all[train_mask])
        val_probs = model.predict_proba(X_all[val_mask])[:, 1]
        val_pr = float(average_precision_score(y_all[val_mask], val_probs))
        print(f"TBE candidate {name}: val PR-AUC={val_pr:.4f}")
        if val_pr > best_val_pr_auc:
            best_val_pr_auc = val_pr
            best_name = name
            best_model = model

    joblib.dump(
        {
            "model": best_model,
            "model_type": best_name,
            "feature_names": TBE_FEATURE_NAMES,
            "val_pr_auc": best_val_pr_auc,
            "model_version": "tbe_v1.0",
        },
        ARTIFACTS_DIR / "tbe_model.joblib",
    )
    print(f"Saved best TBE model ({best_name}) to ml/artifacts/tbe_model.joblib")


if __name__ == "__main__":
    main()
