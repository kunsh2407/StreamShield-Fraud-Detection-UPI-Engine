"""Offline synthetic dataset generator for StreamShield (Blueprint Sections 8 & 15).

Generates reproducible synthetic customers, beneficiaries (with NetworkX graph features),
payments, scenario labels, and questionnaire answers without customer/scenario leakage
across train/val/test splits.
"""

from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone
from pathlib import Path
import numpy as np
import pandas as pd
import networkx as nx

SEED = 42
BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"

CANONICAL_CUSTOMERS = [
    {
        "customer_id": "CUS_0001",
        "name": "Rama Rao (Senior Citizen)",
        "preferred_language": "te",
        "profile_group": "SENIOR",
        "baseline_txn_count_30d": 14,
        "baseline_amount_median": 1500.0,
        "baseline_amount_mad": 450.0,
        "usual_active_hours": [8, 9, 10, 11, 16, 17, 18],
        "occupation": "Retired Public Sector Officer",
        "age": 72,
    },
    {
        "customer_id": "CUS_0002",
        "name": "Priya Sharma (Everyday User)",
        "preferred_language": "en",
        "profile_group": "GENERAL",
        "baseline_txn_count_30d": 65,
        "baseline_amount_median": 3200.0,
        "baseline_amount_mad": 1200.0,
        "usual_active_hours": [9, 10, 12, 13, 14, 18, 19, 20, 21, 22],
        "occupation": "Software Engineer",
        "age": 28,
    },
    {
        "customer_id": "CUS_0003",
        "name": "Ramesh Kumar (Limited Literacy)",
        "preferred_language": "hi",
        "profile_group": "LIMITED_LITERACY_TEST",
        "baseline_txn_count_30d": 22,
        "baseline_amount_median": 850.0,
        "baseline_amount_mad": 250.0,
        "usual_active_hours": [6, 7, 8, 9, 11, 15, 17, 19, 20],
        "occupation": "Small Grocery Shopkeeper",
        "age": 58,
    },
    {
        "customer_id": "CUS_0004",
        "name": "Sunita Devi (Family Payer)",
        "preferred_language": "hi",
        "profile_group": "GENERAL",
        "baseline_txn_count_30d": 28,
        "baseline_amount_median": 2100.0,
        "baseline_amount_mad": 600.0,
        "usual_active_hours": [7, 8, 13, 17, 18, 19, 21],
        "occupation": "High School Teacher",
        "age": 44,
    },
]

CANONICAL_BENEFICIARIES = [
    {
        "beneficiary_id": "BEN_0101",
        "vpa": "dr_satyanarayana_clinic@okhdfcbank",
        "name": "Dr. K. Satyanarayana Clinic (Trusted Doctor)",
        "account_age_days": 1280,
        "customer_counterparties_30d": 140,
        "incoming_txn_count_24h": 8,
        "incoming_amount_24h": 12000.0,
        "outgoing_amount_24h": 2500.0,
        "flow_through_ratio": 0.21,
        "network_degree": 3,
        "synthetic_report_count": 0,
        "category": "Healthcare / Doctor",
        "risk_tier": "LOW",
        "beneficiary_is_mule_like": 0,
    },
    {
        "beneficiary_id": "BEN_0102",
        "vpa": "srinivasa_kirana_daily@paytm",
        "name": "Srinivasa Kirana & Provisions (Local Merchant)",
        "account_age_days": 1540,
        "customer_counterparties_30d": 310,
        "incoming_txn_count_24h": 24,
        "incoming_amount_24h": 18500.0,
        "outgoing_amount_24h": 4200.0,
        "flow_through_ratio": 0.23,
        "network_degree": 2,
        "synthetic_report_count": 0,
        "category": "Merchant / Groceries",
        "risk_tier": "LOW",
        "beneficiary_is_mule_like": 0,
    },
    {
        "beneficiary_id": "BEN_0601",
        "vpa": "cyber_nodal_verification_desk@ybl",
        "name": "Mule Account (Fake Digital-Arrest Threat Funnel)",
        "account_age_days": 3,
        "customer_counterparties_30d": 19,
        "incoming_txn_count_24h": 14,
        "incoming_amount_24h": 890000.0,
        "outgoing_amount_24h": 865000.0,
        "flow_through_ratio": 0.97,
        "network_degree": 18,
        "synthetic_report_count": 7,
        "category": "Unverified Mule / Cyber Impersonation",
        "risk_tier": "HIGH",
        "beneficiary_is_mule_like": 1,
    },
    {
        "beneficiary_id": "BEN_0602",
        "vpa": "instant_kyc_verification_hub@okaxis",
        "name": "Mule Ring Node (Fake Bank KYC / Account Block)",
        "account_age_days": 6,
        "customer_counterparties_30d": 26,
        "incoming_txn_count_24h": 18,
        "incoming_amount_24h": 520000.0,
        "outgoing_amount_24h": 495000.0,
        "flow_through_ratio": 0.95,
        "network_degree": 14,
        "synthetic_report_count": 4,
        "category": "Layering Mule / Fake Bank Staff",
        "risk_tier": "HIGH",
        "beneficiary_is_mule_like": 1,
    },
    {
        "beneficiary_id": "BEN_0603",
        "vpa": "crypto_arbitrage_guaranteed@icici",
        "name": "Investment Scam Smurfing Account",
        "account_age_days": 12,
        "customer_counterparties_30d": 34,
        "incoming_txn_count_24h": 12,
        "incoming_amount_24h": 290000.0,
        "outgoing_amount_24h": 275000.0,
        "flow_through_ratio": 0.94,
        "network_degree": 9,
        "synthetic_report_count": 3,
        "category": "High-Yield Investment Fraud",
        "risk_tier": "HIGH",
        "beneficiary_is_mule_like": 1,
    },
]


def generate_customers(rng: np.random.Generator, total_customers: int = 240) -> pd.DataFrame:
    rows = []
    for c in CANONICAL_CUSTOMERS:
        rows.append(
            {
                **c,
                "usual_active_hours": json.dumps(c["usual_active_hours"]),
                "customer_split": "train",
            }
        )

    languages = ["en", "te", "hi"]
    groups = ["SENIOR", "GENERAL", "LIMITED_LITERACY_TEST"]
    occupations = [
        "Retired Teacher",
        "Shopkeeper",
        "Engineer",
        "Small Business Owner",
        "Farmer",
        "Bank Clerk",
        "Homemaker",
        "Student",
    ]

    for idx in range(5, total_customers + 1):
        cid = f"CUS_{idx:04d}"
        group = rng.choice(groups, p=[0.28, 0.52, 0.20])
        lang = rng.choice(languages, p=[0.4, 0.3, 0.3])
        if group == "SENIOR":
            age = int(rng.integers(61, 82))
        elif group == "LIMITED_LITERACY_TEST":
            age = int(rng.integers(32, 68))
        else:
            age = int(rng.integers(21, 60))

        # Deliberately keep baseline distribution independent of age/group bias
        median_amt = float(np.round(rng.uniform(700, 4800), 2))
        mad_amt = float(np.round(median_amt * rng.uniform(0.22, 0.45), 2))
        txn_30d = int(rng.integers(8, 85))
        start_h = int(rng.integers(6, 10))
        hours = sorted(list({int(h % 24) for h in range(start_h, start_h + int(rng.integers(8, 14)))}))

        # Assign split strictly by customer_id to prevent customer leakage
        if idx <= int(total_customers * 0.6):
            split = "train"
        elif idx <= int(total_customers * 0.8):
            split = "val"
        else:
            split = "test"

        rows.append(
            {
                "customer_id": cid,
                "name": f"Synthetic Customer {idx:04d}",
                "preferred_language": lang,
                "profile_group": group,
                "baseline_txn_count_30d": txn_30d,
                "baseline_amount_median": median_amt,
                "baseline_amount_mad": mad_amt,
                "usual_active_hours": json.dumps(hours),
                "occupation": str(rng.choice(occupations)),
                "age": age,
                "customer_split": split,
            }
        )

    return pd.DataFrame(rows)


def generate_beneficiaries(rng: np.random.Generator, total_beneficiaries: int = 300) -> pd.DataFrame:
    # Build synthetic NetworkX transaction graph to compute degree/hub features
    graph = nx.DiGraph()
    rows = []

    for b in CANONICAL_BENEFICIARIES:
        rows.append(dict(b))
        graph.add_node(b["beneficiary_id"])

    legit_categories = [
        "Merchant / Groceries",
        "Healthcare / Hospital",
        "Education / Fees",
        "Family / Relative",
        "Rent / Landlord",
        "Business Supplier",
    ]
    mule_categories = [
        "Unverified Mule / Cyber Impersonation",
        "Layering Mule / Fake Bank Staff",
        "High-Yield Investment Fraud",
        "Emergency Pretext Funnel",
    ]

    for idx in range(1001, 1001 + total_beneficiaries - len(CANONICAL_BENEFICIARIES)):
        bid = f"BEN_{idx:04d}"
        is_mule = int(rng.random() < 0.24)
        # Include stealth/rented cold-start mules and busy legitimate merchants (realistic overlap)
        if is_mule:
            is_fresh_mule = rng.random() < 0.38
            age_days = int(rng.integers(1, 20)) if is_fresh_mule else int(rng.integers(8, 120))
            counterparties = int(rng.integers(2, 16)) if is_fresh_mule else int(rng.integers(14, 70))
            in_cnt = int(rng.integers(2, 11)) if is_fresh_mule else int(rng.integers(8, 45))
            in_amt = float(np.round(rng.uniform(35000, 850000), 2))
            ftr = float(np.round(rng.uniform(0.32, 0.72), 4)) if is_fresh_mule else float(np.round(rng.uniform(0.75, 0.99), 4))
            out_amt = float(np.round(in_amt * ftr, 2))
            reports = 0 if is_fresh_mule else int(rng.integers(1, 8))
            category = str(rng.choice(mule_categories))
            tier = "HIGH" if reports >= 1 or ftr >= 0.85 else "MEDIUM"
        else:
            is_new_legit = rng.random() < 0.18
            age_days = int(rng.integers(5, 45)) if is_new_legit else int(rng.integers(90, 2200))
            is_busy_merchant = rng.random() < 0.28
            counterparties = int(rng.integers(45, 420)) if is_busy_merchant else int(rng.integers(2, 45))
            in_cnt = int(rng.integers(12, 60)) if is_busy_merchant else int(rng.integers(1, 12))
            in_amt = float(np.round(rng.uniform(5000, 240000), 2))
            ftr = float(np.round(rng.uniform(0.10, 0.68), 4))
            out_amt = float(np.round(in_amt * ftr, 2))
            reports = 0
            category = str(rng.choice(legit_categories))
            tier = "LOW"

        rows.append(
            {
                "beneficiary_id": bid,
                "vpa": f"syn_{bid.lower()}@okaxis",
                "name": f"Synthetic Beneficiary {idx:04d}",
                "account_age_days": age_days,
                "customer_counterparties_30d": counterparties,
                "incoming_txn_count_24h": in_cnt,
                "incoming_amount_24h": in_amt,
                "outgoing_amount_24h": out_amt,
                "flow_through_ratio": ftr,
                "network_degree": 0,  # populated from NetworkX below
                "synthetic_report_count": reports,
                "category": category,
                "risk_tier": tier,
                "beneficiary_is_mule_like": is_mule,
            }
        )
        graph.add_node(bid)

    # Wire synthetic graph edges (mule rings connect tightly; legitimate accounts sparsely)
    mule_ids = [r["beneficiary_id"] for r in rows if r["beneficiary_is_mule_like"] == 1]
    legit_ids = [r["beneficiary_id"] for r in rows if r["beneficiary_is_mule_like"] == 0]

    for m_id in mule_ids:
        num_links = int(rng.integers(2, 14))
        peers = rng.choice(mule_ids, size=min(num_links, len(mule_ids)), replace=False)
        for p in peers:
            if p != m_id:
                graph.add_edge(m_id, str(p))

    for l_id in legit_ids:
        num_links = int(rng.integers(1, 5))
        peers = rng.choice(legit_ids, size=min(num_links, len(legit_ids)), replace=False)
        for p in peers:
            if p != l_id:
                graph.add_edge(l_id, str(p))

    for r in rows:
        bid = r["beneficiary_id"]
        if not bid.startswith("BEN_010") and not bid.startswith("BEN_060"):
            r["network_degree"] = int(graph.degree(bid))

    return pd.DataFrame(rows)


def generate_scenarios(
    rng: np.random.Generator,
    customers_df: pd.DataFrame,
    beneficiaries_df: pd.DataFrame,
    n_scenarios: int = 2400,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Generate 2,400 labelled payment scenarios + questionnaire answers."""
    base_time = datetime(2026, 11, 1, 8, 0, 0, tzinfo=timezone.utc)

    mule_bens = beneficiaries_df[beneficiaries_df["beneficiary_is_mule_like"] == 1].to_dict("records")
    legit_bens = beneficiaries_df[beneficiaries_df["beneficiary_is_mule_like"] == 0].to_dict("records")
    cust_records = customers_df.to_dict("records")

    scenario_families = [
        "legitimate_everyday",
        "legitimate_unusual",
        "digital_arrest",
        "fake_kyc",
        "investment_scam",
        "family_emergency_scam",
        "other_coercion",
    ]
    # Realistic class balance (~21% APP scams + ~79% legitimate including hard negatives)
    family_probs = [0.51, 0.28, 0.07, 0.05, 0.04, 0.03, 0.02]

    payments_rows = []
    labels_rows = []
    answers_rows = []

    for i in range(1, n_scenarios + 1):
        cust = cust_records[int(rng.integers(0, len(cust_records)))]
        family = str(rng.choice(scenario_families, p=family_probs))
        pid = f"PAY_{i:06d}"

        usual_hours = json.loads(cust["usual_active_hours"])
        median_amt = float(cust["baseline_amount_median"])
        mad_amt = float(cust["baseline_amount_mad"])

        if family == "legitimate_everyday":
            ben = legit_bens[int(rng.integers(0, len(legit_bens)))]
            amt = float(np.round(max(50.0, rng.normal(median_amt, mad_amt * 0.7)), 2))
            is_new_ben = bool(rng.random() < 0.14)
            hour = int(rng.choice(usual_hours))
            recent_1h = int(rng.integers(0, 2))
            recent_cancelled = 0
            purpose = str(rng.choice(["Groceries", "Pharmacy", "Utilities", "Dinner", "Fuel"]))
            scam_induced = 0
            coercion_present = 0

        elif family == "legitimate_unusual":
            # Hard negatives: large medical, education, rent, urgent legitimate transfers
            ben = legit_bens[int(rng.integers(0, len(legit_bens)))]
            amt = float(np.round(median_amt * rng.uniform(7.0, 38.0), 2))
            is_new_ben = bool(rng.random() < 0.78)
            hour = int(rng.integers(0, 24)) if rng.random() < 0.42 else int(rng.choice(usual_hours))
            recent_1h = int(rng.integers(1, 4))
            recent_cancelled = int(rng.random() < 0.25)
            purpose = str(rng.choice(["Medical Surgery", "College Fees", "House Rent", "Supplier Invoice"]))
            scam_induced = 0
            coercion_present = 0

        else:
            # APP / Coercion scam scenarios
            # 36% of scams use a brand-new/low-report rented account so BRE alone has blind spots
            use_stealth_ben = rng.random() < 0.36
            ben = legit_bens[int(rng.integers(0, len(legit_bens)))] if use_stealth_ben else mule_bens[int(rng.integers(0, len(mule_bens)))]
            amt = float(np.round(median_amt * rng.uniform(6.0, 42.0), 2))
            is_new_ben = bool(rng.random() < 0.85)
            hour = int(rng.integers(0, 24)) if rng.random() < 0.38 else int(rng.choice(usual_hours))
            recent_1h = int(rng.integers(0, 4))
            recent_cancelled = int(rng.integers(0, 2))
            purpose_map = {
                "digital_arrest": "Court Bail / Cyber Verification",
                "fake_kyc": "Account KYC Unblock Charge",
                "investment_scam": "Arbitrage Trading Deposit",
                "family_emergency_scam": "Urgent Hospital Help",
                "other_coercion": "Verification Transfer",
            }
            purpose = purpose_map[family]
            scam_induced = 1
            coercion_present = 1

        created_at = (base_time + timedelta(minutes=i * 7, hours=hour % 24)).isoformat().replace("+00:00", "Z")

        payments_rows.append(
            {
                "payment_id": pid,
                "customer_id": cust["customer_id"],
                "beneficiary_id": ben["beneficiary_id"],
                "amount": amt,
                "currency": "INR",
                "purpose": purpose,
                "created_at": created_at,
                "is_new_beneficiary": is_new_ben,
                "txn_hour": hour,
                "recent_txn_count_1h": recent_1h,
                "recent_cancelled_count_24h": recent_cancelled,
                "channel": "WEB_SIMULATOR",
            }
        )

        labels_rows.append(
            {
                "payment_id": pid,
                "customer_id": cust["customer_id"],
                "beneficiary_id": ben["beneficiary_id"],
                "beneficiary_is_mule_like": int(ben["beneficiary_is_mule_like"]),
                "payment_is_scam_induced": scam_induced,
                "coercion_present": coercion_present,
                "scenario_family": family,
                "split": cust["customer_split"],
            }
        )

        # Simulate realistic questionnaire responses (max 3 questions, including coached 'NO' & 'SKIP')
        if coercion_present == 1:
            # Coached victim answers NO ~12% of the time, SKIP/NOT_SURE ~6%
            ans_urgency = "NO" if rng.random() < 0.12 else ("NOT_SURE" if rng.random() < 0.06 else "YES")
            ans_threat = (
                "YES"
                if family in ("digital_arrest", "fake_kyc") and rng.random() < 0.88
                else ("NO" if rng.random() < 0.7 else "NOT_SURE")
            )
            ans_secrecy = "YES" if rng.random() < 0.78 else ("SKIP" if rng.random() < 0.12 else "NO")
            ans_guidance = "YES" if rng.random() < 0.65 else "NO"
            ans_identity = (
                "YES"
                if family in ("digital_arrest", "fake_kyc", "family_emergency_scam") and rng.random() < 0.82
                else "NO"
            )
            ans_purpose = "NO" if rng.random() < 0.72 else "NOT_SURE"
        else:
            # Legitimate urgent payments might report urgency ~22% of time, but rarely threats or secrecy
            ans_urgency = "YES" if (family == "legitimate_unusual" and rng.random() < 0.22) else "NO"
            ans_threat = "NO" if rng.random() < 0.98 else "NOT_SURE"
            ans_secrecy = "NO" if rng.random() < 0.97 else "SKIP"
            ans_guidance = "NO" if rng.random() < 0.96 else "NOT_SURE"
            ans_identity = "NO"
            ans_purpose = "YES" if rng.random() < 0.94 else "NOT_SURE"

        q_map = {
            "Q_URGENCY": ans_urgency,
            "Q_THREAT": ans_threat,
            "Q_SECRECY": ans_secrecy,
            "Q_GUIDANCE": ans_guidance,
            "Q_IDENTITY": ans_identity,
            "Q_PURPOSE": ans_purpose,
        }

        # Record up to 3 adaptive answers matching AQS logic
        selected_qs = ["Q_URGENCY"]
        if ans_urgency == "YES":
            selected_qs.append("Q_THREAT")
            selected_qs.append("Q_SECRECY" if ans_threat == "YES" else "Q_IDENTITY")
        elif is_new_ben or amt > median_amt * 4:
            selected_qs.append("Q_IDENTITY")
            selected_qs.append("Q_PURPOSE")

        for qid in selected_qs[:3]:
            answers_rows.append(
                {
                    "payment_id": pid,
                    "question_id": qid,
                    "answer": q_map[qid],
                    "input_mode": str(rng.choice(["TAP", "VOICE", "TEXT"], p=[0.7, 0.25, 0.05])),
                    "answered_at": created_at,
                }
            )

    return pd.DataFrame(payments_rows), pd.DataFrame(labels_rows), pd.DataFrame(answers_rows)


def main() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(SEED)

    customers_df = generate_customers(rng, total_customers=240)
    beneficiaries_df = generate_beneficiaries(rng, total_beneficiaries=300)
    payments_df, labels_df, answers_df = generate_scenarios(rng, customers_df, beneficiaries_df, n_scenarios=2400)

    customers_df.to_csv(DATA_DIR / "customers.csv", index=False)
    beneficiaries_df.to_csv(DATA_DIR / "beneficiaries.csv", index=False)
    payments_df.to_csv(DATA_DIR / "payments.csv", index=False)
    labels_df.to_csv(DATA_DIR / "scenario_labels.csv", index=False)
    answers_df.to_csv(DATA_DIR / "question_answers.csv", index=False)

    summary = {
        "seed": SEED,
        "customers": len(customers_df),
        "beneficiaries": len(beneficiaries_df),
        "payments": len(payments_df),
        "scam_rate": round(float(labels_df["payment_is_scam_induced"].mean()), 4),
        "splits": labels_df["split"].value_counts().to_dict(),
    }
    print("Generated synthetic datasets:", json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
