"""Train ablation fusion models A (TBE), B (TBE+BRE), and C (TBE+BRE+CCE) on held-out train/val splits."""

from __future__ import annotations

from pathlib import Path
import joblib
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import average_precision_score, f1_score
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

from feature_engineering import (
    BRE_FEATURE_NAMES,
    CCE_FEATURE_NAMES,
    TBE_FEATURE_NAMES,
    extract_bre_features,
    extract_cce_features,
    extract_tbe_features,
)

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
ARTIFACTS_DIR = BASE_DIR / "ml" / "artifacts"


def assemble_fusion_matrices() -> tuple[pd.DataFrame, dict[str, np.ndarray], np.ndarray]:
    customers_df = pd.read_csv(DATA_DIR / "customers.csv")
    beneficiaries_df = pd.read_csv(DATA_DIR / "beneficiaries.csv")
    payments_df = pd.read_csv(DATA_DIR / "payments.csv")
    labels_df = pd.read_csv(DATA_DIR / "scenario_labels.csv")
    answers_df = pd.read_csv(DATA_DIR / "question_answers.csv")

    cust_map = customers_df.set_index("customer_id").to_dict("index")
    ben_map = beneficiaries_df.set_index("beneficiary_id").to_dict("index")
    ans_grouped: dict[str, list[dict[str, str]]] = {}
    for row in answers_df.to_dict("records"):
        ans_grouped.setdefault(row["payment_id"], []).append(row)

    merged = payments_df.merge(
        labels_df[["payment_id", "payment_is_scam_induced", "scenario_family", "split"]],
        on="payment_id",
    )

    tbe_rows = []
    bre_rows = []
    cce_rows = []
    for row in merged.to_dict("records"):
        tbe_rows.append(extract_tbe_features(row, cust_map[row["customer_id"]]))
        bre_rows.append(extract_bre_features(ben_map[row["beneficiary_id"]]))
        cce_rows.append(extract_cce_features(ans_grouped.get(row["payment_id"], [])))

    X_tbe = np.asarray(tbe_rows, dtype=np.float64)
    X_bre = np.asarray(bre_rows, dtype=np.float64)
    X_cce = np.asarray(cce_rows, dtype=np.float64)

    matrices = {
        "model_a": X_tbe,
        "model_b": np.hstack([X_tbe, X_bre]),
        "model_c": np.hstack([X_tbe, X_bre, X_cce]),
    }
    y = merged["payment_is_scam_induced"].to_numpy(dtype=np.int64)
    return merged, matrices, y


def tune_threshold(y_true: np.ndarray, probs: np.ndarray) -> float:
    best_thresh = 0.5
    best_f1 = -1.0
    for thresh in np.linspace(0.25, 0.80, 23):
        preds = (probs >= thresh).astype(int)
        score = float(f1_score(y_true, preds, zero_division=0))
        if score > best_f1:
            best_f1 = score
            best_thresh = float(round(thresh, 3))
    return best_thresh


def main() -> None:
    ARTIFACTS_DIR.mkdir(parents=True, exist_ok=True)
    merged, matrices, y = assemble_fusion_matrices()
    train_mask = (merged["split"] == "train").to_numpy()
    val_mask = (merged["split"] == "val").to_numpy()

    feature_sets = {
        "model_a": TBE_FEATURE_NAMES,
        "model_b": TBE_FEATURE_NAMES + BRE_FEATURE_NAMES,
        "model_c": TBE_FEATURE_NAMES + BRE_FEATURE_NAMES + CCE_FEATURE_NAMES,
    }

    for key, X in matrices.items():
        pipe = Pipeline(
            [
                ("scaler", StandardScaler()),
                ("clf", LogisticRegression(max_iter=1500, class_weight="balanced", random_state=42)),
            ]
        )
        pipe.fit(X[train_mask], y[train_mask])
        val_probs = pipe.predict_proba(X[val_mask])[:, 1]
        val_pr_auc = float(average_precision_score(y[val_mask], val_probs))
        best_threshold = tune_threshold(y[val_mask], val_probs)

        joblib.dump(
            {
                "model": pipe,
                "feature_names": feature_sets[key],
                "threshold": best_threshold,
                "val_pr_auc": val_pr_auc,
                "model_version": f"{key}_fusion_v1.0",
                "policy_version": "policy_v1.0",
            },
            ARTIFACTS_DIR / f"{key}.joblib",
        )
        print(f"Trained {key}: val PR-AUC={val_pr_auc:.4f}, tuned threshold={best_threshold}")


if __name__ == "__main__":
    main()
