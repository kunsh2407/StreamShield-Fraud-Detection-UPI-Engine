"""Backend integration and engine invariant tests for StreamShield."""

from __future__ import annotations

import sys
from pathlib import Path
from fastapi.testclient import TestClient

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from backend.app.engines.coercion_context import score_coercion  # noqa: E402
from backend.app.engines.transaction_behaviour import score_transaction  # noqa: E402
from backend.app.main import app  # noqa: E402
from backend.app.models.model_loader import registry  # noqa: E402

client = TestClient(app)


def test_health_and_ablation_endpoints():
    resp = client.get("/api/v1/health")
    assert resp.status_code == 200
    body = resp.json()
    assert body["is_simulated"] is True
    assert body["models_loaded"]["tbe"] is True
    assert body["models_loaded"]["bre"] is True
    assert body["models_loaded"]["fusion_c"] is True
    assert body["models_loaded"]["evaluation_report"] is True

    eval_resp = client.get("/api/v1/evaluation/ablation")
    assert eval_resp.status_code == 200
    eval_data = eval_resp.json()
    assert len(eval_data["models"]) == 3
    assert eval_data["models"][2]["prAuc"] > eval_data["models"][0]["prAuc"]


def test_skip_and_not_sure_are_never_penalized_as_fraud():
    cce_skip = score_coercion([{"question_id": "Q_URGENCY", "answer": "SKIP"}])
    cce_not_sure = score_coercion([{"question_id": "Q_THREAT", "answer": "NOT_SURE"}])
    cce_help = score_coercion([{"question_id": "Q_SECRECY", "answer": "NEED_HELP"}])
    assert cce_skip is not None and cce_skip.score == 0
    assert cce_not_sure is not None and cce_not_sure.score == 0
    assert cce_help is not None and cce_help.score == 0


def test_demographics_do_not_affect_tbe_score():
    cust_senior = dict(registry.customers["CUS_0001"])
    cust_general = {
        **cust_senior,
        "profile_group": "GENERAL",
        "preferred_language": "en",
        "age": 27,
    }
    payment = {"amount": 42000, "is_new_beneficiary": False, "txn_hour": 10}
    s1 = score_transaction(payment, cust_senior)
    s2 = score_transaction(payment, cust_general)
    assert s1.score == s2.score
    assert s1.reason_codes == s2.reason_codes


def test_full_payment_lifecycle_low_high_and_feedback():
    # 1. Low-risk everyday payment
    low_resp = client.post(
        "/api/v1/payments/initiate",
        json={
            "customer_id": "CUS_0002",
            "beneficiary_id": "BEN_0102",
            "amount": 350.0,
            "currency": "INR",
            "purpose": "Groceries",
            "language": "en",
            "channel": "WEB_SIMULATOR",
        },
    )
    assert low_resp.status_code == 200
    low_data = low_resp.json()
    assert low_data["initial_assessment"]["risk_level"] == "LOW"
    assert low_data["initial_assessment"]["recommended_action"] == "ALLOW"

    # 2. Digital-arrest high-risk coercion flow
    init_resp = client.post(
        "/api/v1/payments/initiate",
        json={
            "customer_id": "CUS_0001",
            "beneficiary_id": "BEN_0601",
            "amount": 75000.0,
            "currency": "INR",
            "purpose": "Court Bail Verification",
            "language": "te",
            "channel": "WEB_SIMULATOR",
        },
    )
    assert init_resp.status_code == 200
    init_data = init_resp.json()
    pid = init_data["payment_id"]
    assert init_data["next_question"]["question_id"] == "Q_URGENCY"

    a1 = client.post(f"/api/v1/payments/{pid}/answers", json={"question_id": "Q_URGENCY", "answer": "YES", "input_mode": "TAP"})
    assert a1.status_code == 200
    assert a1.json()["next_question"]["question_id"] == "Q_THREAT"

    a2 = client.post(f"/api/v1/payments/{pid}/answers", json={"question_id": "Q_THREAT", "answer": "YES", "input_mode": "VOICE"})
    assert a2.status_code == 200
    assert a2.json()["next_question"]["question_id"] == "Q_SECRECY"

    a3 = client.post(f"/api/v1/payments/{pid}/answers", json={"question_id": "Q_SECRECY", "answer": "YES", "input_mode": "TAP"})
    assert a3.status_code == 200
    final_data = a3.json()
    assert final_data["questionnaire_status"] == "COMPLETED"
    assert final_data["final_assessment"]["risk_level"] == "HIGH"
    assert final_data["final_assessment"]["recommended_action"] == "SAFETY_PAUSE"
    assert "AUTHORITY_THREAT_REPORTED" in final_data["final_assessment"]["reason_codes"]

    # 3. Decision & Feedback persistence
    review_resp = client.post(f"/api/v1/payments/{pid}/decision", json={"customer_choice": "REQUEST_BANK_REVIEW"})
    assert review_resp.status_code == 200
    assert review_resp.json()["status"] == "REFERRED_FOR_REVIEW"

    dec_resp = client.post(f"/api/v1/payments/{pid}/decision", json={"customer_choice": "PAUSE_AND_VERIFY"})
    assert dec_resp.status_code == 200
    assert dec_resp.json()["status"] == "SIMULATION_PAUSED"

    fb_resp = client.post(
        "/api/v1/feedback",
        json={"payment_id": pid, "outcome": "CONFIRMED_SCAM", "label_source": "REVIEWER", "notes": "Pytest verification"},
    )
    assert fb_resp.status_code == 200
    assert fb_resp.json()["saved"] is True

    # 4. Admin retrieval
    detail = client.get(f"/api/v1/payments/{pid}")
    assert detail.status_code == 200
    assert detail.json()["status"] == "SIMULATION_PAUSED"
    assert detail.json()["feedback"]["outcome"] == "CONFIRMED_SCAM"


def test_validation_and_unknown_entity_errors():
    bad_amt = client.post(
        "/api/v1/payments/initiate",
        json={"customer_id": "CUS_0001", "beneficiary_id": "BEN_0101", "amount": -50},
    )
    assert bad_amt.status_code == 422

    missing_cust = client.post(
        "/api/v1/payments/initiate",
        json={"customer_id": "CUS_DOES_NOT_EXIST", "beneficiary_id": "BEN_0101", "amount": 500},
    )
    assert missing_cust.status_code == 404
    assert missing_cust.json()["error"]["code"] == "UNKNOWN_CUSTOMER"


def test_demo_stateless_score_with_answers_evaluates_cce_and_progression():
    step0 = client.post(
        "/api/v1/demo/score",
        json={
            "customer_id": "CUS_0001",
            "beneficiary_id": "BEN_0601",
            "amount": 75000,
            "currency": "INR",
            "purpose": "Cyber Police Bail Verification",
            "language": "te",
            "answers": [],
        },
    )
    assert step0.status_code == 200
    assert step0.json()["next_question"]["question_id"] == "Q_URGENCY"

    step1 = client.post(
        "/api/v1/demo/score",
        json={
            "customer_id": "CUS_0001",
            "beneficiary_id": "BEN_0601",
            "amount": 75000,
            "currency": "INR",
            "purpose": "Cyber Police Bail Verification",
            "language": "te",
            "answers": [
                {"question_id": "Q_URGENCY", "answer": "YES", "input_mode": "TAP", "answered_at": "2026-11-13T00:00:00Z"}
            ],
        },
    )
    assert step1.status_code == 200
    assert step1.json()["next_question"]["question_id"] == "Q_THREAT"

    step3 = client.post(
        "/api/v1/demo/score",
        json={
            "customer_id": "CUS_0001",
            "beneficiary_id": "BEN_0601",
            "amount": 75000,
            "currency": "INR",
            "purpose": "Cyber Police Bail Verification",
            "language": "te",
            "answers": [
                {"question_id": "Q_URGENCY", "answer": "YES", "input_mode": "TAP", "answered_at": "2026-11-13T00:00:00Z"},
                {"question_id": "Q_THREAT", "answer": "YES", "input_mode": "TAP", "answered_at": "2026-11-13T00:00:01Z"},
                {"question_id": "Q_SECRECY", "answer": "YES", "input_mode": "TAP", "answered_at": "2026-11-13T00:00:02Z"},
            ],
        },
    )
    assert step3.status_code == 200
    data = step3.json()
    assert data["next_question"] is None
    assert data["assessment"]["component_scores"]["coercion_risk_score"] == 100
    assert data["assessment"]["risk_level"] == "HIGH"
    assert data["assessment"]["recommended_action"] == "SAFETY_PAUSE"
    assert "AUTHORITY_THREAT_REPORTED" in data["assessment"]["reason_codes"]


def test_user_account_and_closed_loop_bank_review_resolution():
    acct = client.get(
        "/api/v1/user/account",
        headers={"X-User-Role": "USER", "X-User-Customer-Id": "CUS_0001"},
    )
    assert acct.status_code == 200
    acct_data = acct.json()
    assert acct_data["profile"]["customer_id"] == "CUS_0001"
    assert acct_data["vpa"] == "rama.rao@okupi"
    assert len(acct_data["transactions"]) >= 3

    # Case 1: User requests bank review -> Bank marks CONFIRMED_LEGITIMATE -> APPROVED_BY_BANK
    init_legit = client.post(
        "/api/v1/payments/initiate",
        json={
            "customer_id": "CUS_0001",
            "beneficiary_id": "BEN_0602",
            "amount": 25000.0,
            "currency": "INR",
            "purpose": "Family Medical Advance",
            "language": "en",
            "channel": "PHONE_APP",
        },
    )
    assert init_legit.status_code == 200
    pid_legit = init_legit.json()["payment_id"]

    # Walk through remaining questions
    q = init_legit.json()["next_question"]
    while q is not None:
        ans = client.post(
            f"/api/v1/payments/{pid_legit}/answers",
            json={"question_id": q["question_id"], "answer": "NO", "input_mode": "TAP"},
        )
        assert ans.status_code == 200
        q = ans.json()["next_question"]

    rev1 = client.post(f"/api/v1/payments/{pid_legit}/decision", json={"customer_choice": "REQUEST_BANK_REVIEW"})
    assert rev1.status_code == 200
    assert rev1.json()["status"] == "REFERRED_FOR_REVIEW"

    fb_legit = client.post(
        "/api/v1/feedback",
        json={"payment_id": pid_legit, "outcome": "CONFIRMED_LEGITIMATE", "label_source": "REVIEWER"},
    )
    assert fb_legit.status_code == 200
    assert fb_legit.json()["updated_status"] == "APPROVED_BY_BANK"
    assert client.get(f"/api/v1/payments/{pid_legit}").json()["status"] == "APPROVED_BY_BANK"

    # Case 2: User requests bank review -> Bank marks CONFIRMED_SCAM -> TERMINATED_SCAM
    init_scam = client.post(
        "/api/v1/payments/initiate",
        json={
            "customer_id": "CUS_0001",
            "beneficiary_id": "BEN_0601",
            "amount": 60000.0,
            "currency": "INR",
            "purpose": "CBI Clearance Fee",
            "language": "en",
            "channel": "LAPTOP_WEB",
        },
    )
    assert init_scam.status_code == 200
    pid_scam = init_scam.json()["payment_id"]
    q2 = init_scam.json()["next_question"]
    while q2 is not None:
        ans2 = client.post(
            f"/api/v1/payments/{pid_scam}/answers",
            json={"question_id": q2["question_id"], "answer": "YES", "input_mode": "TAP"},
        )
        assert ans2.status_code == 200
        q2 = ans2.json()["next_question"]

    rev2 = client.post(f"/api/v1/payments/{pid_scam}/decision", json={"customer_choice": "REQUEST_BANK_REVIEW"})
    assert rev2.json()["status"] == "REFERRED_FOR_REVIEW"

    fb_scam = client.post(
        "/api/v1/feedback",
        json={"payment_id": pid_scam, "outcome": "CONFIRMED_SCAM", "label_source": "REVIEWER"},
    )
    assert fb_scam.status_code == 200
    assert fb_scam.json()["updated_status"] == "TERMINATED_SCAM"
    assert client.get(f"/api/v1/payments/{pid_scam}").json()["status"] == "TERMINATED_SCAM"

    # Case 3: Cancel & Report Fraud by customer
    init_rep = client.post(
        "/api/v1/payments/initiate",
        json={
            "customer_id": "CUS_0002",
            "beneficiary_id": "BEN_0601",
            "amount": 55000.0,
            "currency": "INR",
            "purpose": "Unknown Arrest Desk",
            "language": "en",
            "channel": "PHONE_APP",
        },
    )
    pid_rep = init_rep.json()["payment_id"]
    rep_dec = client.post(
        f"/api/v1/payments/{pid_rep}/decision",
        json={"customer_choice": "CANCEL_SIMULATED", "report_fraud": True},
    )
    assert rep_dec.status_code == 200
    assert rep_dec.json()["status"] == "SIMULATION_CANCELLED"
    rep_detail = client.get(f"/api/v1/payments/{pid_rep}").json()
    assert rep_detail["feedback"]["label_source"] == "CUSTOMER"
    assert rep_detail["feedback"]["outcome"] == "CONFIRMED_SCAM"
