# StreamShield — Hackathon Pitch Deck & Jury Q&A Document

> **Prototype Scope Notice:** StreamShield is a working pre-payment risk & coercion-protection prototype running on synthetic transaction scenarios (`data/scenarios.csv`, `ml/artifacts/`), local customer/beneficiary baselines, a Python FastAPI + scikit-learn scoring service, an Express + Firebase Auth gateway, and Cloud SQL PostgreSQL persistence (`asia-southeast1`). It does **not** connect to live UPI/NPCI rails, move real money, collect UPI PINs/OTPs, or integrate with live RBI MuleHunter.ai / DPIP APIs.

---

## Part 1: Updated Pitch Deck (6 Slides + Speaker Scripts)

### Slide 1 — Problem & Vision: Stopping Authorized Push Payment (APP) Scams Before the PIN
- **Headline:** *StreamShield: Pre-Payment Mule-Ring & Social-Engineering Defense for UPI*
- **Core Problem:**
  - UPI payments settle irrevocably in seconds.
  - In **Digital Arrest**, fake **Bank KYC**, and authority-impersonation scams, scammers coach victims live over phone/video calls to override generic bank alerts and enter their own UPI PIN.
  - Traditional threshold rules (`> ₹50,000`) create high false-positive friction for genuine users while missing structured smurfing and first-time coercion transfers.
- **Vision:** Score both **financial/network risk** and **real-time human coercion context** *before* the user authorizes payment—intervening calmly in the payer's own language (`English`, `తెలుగు`, `हिन्दी`).
- **Speaker Script (45 sec):**
  > "UPI moves money irrevocably in seconds. When a scammer impersonates cyber police on a live phone call, transaction monitoring alone only sees a valid customer entering their own PIN. StreamShield intervenes *before* the PIN is entered—fusing transaction anomaly, beneficiary mule intelligence, and a blame-free 2-to-3 question coercion check right inside the payment flow."

---

### Slide 2 — Five-Engine Risk Fusion Architecture (`TBE + BRE + AQS + CCE + RFDE`)
- **Headline:** *Modular, Auditable Scoring Instead of a Black-Box Score*
- **Architecture:**
  1. **TBE (Transaction Behaviour Engine):** Trained `LogisticRegression` (`StandardScaler`, `class_weight="balanced"`) evaluating payer amount deviation against robust Median/MAD baselines, ratio to 30-day median, and unusual active hour flags.
  2. **BRE (Beneficiary Risk Engine):** `NetworkX`-derived counterparty graph degree, 24h rapid flow-through ratio, incoming/outgoing diversity, and defensive priors for brand-new cold-start beneficiaries (`account_age_days`).
  3. **AQS (Adaptive Questioning Service):** Triggers **only** when initial risk is elevated (`MEDIUM` or `HIGH`, score `>= 35`)—serving 2 to 3 localized clarification questions (`English`, `తెలుగు`, `हिन्दी`) with optional WebSpeech audio read-aloud (`0` mic permissions required).
  4. **CCE (Coercion Context Engine):** Scores urgency, secrecy, authority intimidation, and OTP/remote-screen-share pressure from adaptive replies—while enforcing **zero penalty** for `NOT_SURE`, `SKIP`, or `NEED_HELP`.
  5. **RFDE (Risk Fusion & Decision Engine):** Calibrated logistic fusion model (`fusion_c_model.joblib`) outputs an auditable `0–100` score, plain-language reason codes, and recommended action: `ALLOW`, `VERIFY`, or `SAFETY_PAUSE`.
- **Full-Stack Deployment:** React 19 + TypeScript UI (`:3000`) -> Express + Firebase Google Auth API Gateway (`:3000/api/v1/*`) -> Python FastAPI + scikit-learn scoring service (`:8001`) -> Cloud SQL PostgreSQL (`asia-southeast1`) + Drizzle ORM schema.
- **Speaker Script (60 sec):**
  > "Instead of one opaque score, StreamShield decomposes risk into three calibrated engines. Everyday transfers—like a regular ₹350 chai payment—score low on TBE and BRE and clear immediately with zero questions. Only ambiguous or risky transfers trigger our Adaptive Questioning Service, which gathers coercion signals in English, Telugu, or Hindi without ever penalizing someone who taps Skip or Not Sure."

---

### Slide 3 — Reproducible Three-Model Ablation Proof (Empirical Results)
- **Headline:** *Coercion Context Cuts False Positives to 1.38% and Catches 100% of Held-Out Digital-Arrest Scams*
- **Experimental Setup (Measured from `ml/artifacts/evaluation_metrics.json`):**
  - **Dataset:** `2,400` synthetic UPI scenarios generated offline (`ml/train_models.py`).
  - **Leakage Prevention:** Strictly grouped by `customer_id` (`453` held-out test scenarios, `19.87%` positive rate).
  - **Mean Adaptive Burden:** `2.14` questions per payment; `0.1%` skip rate.

| Model | Engines Included | Threshold | PR-AUC | Precision | Recall | F1 | Brier Score | FP Rate | Digital-Arrest Catch | Avg Latency |
| :--- | :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| **Model A** | `TBE` (Transaction Only) | `0.675` | `0.6188` | `51.54%` | `74.44%` | `0.6091` | `0.1433` | `17.36%` | `80.0%` | `0.513 ms` |
| **Model B** | `TBE + BRE` (+ Mule Graph) | `0.750` | `0.9048` | `83.53%` | `78.89%` | `0.8114` | `0.0869` | `3.86%` | `86.7%` | `0.469 ms` |
| **Model C** | `TBE + BRE + CCE` (**StreamShield**) | `0.600` | **`0.9958`** | **`94.62%`** | **`97.78%`** | **`0.9617`** | **`0.0168`** | **`1.38%`** | **`100.0%`** | **`0.433 ms`** |

- **Confusion Matrices (453 Held-Out Scenarios):**
  - **Model A:** TP `67`, FP `63`, TN `300`, FN `23`
  - **Model B:** TP `71`, FP `14`, TN `349`, FN `19`
  - **Model C (StreamShield):** TP `88`, FP `5`, TN `358`, FN `2`
- **Speaker Script (45 sec):**
  > "Using a customer-grouped held-out split of 453 synthetic scenarios, transaction behavior alone hits a PR-AUC of 0.619 with a 17.4% false-positive rate. Adding beneficiary graph intelligence lifts PR-AUC to 0.905. Adding StreamShield's coercion context lifts PR-AUC to 0.996, slashes false positives down to 1.38%, and catches 100% of held-out digital-arrest scenarios."

---

### Slide 4 — Inclusive Vernacular UX, Ethics & Customer Safety Controls
- **Headline:** *Accessibility Is a Security Control—Zero Demographic Bias, Zero Skip Penalty*
- **Key Capabilities:**
  - **Multilingual & Voice-Read-Aloud:** Native prompts in `English`, `తెలుగు` (Telugu), and `हिन्दी` (Hindi), plus one-tap WebSpeech read-aloud (`SpeechSynthesis`) that never requires microphone access.
  - **Fairness Constraints Enforced in ML:** Customer demographics (age bracket, preferred language, digital literacy) are strictly excluded from the ML feature matrix.
  - **Non-Punitive Neutrality:** Clicking `NOT_SURE`, `SKIP`, or `NEED_HELP` adds `0` coercion risk points and preserves calm, supportive guidance.
  - **Explicit Customer Outcomes After Assessment:**
    - `Pause & Verify (Recommended)` -> places session in `PAUSED_BY_USER` cooldown.
    - `Request Bank Review` -> immediately escalates session status to `REFERRED_FOR_REVIEW`, shows localized confirmation + a 1-click **Open Analyst Queue** action.
    - `Cancel Simulated Payment` / `Continue Simulated Payment` -> recorded cleanly in PostgreSQL `payments` and `audit_events`.
- **Speaker Script (45 sec):**
  > "Senior citizens under panic cannot parse tiny security warnings. Our interface enforces 44px+ tap targets, plain-language questions in English, Telugu, and Hindi, one-tap audio read-aloud, and zero penalty for tapping Skip or Not Sure. Users can pause to verify with family, cancel outright, or tap Request Bank Review to escalate the case straight into the Bank Analyst Queue."

---

### Slide 5 — Live Operations Monitor, Trail Freeze & Analyst Feedback Loop (FES)
- **Headline:** *Real-Time Stream Operations + PostgreSQL Closed-Loop Retraining*
- **Operational Tooling Built in the App:**
  - **Live Operations & Mule Graph Monitor:** Simulates Round 1 mule fan-in and Round 2 adaptive smurfing rings (`NetworkGraphView`), live transaction scoring feed, tunable `Step-Up` and `Hold` policy thresholds, and an interactive **Friction–Safety Cost Utility Curve** in INR (`Net Benefit = ₹ Fraud Blocked - ₹ Friction Cost`).
  - **Trail Freeze Intervention:** Analysts can inspect a flagged mule hub on the graph and execute a simulated downstream **Trail Freeze** cascade across linked mule hops.
  - **Bank Analyst Queue & FES (Feedback & Evaluation Store):** Displays live session queues merged with Cloud SQL PostgreSQL alerts (`GET /api/v1/admin/alerts`, `GET /api/v1/admin/metrics`), highlighting `REFERRED FOR REVIEW` escalations and allowing analysts to record ground-truth labels (`CONFIRMED_SCAM` / `CONFIRMED_LEGITIMATE` via `POST /api/v1/feedback`) for future model calibration.
- **Speaker Script (45 sec):**
  > "Beyond pre-payment coaching, StreamShield closes the loop for bank fraud teams. Analysts monitor streaming mule graphs, test Round 2 smurfing drift thresholds, inspect escalated `REFERRED_FOR_REVIEW` payments, and store confirmed scam or legitimate labels directly into Cloud SQL PostgreSQL to power future model retraining."

---

### Slide 6 — Live 2-Minute Demo Script & Ecosystem Alignment
- **Live Demo Flow:**
  1. **Simulator — Demo 1 (`Everyday Chai Pay`, ₹350):** Clears immediately as `LOW RISK · ALLOW` (`0` questions asked—zero friction for routine payments).
  2. **Simulator — Demo 2 (`Digital-Arrest Scam`, ₹75,000, switch to `తెలుగు` or `हिन्दी`):** Triggers `TBE + BRE` risk, walks through 3 localized coercion questions (with optional audio read-aloud), escalates to `SAFETY_PAUSE` (`100/100`), then click **Request Bank Review** -> **Open Analyst Queue** to show `REFERRED FOR REVIEW` queued for analyst triage.
  3. **ML Ablation & Operations:** Show live Model A -> B -> C PR-AUC jump from `ml/artifacts/evaluation_metrics.json`, and inject `+25 Tx` in **Operations** (`Round 2 Drift`) to demonstrate threshold tuning and graph Trail Freeze.
- **Ecosystem Positioning:** Designed as a **complementary pre-payment customer coercion & bank analyst sidecar** alongside existing bank mule-account defenses (such as RBI **MuleHunter.ai** and **DPIP** concepts)—bridging the gap before authorized push payment PIN entry without claiming live rail integration.

---

## Part 2: Updated Jury Q&A Defense Playbook

### Category 1: Tech Stack & Architecture

**Q1. What exact frontend, backend, database, and ML stack is running in StreamShield right now?**
- **Direct Answer:** React 19 + TypeScript + Tailwind CSS v4 frontend (Vite), Node.js/Express API gateway + Firebase Auth on port `3000`, Python FastAPI + scikit-learn + NetworkX scoring engine on port `8001`, and Cloud SQL PostgreSQL (`asia-southeast1`) managed with Drizzle ORM (`src/db/schema.ts`) and `psycopg2`.
- **Implementation Details:**
  - Frontend communicates strictly through Express `/api/v1/*` routes (`server.ts`), keeping DB credentials and server configuration off the client.
  - Firebase Google Authentication verifies ID tokens on protected PostgreSQL persistence routes (`POST /api/v1/payments/initiate`, `/answer`, `/decision`, `/feedback`, `/admin/alerts`, `/admin/metrics`), while guest visitors can run stateless scoring against FastAPI (`/api/v1/demo/score`) and inspect local session queues immediately.
  - Python FastAPI (`backend/app/main.py`) loads pre-trained `.joblib` scikit-learn bundles (`tbe_model.joblib`, `bre_model.joblib`, `fusion_c_model.joblib`) at startup.

**Q2. Why use both Express (`server.ts`) and Python FastAPI (`backend/app`)?**
- **Direct Answer:** Express serves as the single web origin (`:3000`) handling Vite assets, Firebase ID token verification, and Drizzle schema alignment, while Python FastAPI (`:8001`) executes native scikit-learn + NumPy + NetworkX ML inference and Cloud SQL payment orchestration cleanly in Python.
- **Benefit:** Zero cross-origin CORS exposure in the browser (`localhost:3000` proxies `/api/v1/*` internally to `127.0.0.1:8001`), and the Python scoring service can scale independently as a dedicated bank sidecar microservice.

**Q3. Which backend API endpoints are implemented and tested?**
- `GET /api/v1/health` — Model readiness, model/policy version, synthetic environment flag.
- `POST /api/v1/demo/score` — Stateless FastAPI scoring for unauthenticated quick demos.
- `POST /api/v1/payments/initiate` — Runs Stage 1 (`TBE + BRE`), persists payment + assessment in PostgreSQL, returns initial score and question #1 if risk `>= 35`.
- `POST /api/v1/payments/{id}/answer` — Records adaptive reply (`YES`, `NO`, `NOT_SURE`, `SKIP`, `NEED_HELP`), serves next question or runs Stage 2 (`CCE + RFDE`) final fusion.
- `POST /api/v1/payments/{id}/decision` — Records customer choice (`PAUSE_AND_VERIFY`, `CONTINUE_SIMULATED`, `CANCEL_SIMULATED`, `REQUEST_BANK_REVIEW` -> transitions status to `REFERRED_FOR_REVIEW`).
- `POST /api/v1/feedback` — Persists analyst ground-truth outcome (`CONFIRMED_SCAM` / `CONFIRMED_LEGITIMATE`) for FES retraining loops.
- `GET /api/v1/admin/alerts` & `GET /api/v1/admin/metrics` — Serves queued cases, latency metrics (`avg`, `p99`), and risk counts to the Bank Analyst Queue.
- **Verification:** Covered by `tests/backend/test_api.py` (pytest integration suite running directly against FastAPI + Cloud SQL PostgreSQL).

---

### Category 2: Machine Learning, Ablation & Class Imbalance

**Q4. Real UPI fraud is well under 1%. Why doesn't simple accuracy work, and how did you train against imbalance?**
- **Direct Answer:** A naive model predicting "safe" on 99%+ legitimate traffic achieves 99% accuracy with 0% fraud recall. We optimize **PR-AUC**, **Precision**, **Recall**, **Brier calibration score**, and **False Positive Rate** using `class_weight="balanced"` logistic regression pipelines with `StandardScaler`.
- **Zero-Leakage Guarantee:** In `ml/train_models.py`, train/validation/test splits partition strictly by `customer_id` (`GroupShuffleSplit`), guaranteeing no scenario from a test customer ever appears during training or threshold calibration.

**Q5. How do your three ablation models prove the value of Coercion Context (CCE)?**
- **Direct Answer:** On our 453 held-out synthetic scenarios:
  - **Model A (`TBE` only):** PR-AUC `0.6188`, FP Rate `17.36%`, Digital-Arrest Catch `80.0%`.
  - **Model B (`TBE + BRE`):** PR-AUC `0.9048`, FP Rate `3.86%`, Digital-Arrest Catch `86.7%`.
  - **Model C (`TBE + BRE + CCE`, StreamShield):** PR-AUC `0.9958`, FP Rate `1.38%`, Recall `97.78%`, Precision `94.62%`, Brier Score `0.0168`, Digital-Arrest Catch `100.0%`.
- **Key Takeaway:** Coercion questioning eliminates ~64% of remaining false positives compared to transaction+graph alone (`3.86%` -> `1.38%`) while closing the blind spot on social-engineering scams where the payer's own device and PIN are genuine.

**Q6. Why use calibrated Logistic Regression models (`joblib`) instead of heavy neural networks or LLM calls on the hot path?**
- **Direct Answer:** Sub-millisecond deterministic inference, calibrated probability outputs (Brier `0.0168`), complete feature explainability into human-readable reason codes, and zero dependence on external LLM API calls during pre-payment risk scoring.

---

### Category 3: Latency, Cold-Start & Adversarial Drift

**Q7. How do you keep real-time scoring fast without sacrificing network graph signals?**
- **Direct Answer:** Beneficiary graph attributes (`network_degree`, `flow_through_ratio_24h`, `incoming_distinct_senders`, `account_age_days`) are derived offline/asynchronously via `NetworkX` (`ml/extract_graph_features.py`) and read directly during inference, yielding sub-millisecond model evaluation (~`0.43 ms` mean offline benchmark, single-digit/low-double-digit ms end-to-end FastAPI response). Low-risk payments (`score < 35`) exit immediately without any clarification questions.

**Q8. What happens during "Cold Start" (a brand-new mule account) or Round 2 adversarial smurfing?**
- **Cold-Start Defense:** New accounts with tiny `account_age_days` receive conservative cold-start priors in `BRE`, weighted alongside high `flow_through_ratio_24h` and counterparty graph degree—so a 3-day-old mule funneling 97% of inflows gets flagged immediately even without 30-day history.
- **Round 2 Smurfing & Drift Defense:** In the **Operations** workspace, analysts can inject Round 2 smurfing rings (split sub-threshold transfers cycling through mule hops), dynamically tune Step-Up and Hold decision thresholds against the live **Friction–Safety Cost Utility** curve, and execute a multi-hop **Trail Freeze**.

---

### Category 4: Accessibility, Ethics, Privacy & Regulatory Scope

**Q9. Does age, language choice, or tapping "Not Sure / Skip" unfairly penalize vulnerable users?**
- **Direct Answer:** Never. Demographic fields (age group, preferred language, digital literacy) are strictly excluded from all model training and inference feature vectors. Clicking `NOT_SURE`, `SKIP`, or `NEED_HELP` contributes **zero coercion risk points** and only alters UX support—offering calm guidance or **Request Bank Review**.

**Q10. How does StreamShield protect privacy and relate to RBI MuleHunter.ai / DPIP?**
- **Privacy by Design:** Zero real money, zero UPI PIN/OTP capture, and zero microphone recording (`WebSpeech SpeechSynthesis` only reads questions aloud client-side).
- **Ecosystem Positioning:** MuleHunter.ai and bank/PSP risk engines focus on detecting receiving mule accounts; StreamShield complements them on the **pre-payment payer side** by capturing real-time social-engineering coercion before irrevocable settlement and routing escalated (`REFERRED_FOR_REVIEW`) cases with reason codes straight into the bank analyst queue.
- **Honest Prototype Boundary:** All customer profiles, beneficiary graphs, and 2,400 evaluation scenarios are synthetic benchmarks built for hackathon validation.
